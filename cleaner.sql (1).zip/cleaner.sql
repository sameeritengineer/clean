-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 28, 2020 at 04:00 PM
-- Server version: 5.7.18-log
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cleaner`
--

-- --------------------------------------------------------

--
-- Table structure for table `approved__bios`
--

CREATE TABLE `approved__bios` (
  `id` int(10) UNSIGNED NOT NULL,
  `serviceprovider_id` int(11) NOT NULL,
  `Bio` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `approved__bios`
--

INSERT INTO `approved__bios` (`id`, `serviceprovider_id`, `Bio`, `starttime`, `endtime`, `created_at`, `updated_at`) VALUES
(1, 5, 'Hi this is testing going ON.', '06:22:00', '17:08:00', '2019-01-22 00:51:12', '2019-03-28 06:51:27'),
(2, 3, '<p>kstkteoyruor</p>', '04:49:00', '03:49:00', '2019-01-22 00:53:08', '2019-05-21 00:32:58'),
(3, 7, '<p>This is testing .only extras</p>', '18:58:00', '11:51:00', '2019-01-22 00:54:29', '2019-05-21 00:34:07'),
(4, 11, '<p>bshsbsjhshahahwhuege</p>', '17:16:00', '17:16:00', '2019-01-22 06:20:03', '2019-01-30 00:10:58'),
(5, 40, '<p>hello</p>', '13:12:00', '18:12:00', '2019-02-04 02:14:58', '2019-05-21 00:36:26'),
(6, 43, '<p>Hhhhhhh</p>', '15:08:00', '15:08:00', '2019-02-04 02:17:26', '2019-05-21 00:36:50'),
(7, 47, '<p>These text generators are solid (and serious) in nature. Most of which have great features to help increase the effectiveness of your vision.</p>', '09:00:00', '19:00:00', '2019-02-20 07:06:38', '2019-05-21 00:36:59'),
(8, 49, 'This app works', '21:48:00', '20:48:00', '2019-04-01 06:49:04', '2019-05-21 01:37:15'),
(9, 63, '<p>hello</p>', '10:26:00', '20:26:00', '2019-05-20 07:27:19', '2019-05-20 07:29:37'),
(11, 37, '<p>fgdfgfdg</p>', '10:30:00', '22:30:00', '2019-05-21 00:35:52', '2019-05-21 00:35:52'),
(12, 54, '<p>jghjghjgj gh jghjghjhj</p>', '22:30:00', '09:25:00', '2019-05-21 00:54:35', '2019-05-21 00:54:35'),
(13, 50, '<p>ghjfgjghjh</p>', '10:00:00', '10:00:00', '2019-05-21 02:11:46', '2019-05-21 02:11:46'),
(14, 60, 'test', '15:04:00', '15:05:00', '2019-05-22 04:19:49', '2019-05-22 04:19:49'),
(15, 78, 'wow', '02:09:00', '11:09:00', '2019-08-20 08:10:20', '2019-08-20 08:10:20'),
(16, 80, 'testing', '00:00:00', '23:00:00', '2019-08-21 04:07:52', '2019-08-21 04:07:52'),
(17, 81, 'hi this is ajay', '17:11:00', '08:44:00', '2019-08-21 05:12:38', '2019-08-21 05:12:38'),
(18, 83, 'dhdkdhd', '00:00:00', '23:00:00', '2019-08-23 05:11:42', '2019-08-23 05:11:42'),
(19, 86, 'Testing', '00:00:00', '23:00:00', '2019-08-27 03:57:59', '2019-08-27 03:57:59'),
(20, 88, 'final testing', '00:00:00', '23:00:00', '2019-08-27 06:26:47', '2019-08-27 06:26:47'),
(21, 93, 'testing', '00:00:00', '23:00:00', '2019-08-28 02:43:15', '2019-08-28 02:43:15'),
(22, 94, 'tdhdkxhd', '00:00:00', '23:00:00', '2019-08-28 04:20:48', '2019-08-28 04:20:48'),
(23, 100, 'Testing', '00:00:00', '23:00:00', '2019-08-28 06:35:59', '2019-08-28 06:35:59'),
(24, 102, 'Fhdid', '00:00:00', '23:00:00', '2019-08-28 08:10:59', '2019-08-28 08:10:59'),
(25, 103, 'Gdidgdiege', '00:00:00', '23:00:00', '2019-08-29 01:47:18', '2019-08-29 01:47:18'),
(26, 104, 'Euro 3', '00:15:00', '23:00:00', '2019-08-29 02:16:18', '2019-08-29 02:16:18'),
(27, 96, 'dhifdydudh', '00:00:00', '23:00:00', '2019-08-29 06:13:50', '2019-08-29 06:13:50'),
(28, 105, 'Fhfiufuuf', '00:00:00', '23:00:00', '2019-08-30 04:17:09', '2019-08-30 04:17:09'),
(29, 106, 'dhdkhd', '00:00:00', '23:00:00', '2019-08-30 04:17:35', '2019-08-30 04:17:35'),
(30, 108, 'Hi there , \nI am a dedicated worker . \nPunctual', '13:00:00', '17:08:00', '2020-02-28 01:09:26', '2020-02-28 01:09:26'),
(31, 110, '100% Customer Satisfaction', '17:39:00', '21:39:00', '2020-02-28 04:40:19', '2020-02-28 04:40:19');

-- --------------------------------------------------------

--
-- Table structure for table `block_customers`
--

CREATE TABLE `block_customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `provider_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `block_customers`
--

INSERT INTO `block_customers` (`id`, `provider_id`, `customer_id`, `status`, `created_at`, `updated_at`) VALUES
(6, 44, 10, 1, '2019-04-02 00:19:56', '2019-04-02 00:19:56'),
(7, 40, 6, 1, '2019-04-02 00:33:11', '2019-04-02 00:33:11');

-- --------------------------------------------------------

--
-- Table structure for table `block_providers`
--

CREATE TABLE `block_providers` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `block_providers`
--

INSERT INTO `block_providers` (`id`, `customer_id`, `provider_id`, `status`, `created_at`, `updated_at`) VALUES
(26, 4, 7, 1, '2019-05-17 01:11:33', '2019-05-17 01:11:33'),
(27, 6, 37, 1, '2019-05-17 01:11:37', '2019-05-17 01:11:37'),
(28, 48, 37, 1, '2019-05-17 01:11:44', '2019-05-17 01:11:44'),
(29, 48, 43, 1, '2019-05-17 01:11:54', '2019-05-17 01:11:54');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `state_id`, `created_at`, `updated_at`) VALUES
(19, 'Somerset', 13, '2018-12-04 02:06:56', '2018-12-04 02:06:56'),
(20, 'Gawler', 12, '2018-12-04 02:08:24', '2018-12-04 02:08:24'),
(21, 'Murray Bridge', 12, '2018-12-04 02:09:27', '2018-12-04 02:09:27'),
(22, 'Mount Barker', 12, '2018-12-04 02:09:42', '2018-12-04 02:09:42'),
(23, 'Newcastle', 10, '2018-12-04 02:10:55', '2018-12-04 02:10:55'),
(24, 'Central Coast', 10, '2018-12-04 02:14:13', '2018-12-04 02:14:13'),
(25, 'Wollongong', 10, '2018-12-04 02:14:26', '2018-12-04 02:14:26'),
(26, 'Maitland', 12, '2018-12-04 02:14:38', '2019-01-21 23:41:56'),
(27, 'Brisbane', 11, '2018-12-04 02:15:13', '2018-12-04 02:15:13'),
(28, 'Sunshine Coast', 11, '2018-12-04 02:15:24', '2018-12-04 02:15:24'),
(29, 'Townsville', 11, '2018-12-04 02:15:33', '2018-12-04 02:15:33'),
(30, 'Cairns', 13, '2018-12-04 02:15:42', '2019-02-02 08:23:24'),
(31, 'Toowoomba', 11, '2018-12-04 02:15:54', '2018-12-04 02:15:54'),
(32, 'Mackay', 11, '2018-12-04 02:16:04', '2018-12-04 02:16:04'),
(33, 'Perth', 15, '2018-12-04 02:16:57', '2019-02-02 08:22:23'),
(34, 'Geraldton', 14, '2018-12-04 02:17:21', '2019-02-02 08:21:27'),
(35, 'Albany', 10, '2018-12-04 02:17:33', '2019-01-21 23:41:24');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `created_at`, `updated_at`) VALUES
(6, 'America', '2018-10-23 02:24:30', '2018-12-21 06:30:42');

-- --------------------------------------------------------

--
-- Table structure for table `customer_faqs`
--

CREATE TABLE `customer_faqs` (
  `id` int(10) UNSIGNED NOT NULL,
  `question` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer_faqs`
--

INSERT INTO `customer_faqs` (`id`, `question`, `answer`, `created_at`, `updated_at`) VALUES
(9, 'How much do you tip a house cleaning service', '<p>Our policy is that tipping is always appreciated by pros who go above and beyond, but never required. The entirety of the tip gets passed through to the pro &mdash; Handy doesn&rsquo;t take any percentage. It&rsquo;s a great way to show your appreciation for your pro and a job well done.<br />\r\n<br />\r\nFurther, we&rsquo;ve found that pros are usually much more likely to pick up your jobs and flex their own schedules to meet yours when you&rsquo;ve tipped them in the past! If your pro works hard or travels a long way to get to your house in bad weather, it&rsquo;s a nice way to show your appreciation. Tipping can be done right through the app on your credit card, same as you paid for the booking.</p>', '2018-12-27 05:19:04', '2019-01-17 05:55:38'),
(10, 'Are house cleaning services worth it', '<p>Yes, it certainly is, assuming you&rsquo;re the type of person who likes to come home to a beautiful and pristine home without having lifted a finger! If you&rsquo;re a time-strapped professional working a 16-hour day, a busy mom or dad shuffling children between daycare and school and soccer practices, or just someone who simply has too much to do and far too little time to do it in, house cleaning can be at the bottom of your list. Nobody wants a messy home, and yet nobody really enjoys chores either &ndash; this is where Handy comes in.<br />\r\n<br />\r\nWe&rsquo;ve got the solutions. You demand top quality house cleaning services, and Handy puts you in touch with the best house cleaners. Cost-wise, you&rsquo;re looking at a service that&rsquo;s affordable and great value for money. And let&rsquo;s be honest -- a couple extra hours with the kids at the end of the day can be priceless.</p>', '2018-12-27 05:19:16', '2019-01-17 05:55:11'),
(11, 'How much are house cleaning services', '<p>This depends on the size of your house &mdash; enter how many bedrooms and bathrooms you have into the form above and we&rsquo;ll give you an instant quote. We&rsquo;re confident you&rsquo;ll find prices extremely reasonable given the high level of service you will receive from your pro.</p>', '2018-12-27 05:19:27', '2019-01-17 05:54:48'),
(12, 'Can I skip or reschedule bookings', '<p>You can reschedule any booking without penalty, so long as you do so at least 24 hours ahead of the scheduled start time.</p>', '2018-12-27 08:06:19', '2019-01-17 05:54:23'),
(18, 'Which Handy professional will come to my place', '<ul>\r\n	<li>Handy has a vast network of experienced, top-rated cleaners. Based on the time and date of your request, we work to assign the best professional available.</li>\r\n	<li>Like working with a specific pro? Add them to your Pro Team from the mobile app and they&#39;ll be requested first for all future bookings.</li>\r\n	<li>You will receive an email with details about your professional prior to your appointment.</li>\r\n</ul>', '2018-12-28 23:22:37', '2019-01-17 05:53:56'),
(19, 'Whats included in a cleaning', '<h3>Bedroom, Living Room &amp; Common Areas</h3>\r\n\r\n<ul>\r\n	<li>Dust all accessible surfaces</li>\r\n	<li>Wipe down all mirrors and glass fixtures</li>\r\n	<li>Clean all floor surfaces</li>\r\n	<li>Take out garbage and recycling</li>\r\n</ul>\r\n\r\n<h3>Bathrooms</h3>\r\n\r\n<ul>\r\n	<li>Wash and sanitize the toilet, shower, tub, and sink</li>\r\n	<li>Dust all accessible surfaces</li>\r\n	<li>Wipe down all mirrors and glass fixtures</li>\r\n	<li>Clean all floor surfaces</li>\r\n	<li>Take out garbage and recycling</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>', '2018-12-28 23:34:15', '2019-01-17 05:53:24');

-- --------------------------------------------------------

--
-- Table structure for table `customer_faq_spanishes`
--

CREATE TABLE `customer_faq_spanishes` (
  `id` int(10) UNSIGNED NOT NULL,
  `cust_faqId` int(10) UNSIGNED DEFAULT NULL,
  `question` longtext COLLATE utf8mb4_unicode_ci,
  `answer` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer_faq_spanishes`
--

INSERT INTO `customer_faq_spanishes` (`id`, `cust_faqId`, `question`, `answer`, `created_at`, `updated_at`) VALUES
(27, 19, '¿Qué está incluido en una limpieza?', '<p>Dormitorio, sala de estar y &aacute;reas comunes</p>\r\n\r\n<ul>\r\n	<li>Desempolvar todas las superficies accesibles</li>\r\n	<li>Limpie todos los espejos y accesorios de vidrio</li>\r\n	<li>Limpie todas las superficies del piso</li>\r\n	<li>Sacar basura y reciclaje.</li>\r\n</ul>\r\n\r\n<p>Los ba&ntilde;os</p>\r\n\r\n<ul>\r\n	<li>Lave y desinfecte el inodoro, la ducha, la ba&ntilde;era y el lavabo</li>\r\n	<li>Desempolvar todas las superficies accesibles</li>\r\n	<li>Limpie todos los espejos y accesorios de vidrio</li>\r\n	<li>Limpie todas las superficies del piso</li>\r\n</ul>', '2019-05-20 02:39:44', '2019-05-20 02:43:53'),
(28, 18, '¿Qué profesional Handy vendrá a mi casa?', '<ul>\r\n	<li>Handy tiene una vasta red de limpiadores experimentados y con la mejor calificaci&oacute;n. En funci&oacute;n de la fecha y la hora de su solicitud, trabajamos para asignar el mejor profesional disponible.</li>\r\n	<li>&iquest;Te gusta trabajar con un profesional espec&iacute;fico? Agr&eacute;guelos a su Equipo Pro desde la aplicaci&oacute;n m&oacute;vil y se los solicitar&aacute; primero para todas las reservas futuras.</li>\r\n	<li>Recibir&aacute; un correo electr&oacute;nico con detalles sobre su profesional antes de su cita.</li>\r\n</ul>', '2019-05-20 02:40:24', '2019-05-20 02:40:24'),
(29, 12, '¿Puedo omitir o reprogramar reservas?', '<ul>\r\n	<li>Puede reprogramar cualquier reserva sin penalizaci&oacute;n, siempre que lo haga al menos 24 horas antes de la hora de inicio programada.</li>\r\n</ul>', '2019-05-20 02:40:46', '2019-05-20 02:40:46'),
(30, 11, '¿Cuánto cuestan los servicios de limpieza?', '<p>Esto depende del tama&ntilde;o de su casa: ingrese la cantidad de habitaciones y ba&ntilde;os que tiene en el formulario de arriba y le daremos un presupuesto instant&aacute;neo. Estamos seguros de que encontrar&aacute; precios extremadamente razonables dado el alto nivel de servicio que recibir&aacute; de su profesional.</p>', '2019-05-20 02:41:11', '2019-05-20 02:41:11'),
(31, 10, '¿Merecen la pena los servicios de limpieza de la casa?', '<p>S&iacute;, ciertamente lo es, &iexcl;asumiendo que eres el tipo de persona que le gusta venir a casa a un hogar hermoso y pr&iacute;stino sin haber levantado un dedo! Si usted es un profesional con poco tiempo que trabaja 16 horas al d&iacute;a, una mam&aacute; o un pap&aacute; ocupados que baraja a los ni&ntilde;os entre la guarder&iacute;a, la escuela y las pr&aacute;cticas de f&uacute;tbol, ​​o simplemente alguien que simplemente tiene mucho que hacer y muy poco tiempo para hacerlo , la limpieza de la casa puede estar en la parte inferior de su lista. Nadie quiere un hogar desordenado y, sin embargo, a nadie le gustan las tareas, aqu&iacute; es donde entra Handy.</p>\r\n\r\n<p>Tenemos las soluciones. Exige servicios de limpieza de casas de alta calidad y Handy lo pone en contacto con los mejores limpiadores de casas. En cuanto a los costos, usted est&aacute; buscando un servicio asequible y con una excelente relaci&oacute;n calidad-precio. Y seamos honestos: un par de horas adicionales con los ni&ntilde;os al final del d&iacute;a puede ser invaluable.</p>', '2019-05-20 02:41:38', '2019-05-20 02:41:38'),
(32, 9, '¿Cuánto propinas a un servicio de limpieza de la casa?', '<p>Nuestra pol&iacute;tica es que las propinas siempre son apreciadas por los profesionales que van m&aacute;s all&aacute;, pero nunca se requieren. La totalidad de la sugerencia se transmite al profesional: Handy no acepta ning&uacute;n porcentaje. Es una excelente manera de mostrar su aprecio por su profesional y un trabajo bien hecho.</p>\r\n\r\n<p>Adem&aacute;s, hemos encontrado que los profesionales suelen ser mucho m&aacute;s propensos a recoger sus trabajos y modificar sus propios horarios para cumplir con los suyos cuando los ha avisado en el pasado. Si su profesional trabaja arduamente o viaja por un largo camino para llegar a su casa con mal tiempo, es una buena manera de mostrar su agradecimiento. Las propinas se pueden hacer directamente a trav&eacute;s de la aplicaci&oacute;n en su tarjeta de cr&eacute;dito, igual que pag&oacute; por la reserva.</p>', '2019-05-20 02:42:04', '2019-05-20 02:42:04');

-- --------------------------------------------------------

--
-- Table structure for table `daily_scheduled_jobs`
--

CREATE TABLE `daily_scheduled_jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(11) NOT NULL,
  `Zipcode` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `daily_time` time NOT NULL,
  `customer_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `services` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `daily_scheduled_jobs`
--

INSERT INTO `daily_scheduled_jobs` (`id`, `customer_id`, `Zipcode`, `daily_time`, `customer_address`, `services`, `created_at`, `updated_at`) VALUES
(9, 10, '70008', '10:00:00', 'Michael I. Days 3756 Preston Street Wichita', '14,22,26', '2019-02-06 07:06:58', '2019-02-06 07:06:58'),
(10, 12, '70008', '12:30:00', 'Kelley A. Fleming 196 Woodside Circle Mobile, FL 36602 Phone:240-256-1942', '22,26', '2019-02-06 07:07:47', '2019-02-06 07:07:47'),
(11, 15, '60001', '14:30:00', 'Franklin Street Montgomery, AL 36104 Phone:126-632-2345', '22,26,14,23', '2019-02-06 07:08:34', '2019-02-06 07:08:34'),
(12, 10, '70008', '12:00:00', 'Carol J. Stephens 1635 Franklin5', '23,26', '2019-02-06 07:20:00', '2019-02-06 07:20:00'),
(29, 41, '50001', '19:11:00', 'gghhuhgff', '14,22,23', '2019-02-06 08:11:38', '2019-02-06 08:11:38'),
(30, 41, '50001', '19:15:00', 'hujjfffg', '22,23,26', '2019-02-06 08:15:12', '2019-02-06 08:15:12'),
(31, 41, '50000', '19:18:00', 'jujjkjk', '22,23,26', '2019-02-06 08:18:21', '2019-02-06 08:18:21'),
(32, 41, '50000', '19:19:00', 'jjkkhfvhjjj', '14,22', '2019-02-06 08:19:36', '2019-02-06 08:19:36'),
(33, 41, '50001', '19:20:00', 'nkkcdsgjnkkgrww', '14,22,23', '2019-02-06 08:20:24', '2019-02-06 08:20:24'),
(34, 41, '50001', '19:22:00', 'jikhfdcjjjjjfgyh', '14,22,23', '2019-02-06 08:22:37', '2019-02-06 08:22:37'),
(35, 41, '50001', '19:25:00', 'hhjjj', '22,23,26', '2019-02-06 08:25:16', '2019-02-06 08:25:16'),
(36, 48, '40001', '16:55:00', 'cleaner5@gmail.com', '14,22,26', '2019-02-25 00:28:39', '2019-02-25 00:28:39'),
(37, 16, '40003', '15:18:04', 'ROPAR', '14', '2019-03-15 02:18:33', '2019-03-15 02:18:33'),
(38, 16, '50009', '15:42:00', 'Ropar', '14', '2019-04-03 02:42:27', '2019-04-03 02:42:27'),
(39, 16, '50009', '15:50:22', 'Ropar', '26,14,22', '2019-04-09 04:50:41', '2019-04-09 04:50:41'),
(40, 16, '50009', '16:41:21', 'Ropar', '14,22,26', '2019-04-09 05:41:35', '2019-04-09 05:41:35'),
(41, 16, '50006', '14:16:07', 'hey', '22,14,23,26', '2019-05-20 01:16:29', '2019-05-20 01:16:29'),
(42, 6, '70006', '19:15:00', 'hhdhshhs', '14,22', '2019-06-01 05:15:29', '2019-06-01 05:15:29'),
(43, 6, '40002', '16:11:00', 'sdgegreg', '14,22,23,26', '2019-06-03 05:11:35', '2019-06-03 05:11:35'),
(44, 16, '40003', '13:48:00', 'fddd', '14,22,23,26', '2019-07-12 02:49:36', '2019-07-12 02:49:36');

-- --------------------------------------------------------

--
-- Table structure for table `discount_codes`
--

CREATE TABLE `discount_codes` (
  `id` int(10) UNSIGNED NOT NULL,
  `code_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `discount_codes`
--

INSERT INTO `discount_codes` (`id`, `code_name`, `discount`, `status`, `created_at`, `updated_at`) VALUES
(4, 'HoliSpecial', '15%', 1, '2019-03-20 01:59:43', '2019-03-20 02:35:05');

-- --------------------------------------------------------

--
-- Table structure for table `instant_bookings`
--

CREATE TABLE `instant_bookings` (
  `id` int(10) UNSIGNED NOT NULL,
  `cutomer_id` int(11) NOT NULL,
  `Parent_id` int(11) DEFAULT NULL,
  `zipcode` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `Services` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `instant_bookings`
--

INSERT INTO `instant_bookings` (`id`, `cutomer_id`, `Parent_id`, `zipcode`, `customer_address`, `date`, `time`, `Services`, `created_at`, `updated_at`) VALUES
(100, 2, NULL, '40003', 'jsisjsjsiw', '2019-01-24', '13:20:00', '14,22,23,26', '2019-01-24 02:20:43', '2019-01-24 02:20:43'),
(101, 4, NULL, '40003', 'hsuajjsw', '2019-01-24', '13:21:00', '14,22,23,26', '2019-01-24 02:21:29', '2019-01-24 02:21:29'),
(102, 6, NULL, '40003', 'jajwiwieije', '2019-01-24', '13:22:00', '14,22,23,26', '2019-01-24 02:22:33', '2019-01-24 02:22:33'),
(103, 10, NULL, '40003', 'hsjsjjsje', '2019-01-24', '13:35:00', '14,22,23,26', '2019-01-24 02:35:33', '2019-01-24 02:35:33'),
(104, 12, NULL, '40003', 'uuwhhshw', '2019-01-24', '13:50:00', '14,22,23,26', '2019-01-24 02:50:25', '2019-01-24 02:50:25'),
(106, 15, NULL, '40003', 'hsuauwuqiuw', '2019-01-24', '20:13:00', '14,22,23,26', '2019-01-24 09:13:13', '2019-01-24 09:13:13'),
(107, 16, NULL, '40003', 'baushsisis', '2019-01-24', '20:14:00', '14,22,23,26', '2019-01-24 09:14:28', '2019-01-24 09:14:28'),
(109, 41, NULL, '40003', 'Ropar', '2019-01-21', '17:16:00', '14,22,23,26', '2019-01-25 02:42:53', '2019-01-25 02:42:53'),
(121, 42, NULL, '40003', 'SMIT', '2019-02-26', '20:15:18', '14,22', '2019-01-31 06:15:40', '2019-01-31 06:15:40'),
(125, 45, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2019-02-04', '21:03:10', '14,22,23,26', '2019-01-31 07:03:27', '2019-01-31 07:03:27'),
(135, 46, NULL, '40003', 'dummy', '2019-03-30', '14:13:00', '14,22,23,26', '2019-02-04 03:14:04', '2019-02-04 03:14:04'),
(136, 48, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-02-04 03:14:30', '2019-02-04 03:14:30'),
(137, 2, NULL, '40003', 'drttt', '2019-02-04', '15:24:00', '14,22,23,26', '2019-02-04 04:24:24', '2019-02-04 04:24:24'),
(140, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-02-04 04:33:47', '2019-02-04 04:33:47'),
(141, 6, NULL, '40003', 'fyguhuj', '2019-02-04', '15:37:00', '14,22,23,26', '2019-02-04 04:37:26', '2019-02-04 04:37:26'),
(143, 10, NULL, '40003', 'cffghhgigihkhkhihiggigig', '2019-02-04', '15:43:00', '14,22,23,26', '2019-02-04 04:43:06', '2019-02-04 04:43:06'),
(144, 12, NULL, '40003', 'iikooo', '2019-02-04', '15:50:00', '14,22,23,26', '2019-02-04 04:50:56', '2019-02-04 04:50:56'),
(145, 15, NULL, '40003', 'ufigigigigig', '2019-02-04', '15:58:00', '14,22,23,26', '2019-02-04 04:58:17', '2019-02-04 04:58:17'),
(146, 16, NULL, '40003', 'bihohohoho', '2019-02-04', '16:00:00', '14,22,23,26', '2019-02-04 05:00:22', '2019-02-04 05:00:22'),
(147, 41, NULL, '40003', 'fggyuiiii', '2019-02-04', '16:19:00', '14,22,23,26', '2019-02-04 05:20:23', '2019-02-04 05:20:23'),
(148, 42, NULL, '40003', 'ugugiivivibii', '2019-02-04', '16:21:00', '14,22,23,26', '2019-02-04 05:22:05', '2019-02-04 05:22:05'),
(164, 45, 100, '50006', 'Nathan K. Flores 1516 Holt Street West Palm Beach.', '2019-01-23', '11:28:00', '14,22', '2019-02-21 02:54:16', '2019-02-21 02:54:16'),
(165, 46, 101, '70004', '581 Hornor Avenue\r\nVinita, OK 74301', '2019-04-20', '09:28:00', '14,22,26', '2019-02-21 05:14:11', '2019-02-21 05:14:11'),
(166, 48, 102, '70005', '1576 Freed Drive\r\nStockton, CA 95202', '2019-04-20', '09:28:00', '14,22,26,23', '2019-02-21 05:14:29', '2019-02-21 05:14:29'),
(167, 2, 103, '70006', '3002 Godfrey Street\r\nBeaverton, OR 97006', '2019-04-20', '12:05:00', '26,23', '2019-02-21 05:15:02', '2019-02-21 05:15:02'),
(168, 4, 104, '70007', '351 Fort Street\r\nEngelhard, NC 27824', '2019-03-25', '22:05:00', '14', '2019-02-21 05:15:53', '2019-02-21 05:15:53'),
(169, 12, NULL, '50006', '976 High Street \r\nLongwood, FL 32779', '2019-12-31', '15:10:00', '26', '2019-02-22 04:32:33', '2019-02-22 04:32:33'),
(170, 10, NULL, '70004', '667 Vine St. \r\nChicopee, MA 01020', '2019-12-29', '13:30:00', '23,26,22', '2019-02-22 05:26:19', '2019-02-22 05:26:19'),
(171, 6, NULL, '70005', '45 High Dr. \r\nLindenhurst, NY 11757', '2019-12-28', '09:15:00', '26,22', '2019-02-22 05:26:22', '2019-02-22 05:26:22'),
(172, 4, NULL, '70006', '9437 Dogwood Drive \r\nSyosset, NY 11791', '2019-12-27', '11:30:00', '14,23,26,22', '2019-02-22 05:26:24', '2019-02-22 05:26:24'),
(173, 2, NULL, '40003', '9442 SE. Bohemia St. \r\nGettysburg, PA 17325', '2019-12-26', '10:00:00', '14,23', '2019-02-22 05:26:26', '2019-02-22 05:26:26'),
(174, 16, NULL, '40003', 'Ropar', '2019-03-14', '11:18:25', '14,26', '2019-03-13 05:19:44', '2019-03-13 05:19:44'),
(175, 16, NULL, '40003', 'Ropar', '2019-03-14', '18:24:16', '22,14', '2019-03-13 05:24:34', '2019-03-13 05:24:34'),
(176, 16, NULL, '40003', 'Smit Ropar', '2019-03-14', '22:59:13', '23,14', '2019-03-13 06:59:34', '2019-03-13 06:59:34'),
(177, 16, NULL, '40003', 'Ropar', '2019-03-14', '23:28:56', '26', '2019-03-13 07:29:15', '2019-03-13 07:29:15'),
(178, 16, NULL, '40003', 'SMIt', '2019-03-16', '06:33:35', '14', '2019-03-13 07:33:57', '2019-03-13 07:33:57'),
(179, 16, NULL, '40003', 'SMIt', '2019-03-16', '06:33:35', '14', '2019-03-13 07:33:59', '2019-03-13 07:33:59'),
(180, 16, 107, '40003', 'baushsisis', '2019-03-15', '11:31:07', '14,22,23,26', '2019-03-14 08:30:33', '2019-03-14 08:30:33'),
(181, 16, 107, '40003', 'baushsisis', '2019-03-15', '11:17:40', '14,22,23,26', '2019-03-15 00:18:26', '2019-03-15 00:18:26'),
(182, 16, 107, '40003', 'baushsisis', '2019-04-15', '11:23:06', '14,22,23,26', '2019-03-15 00:22:11', '2019-03-15 00:22:11'),
(183, 16, NULL, '40003', 'Ropar', '2019-03-17', '17:32:00', '22', '2019-03-16 05:07:10', '2019-03-16 05:07:10'),
(184, 16, NULL, '40003', 'Ropar', '2019-03-17', '16:22:20', '26', '2019-03-16 05:22:42', '2019-03-16 05:22:42'),
(185, 16, 107, '40003', 'baushsisis', '2019-03-18', '13:26:33', '14,22,23,26', '2019-03-16 05:26:37', '2019-03-16 05:26:37'),
(186, 16, NULL, '50009', 'SMIT', '2019-04-03', '15:35:38', '22', '2019-04-03 02:36:23', '2019-04-03 02:36:23'),
(187, 16, NULL, '50009', 'Ropar', '2019-04-03', '17:44:55', '14', '2019-04-03 02:45:10', '2019-04-03 02:45:10'),
(188, 16, NULL, '50009', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,26', '2019-04-03 02:55:05', '2019-04-03 02:55:05'),
(312, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 04:34:45', '2019-04-09 04:34:45'),
(313, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 04:42:27', '2019-04-09 04:42:27'),
(314, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 04:43:36', '2019-04-09 04:43:36'),
(315, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 04:45:50', '2019-04-09 04:45:50'),
(316, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 05:05:53', '2019-04-09 05:05:53'),
(317, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 05:08:01', '2019-04-09 05:08:01'),
(318, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 05:09:00', '2019-04-09 05:09:00'),
(319, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 05:09:34', '2019-04-09 05:09:34'),
(320, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 05:09:39', '2019-04-09 05:09:39'),
(321, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 05:09:58', '2019-04-09 05:09:58'),
(322, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 05:10:18', '2019-04-09 05:10:18'),
(323, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 05:12:01', '2019-04-09 05:12:01'),
(324, 16, NULL, '50009', 'ROPAR', '2019-04-10', '18:15:16', '14,22,26', '2019-04-09 05:15:24', '2019-04-09 05:15:24'),
(325, 16, NULL, '50009', 'ROPAR', '2019-04-10', '19:21:43', '14,22,26', '2019-04-09 05:21:56', '2019-04-09 05:21:56'),
(326, 16, NULL, '50009', 'Smartitventures', '2019-04-09', '21:24:01', '14,22,26', '2019-04-09 05:24:14', '2019-04-09 05:24:14'),
(327, 16, NULL, '50009', 'SMARTITVENTURES', '2019-04-11', '16:24:27', '14,22,26', '2019-04-09 05:24:55', '2019-04-09 05:24:55'),
(328, 16, NULL, '50009', 'Ropar', '2019-04-11', '16:26:02', '14,22,26', '2019-04-09 05:26:22', '2019-04-09 05:26:22'),
(329, 16, NULL, '50009', 'Ropar', '2019-04-10', '16:47:25', '14,22,26', '2019-04-09 05:47:47', '2019-04-09 05:47:47'),
(330, 16, NULL, '50009', 'Ropar', '2019-04-10', '17:01:25', '14,22,26', '2019-04-09 06:01:43', '2019-04-09 06:01:43'),
(331, 16, NULL, '50009', 'Ropar', '2019-04-11', '17:06:03', '14,22,26', '2019-04-09 06:06:18', '2019-04-09 06:06:18'),
(332, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 06:10:45', '2019-04-09 06:10:45'),
(333, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 06:11:09', '2019-04-09 06:11:09'),
(334, 16, NULL, '50009', 'Ropar', '2019-04-11', '17:12:18', '14,22,26', '2019-04-09 06:12:36', '2019-04-09 06:12:36'),
(335, 16, NULL, '50009', 'Ropar', '2019-04-11', '19:13:30', '14,22,26', '2019-04-09 06:13:38', '2019-04-09 06:13:38'),
(336, 16, NULL, '50009', 'Ropar', '2019-04-11', '17:13:59', '14,22,26', '2019-04-09 06:14:15', '2019-04-09 06:14:15'),
(337, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 06:17:17', '2019-04-09 06:17:17'),
(338, 16, NULL, '50009', 'Ropar', '2019-04-12', '17:16:18', '14,22,23,26', '2019-04-09 06:17:55', '2019-04-09 06:17:55'),
(339, 16, NULL, '50009', 'Ropar', '2019-04-13', '18:18:47', '14,22,23,26', '2019-04-09 06:18:51', '2019-04-09 06:18:51'),
(340, 16, NULL, '50009', 'Ropar', '2019-04-09', '17:29:58', '14,22,26', '2019-04-09 06:30:14', '2019-04-09 06:30:14'),
(341, 16, NULL, '50009', 'Ropar', '2019-04-09', '17:29:58', '14,22,26', '2019-04-09 06:30:17', '2019-04-09 06:30:17'),
(342, 16, NULL, '50009', 'Ropar', '2019-04-10', '19:38:14', '14,22,26', '2019-04-09 08:38:27', '2019-04-09 08:38:27'),
(343, 16, NULL, '50009', 'Ropar', '2019-04-13', '19:38:46', '14,22,26', '2019-04-09 08:38:59', '2019-04-09 08:38:59'),
(344, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-09 08:40:11', '2019-04-09 08:40:11'),
(345, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-10 00:24:15', '2019-04-10 00:24:15'),
(346, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-10 00:27:06', '2019-04-10 00:27:06'),
(347, 16, 175, '40003', 'Ropar', '2019-04-10', '11:34:00', '22,14', '2019-04-10 00:34:07', '2019-04-10 00:34:07'),
(348, 16, NULL, '50009', 'ROPAR 2', '2019-12-20', '12:15:00', '14,23,22', '2019-04-10 01:07:30', '2019-04-10 01:07:30'),
(349, 16, NULL, '50009', 'Baji', '2019-12-20', '12:15:00', '14,23,22', '2019-04-10 01:08:03', '2019-04-10 01:08:03'),
(350, 16, NULL, '50009', 'Baji', '2019-12-20', '12:15:00', '14,23,22', '2019-04-10 01:18:27', '2019-04-10 01:18:27'),
(351, 16, NULL, '50009', 'Baji', '2019-12-20', '12:15:00', '14,23,22', '2019-04-10 01:18:41', '2019-04-10 01:18:41'),
(352, 16, NULL, '50009', 'Baji', '2019-12-20', '12:15:00', '14,23,22', '2019-04-10 01:18:48', '2019-04-10 01:18:48'),
(353, 16, NULL, '50009', 'Baji123456789', '2019-12-20', '12:15:00', '14,23,22', '2019-04-10 05:25:26', '2019-04-10 05:25:26'),
(354, 16, NULL, '50009', 'Ropar', '2019-04-12', '16:30:59', '14,22,26', '2019-04-10 05:31:11', '2019-04-10 05:31:11'),
(355, 16, NULL, '50009', 'Ropar', '2019-04-19', '16:31:35', '14,22,26', '2019-04-10 05:31:50', '2019-04-10 05:31:50'),
(356, 16, NULL, '50009', 'Baji123456789', '2019-12-20', '12:15:00', '14,23,22', '2019-04-11 04:37:07', '2019-04-11 04:37:07'),
(357, 16, 176, '40003', 'Smit Ropar', '2019-04-17', '16:12:50', '23,14', '2019-04-12 04:12:54', '2019-04-12 04:12:54'),
(358, 16, NULL, '50009', 'Baji123456789', '2019-12-20', '12:15:00', '14,23,22', '2019-04-15 05:32:02', '2019-04-15 05:32:02'),
(359, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 05:05:48', '2019-05-17 05:05:48'),
(360, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-05-17 05:26:51', '2019-05-17 05:26:51'),
(361, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23', '2019-05-17 05:29:01', '2019-05-17 05:29:01'),
(362, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-05-17 06:28:07', '2019-05-17 06:28:07'),
(363, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-05-17 06:31:55', '2019-05-17 06:31:55'),
(364, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-05-17 06:34:09', '2019-05-17 06:34:09'),
(365, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-05-17 06:36:07', '2019-05-17 06:36:07'),
(366, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-05-17 06:36:58', '2019-05-17 06:36:58'),
(367, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-05-17 06:39:43', '2019-05-17 06:39:43'),
(368, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-05-17 06:41:46', '2019-05-17 06:41:46'),
(369, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-05-17 06:42:58', '2019-05-17 06:42:58'),
(370, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-05-17 06:43:33', '2019-05-17 06:43:33'),
(371, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-05-17 06:44:45', '2019-05-17 06:44:45'),
(372, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-05-17 06:45:36', '2019-05-17 06:45:36'),
(373, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-05-17 06:46:31', '2019-05-17 06:46:31'),
(374, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 06:54:45', '2019-05-17 06:54:45'),
(375, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 06:55:16', '2019-05-17 06:55:16'),
(376, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 06:58:34', '2019-05-17 06:58:34'),
(377, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:05:03', '2019-05-17 07:05:03'),
(378, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:06:30', '2019-05-17 07:06:30'),
(379, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:07:12', '2019-05-17 07:07:12'),
(380, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:10:31', '2019-05-17 07:10:31'),
(381, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:13:01', '2019-05-17 07:13:01'),
(382, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:17:57', '2019-05-17 07:17:57'),
(383, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:19:42', '2019-05-17 07:19:42'),
(384, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:21:11', '2019-05-17 07:21:11'),
(385, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:22:41', '2019-05-17 07:22:41'),
(386, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:24:22', '2019-05-17 07:24:22'),
(387, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:24:43', '2019-05-17 07:24:43'),
(388, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:25:50', '2019-05-17 07:25:50'),
(389, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:26:30', '2019-05-17 07:26:30'),
(390, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:36:33', '2019-05-17 07:36:33'),
(391, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:44:30', '2019-05-17 07:44:30'),
(392, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:46:20', '2019-05-17 07:46:20'),
(393, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 07:51:23', '2019-05-17 07:51:23'),
(394, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 08:01:23', '2019-05-17 08:01:23'),
(395, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 08:03:54', '2019-05-17 08:03:54'),
(396, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-17 08:06:49', '2019-05-17 08:06:49'),
(397, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-18 00:31:17', '2019-05-18 00:31:17'),
(398, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-18 00:45:26', '2019-05-18 00:45:26'),
(399, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-18 02:24:36', '2019-05-18 02:24:36'),
(400, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-18 02:25:42', '2019-05-18 02:25:42'),
(401, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-18 02:29:38', '2019-05-18 02:29:38'),
(402, 2, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-18 03:01:41', '2019-05-18 03:01:41'),
(403, 2, NULL, '50006', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-05-18 03:02:41', '2019-05-18 03:02:41'),
(404, 16, NULL, '50006', 'hi', '2019-05-18', '20:10:42', '14,22,23,26', '2019-05-18 03:10:45', '2019-05-18 03:10:45'),
(405, 16, NULL, '50006', 'hey', '2019-05-18', '23:49:39', '14', '2019-05-18 04:50:15', '2019-05-18 04:50:15'),
(406, 16, NULL, '50006', 'hey', '2019-05-18', '20:08:46', '14,22', '2019-05-18 05:08:49', '2019-05-18 05:08:49'),
(407, 16, NULL, '50006', 'hey', '2019-05-18', '20:09:22', '14,22', '2019-05-18 05:09:30', '2019-05-18 05:09:30'),
(408, 16, NULL, '50006', 'hey', '2019-05-18', '17:10:00', '14', '2019-05-18 05:10:02', '2019-05-18 05:10:02'),
(409, 16, 175, '40003', 'Ropar', '2019-05-20', '14:16:48', '22,14', '2019-05-20 01:15:53', '2019-05-20 01:15:53'),
(410, 59, NULL, '40003', 'gfdvbhh', '2019-05-20', '15:26:00', '22,23,26', '2019-05-20 04:26:47', '2019-05-20 04:26:47'),
(411, 16, NULL, '50006', 'hey buddy', '2019-05-20', '17:10:34', '22,26', '2019-05-20 05:10:43', '2019-05-20 05:10:43'),
(412, 16, NULL, '50006', 'hey buddy', '2019-05-20', '19:11:54', '23,22', '2019-05-20 05:12:01', '2019-05-20 05:12:01'),
(413, 16, NULL, '70005', 'hey buddy I', '2019-05-20', '20:12:58', '23,26', '2019-05-20 07:13:03', '2019-05-20 07:13:03'),
(414, 62, NULL, '40003', 'hshshs', '2019-05-22', '15:00:00', '14,22,23,26', '2019-05-20 07:38:25', '2019-05-20 07:38:25'),
(415, 16, NULL, '50006', 'hey buddy I', '2019-05-21', '13:51:30', '22,23', '2019-05-21 00:51:35', '2019-05-21 00:51:35'),
(416, 16, 312, '50009', 'ROPAR 2', '2019-05-23', '16:23:37', '14,23,22', '2019-05-23 05:23:38', '2019-05-23 05:23:38'),
(417, 16, NULL, '70005', 'Ropar', '2019-05-24', '12:12:00', '22,23,26', '2019-05-24 01:12:56', '2019-05-24 01:12:56'),
(418, 16, NULL, '70005', 'hi', '2019-05-24', '14:13:21', '14,22,23', '2019-05-24 01:13:26', '2019-05-24 01:13:26'),
(419, 16, NULL, '70005', 'hdsisheig', '2019-05-24', '18:17:49', '22,23,26', '2019-05-24 07:18:23', '2019-05-24 07:18:23'),
(420, 16, NULL, '70005', 'Shridhar', '2019-05-24', '18:21:01', '26,23,22', '2019-05-24 07:21:16', '2019-05-24 07:21:16'),
(421, 16, NULL, '70005', 'hello', '2019-05-29', '17:15:46', '14,22', '2019-05-29 03:15:52', '2019-05-29 03:15:52'),
(422, 16, 175, '40003', 'Ropar', '2019-05-29', '18:16:17', '22,14', '2019-05-29 03:16:21', '2019-05-29 03:16:21'),
(423, 16, NULL, '40002', 'fhfjfh', '2019-06-01', '16:46:00', '22,23,26', '2019-06-01 05:46:25', '2019-06-01 05:46:25'),
(424, 6, 102, '40003', 'jajwiwieije', '2019-06-03', '15:34:00', '14,22,23,26', '2019-06-03 04:34:25', '2019-06-03 04:34:25'),
(425, 6, 102, '40003', 'jajwiwieije', '2019-06-03', '15:43:00', '14,22,23,26', '2019-06-03 04:43:43', '2019-06-03 04:43:43'),
(426, 6, 102, '40003', 'jajwiwieije', '2019-06-03', '15:47:00', '14,22,23,26', '2019-06-03 04:47:26', '2019-06-03 04:47:26'),
(427, 6, 102, '40003', 'jajwiwieije', '2019-06-03', '15:48:00', '14,22,23,26', '2019-06-03 04:48:40', '2019-06-03 04:48:40'),
(428, 6, 102, '40003', 'jajwiwieije', '2019-06-03', '15:48:00', '14,22,23,26', '2019-06-03 04:49:21', '2019-06-03 04:49:21'),
(429, 6, 102, '40003', 'jajwiwieije', '2019-06-03', '15:48:00', '14,22,23,26', '2019-06-03 04:49:36', '2019-06-03 04:49:36'),
(430, 6, 102, '40003', 'jajwiwieije', '2019-06-03', '15:50:00', '14,22,23,26', '2019-06-03 04:50:25', '2019-06-03 04:50:25'),
(431, 6, 102, '40003', 'jajwiwieije', '2019-06-03', '15:50:00', '14,22,23,26', '2019-06-03 04:50:38', '2019-06-03 04:50:38'),
(432, 6, 102, '40003', 'jajwiwieije', '2019-06-03', '15:51:00', '14,22,23,26', '2019-06-03 04:51:32', '2019-06-03 04:51:32'),
(433, 6, 102, '40003', 'jajwiwieije', '2019-06-03', '15:55:00', '14,22,23,26', '2019-06-03 04:55:45', '2019-06-03 04:55:45'),
(434, 6, 102, '40003', 'jajwiwieije', '2019-06-03', '16:03:00', '14,22,23,26', '2019-06-03 05:03:33', '2019-06-03 05:03:33'),
(435, 6, 102, '40003', 'jajwiwieije', '2019-06-03', '16:05:00', '14,22,23,26', '2019-06-03 05:06:03', '2019-06-03 05:06:03'),
(436, 6, 102, '40003', 'jajwiwieije', '2019-06-03', '16:07:00', '14,22,23,26', '2019-06-03 05:07:37', '2019-06-03 05:07:37'),
(437, 16, 175, '40003', 'Ropar', '2019-07-13', '13:49:00', '22,14', '2019-07-12 02:48:19', '2019-07-12 02:48:19'),
(438, 16, 175, '40003', 'Ropar', '2019-07-12', '13:48:24', '22,14', '2019-07-12 02:48:27', '2019-07-12 02:48:27'),
(439, 16, NULL, '50006', 'fghjkkk', '2019-07-12', '13:54:00', '14,22', '2019-07-12 02:54:10', '2019-07-12 02:54:10'),
(440, 16, NULL, '50006', 'GCB', '2019-07-12', '15:50:00', '14,22,23,26', '2019-07-12 02:55:20', '2019-07-12 02:55:20'),
(441, 16, NULL, '70002', 'gjgjfjfitit8t', '2019-07-16', '14:21:00', '14,22,23,26', '2019-07-15 02:22:06', '2019-07-15 02:22:06'),
(442, 16, NULL, '70002', 'vgyt', '2019-07-16', '13:25:00', '22,23,26', '2019-07-15 02:26:00', '2019-07-15 02:26:00'),
(443, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-20 07:19:32', '2019-08-20 07:19:32'),
(444, 69, NULL, '40003', 'dvxjh', '2019-08-20', '18:09:00', '14,22,23,26', '2019-08-20 07:20:15', '2019-08-20 07:20:15'),
(445, 77, NULL, '40003', 'test', '2019-08-20', '20:16:17', '14,22,23,26', '2019-08-20 07:21:43', '2019-08-20 07:21:43'),
(446, 77, NULL, '70005', 'test', '2019-08-20', '19:23:33', '14,22,23,26', '2019-08-20 07:25:14', '2019-08-20 07:25:14'),
(447, 77, NULL, '70005', 'test', '2019-08-20', '18:25:43', '23,26,22,14', '2019-08-20 07:26:15', '2019-08-20 07:26:15'),
(448, 77, NULL, '70005', 'test', '2019-08-20', '18:29:17', '14,22,23,26', '2019-08-20 07:29:43', '2019-08-20 07:29:43'),
(449, 77, NULL, '70005', 'test', '2019-08-20', '18:33:14', '14,22,23,26', '2019-08-20 07:33:24', '2019-08-20 07:33:24'),
(450, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-20 07:35:44', '2019-08-20 07:35:44'),
(451, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-20 07:44:53', '2019-08-20 07:44:53'),
(452, 69, NULL, '40003', 'dhdjsgsjh', '2019-08-22', '16:11:00', '14,22,23,26', '2019-08-21 04:12:21', '2019-08-21 04:12:21'),
(453, 69, NULL, '40003', 'fbdih', '2019-08-22', '16:13:00', '14,22,23,26', '2019-08-21 04:13:24', '2019-08-21 04:13:24'),
(454, 69, NULL, '40003', 'dhdjh', '2019-08-21', '15:15:00', '14,22,23,26', '2019-08-21 04:15:46', '2019-08-21 04:15:46'),
(455, 69, NULL, '40003', 'hdjfhh', '2019-08-21', '15:17:00', '14,22,23,26', '2019-08-21 04:19:58', '2019-08-21 04:19:58'),
(456, 69, NULL, '40003', 'fggh', '2019-08-21', '16:04:22', '26,23,22,14', '2019-08-21 05:04:52', '2019-08-21 05:04:52'),
(457, 69, NULL, '40003', 'chcg', '2019-08-22', '16:27:00', '14,22,23,26', '2019-08-21 05:27:52', '2019-08-21 05:27:52'),
(458, 69, NULL, '40003', 'dhdjdh', '2019-08-21', '16:28:00', '14,22,23,26', '2019-08-21 05:28:22', '2019-08-21 05:28:22'),
(459, 69, NULL, '70002', 'chgg', '2019-08-23', '16:09:00', '14,22,23,26', '2019-08-23 04:09:43', '2019-08-23 04:09:43'),
(460, 69, NULL, '70002', 'xvxg', '2019-08-23', '16:10:00', '14,22,23,26', '2019-08-23 04:11:01', '2019-08-23 04:11:01'),
(461, 69, NULL, '70002', 'shush', '2019-08-23', '16:13:33', '26,23,22,14', '2019-08-23 04:15:43', '2019-08-23 04:15:43'),
(462, 69, NULL, '70002', 'very', '2019-08-23', '15:15:58', '23,14,22,26', '2019-08-23 04:16:12', '2019-08-23 04:16:12'),
(463, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-23 05:03:04', '2019-08-23 05:03:04'),
(464, 69, NULL, '70002', 'xbxjdhdjs', '2019-08-23', '15:59:38', '26,23,22,14', '2019-08-23 05:06:02', '2019-08-23 05:06:02'),
(465, 69, NULL, '70002', 'xbxjdhdjs', '2019-08-23', '15:59:38', '26,23,22,14', '2019-08-23 05:06:02', '2019-08-23 05:06:02'),
(466, 69, NULL, '70002', 'xbxjdhdjs', '2019-08-23', '15:59:38', '26,23,22,14', '2019-08-23 05:06:04', '2019-08-23 05:06:04'),
(467, 69, NULL, '70002', 'xbxjdhdjs', '2019-08-23', '15:59:38', '26,23,22,14', '2019-08-23 05:06:04', '2019-08-23 05:06:04'),
(468, 69, NULL, '70002', 'xbxjdhdjs', '2019-08-23', '15:59:38', '26,23,22,14', '2019-08-23 05:06:05', '2019-08-23 05:06:05'),
(469, 69, NULL, '50009', 'rjdjg', '2019-08-23', '16:25:00', '14,22,23,26', '2019-08-23 05:15:00', '2019-08-23 05:15:00'),
(470, 69, NULL, '50009', 'hffhuf', '2019-08-23', '16:17:00', '14,22,23,26', '2019-08-23 05:17:14', '2019-08-23 05:17:14'),
(471, 69, NULL, '50009', 'cbxjdhdh', '2019-08-23', '16:07:09', '26,23,22,14', '2019-08-23 05:21:02', '2019-08-23 05:21:02'),
(472, 69, NULL, '50009', 'fhdhdh', '2019-08-23', '16:22:16', '26,23,14,22', '2019-08-23 05:22:32', '2019-08-23 05:22:32'),
(473, 69, NULL, '50009', 'test', '2019-08-23', '16:23:37', '14,22,23,26', '2019-08-23 05:23:57', '2019-08-23 05:23:57'),
(474, 69, NULL, '50009', 'test', '2019-08-23', '16:23:37', '14,22,23,26', '2019-08-23 05:23:58', '2019-08-23 05:23:58'),
(475, 85, NULL, '40003', 'hi', '2019-08-23', '17:32:08', '14,22,23,26', '2019-08-23 06:32:18', '2019-08-23 06:32:18'),
(476, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-23 06:35:15', '2019-08-23 06:35:15'),
(477, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-23 06:37:54', '2019-08-23 06:37:54'),
(478, 85, NULL, '40003', 'hey', '2019-08-23', '17:37:29', '14,22,23,26', '2019-08-23 06:38:04', '2019-08-23 06:38:04'),
(479, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-23 07:05:17', '2019-08-23 07:05:17'),
(480, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-23 07:10:10', '2019-08-23 07:10:10'),
(481, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14', '2019-08-23 07:11:56', '2019-08-23 07:11:56'),
(482, 4, NULL, '40003', 'dscsdcdsf', '2015-12-20', '12:15:00', '14', '2019-08-23 07:12:52', '2019-08-23 07:12:52'),
(483, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-23 07:13:10', '2019-08-23 07:13:10'),
(484, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-23 07:14:59', '2019-08-23 07:14:59'),
(485, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-23 07:24:54', '2019-08-23 07:24:54'),
(486, 85, NULL, '40003', 'hi', '2019-08-23', '18:28:25', '14,22,23,26', '2019-08-23 07:30:09', '2019-08-23 07:30:09'),
(487, 69, NULL, '70005', 'xhxjh', '2019-08-26', '19:23:00', '14,22,23,26', '2019-08-26 08:23:54', '2019-08-26 08:23:54'),
(488, 69, NULL, '70005', 'xhxjh', '2019-08-26', '19:23:00', '14,22,23,26', '2019-08-26 08:26:16', '2019-08-26 08:26:16'),
(489, 69, NULL, '70005', 'xjxihh', '2019-08-26', '19:27:00', '14,22,23,26', '2019-08-26 08:27:16', '2019-08-26 08:27:16'),
(490, 69, NULL, '70005', 'xhxoh', '2019-08-26', '19:30:00', '14,22,23,26', '2019-08-26 08:30:40', '2019-08-26 08:30:40'),
(491, 69, NULL, '70005', 'djdjg', '2019-08-26', '19:31:00', '14,22,23,26', '2019-08-26 08:31:06', '2019-08-26 08:31:06'),
(492, 69, NULL, '70005', 'dhdih', '2019-08-26', '19:31:00', '14,22,23,26', '2019-08-26 08:31:32', '2019-08-26 08:31:32'),
(493, 69, NULL, '40003', 'sbzjh', '2019-08-26', '19:46:00', '14,22,23,26', '2019-08-26 08:46:30', '2019-08-26 08:46:30'),
(494, 69, NULL, '40003', 'cgju', '2019-08-27', '00:38:00', '14,22,23,26', '2019-08-27 00:39:03', '2019-08-27 00:39:03'),
(495, 69, NULL, '40003', 'xvxjg', '2019-08-27', '11:39:00', '14,22,23,26', '2019-08-27 00:39:36', '2019-08-27 00:39:36'),
(496, 69, NULL, '40003', 'fgh', '2019-08-27', '11:41:00', '14,22,23,26', '2019-08-27 00:41:48', '2019-08-27 00:41:48'),
(497, 69, NULL, '40003', 'fgdjh', '2019-08-27', '11:46:00', '14,22,23,26', '2019-08-27 00:46:30', '2019-08-27 00:46:30'),
(498, 69, NULL, '40003', 'fgdjh', '2019-08-27', '11:46:00', '14,22,23,26', '2019-08-27 00:46:30', '2019-08-27 00:46:30'),
(499, 69, NULL, '50009', 'xhxkdhh', '2019-08-27', '14:58:00', '14,22,23,26', '2019-08-27 03:58:42', '2019-08-27 03:58:42'),
(500, 69, NULL, '50009', 'djxkhhu', '2019-08-27', '15:59:00', '14,22,23,26', '2019-08-27 03:59:32', '2019-08-27 03:59:32'),
(501, 69, NULL, '50009', 'h jhh', '2019-08-27', '15:59:00', '14,22,23,26', '2019-08-27 03:59:54', '2019-08-27 03:59:54'),
(502, 69, NULL, '50009', 'chcjxj', '2019-08-27', '15:55:00', '14,22,23,26', '2019-08-27 04:00:53', '2019-08-27 04:00:53'),
(503, 69, NULL, '50009', 'djdkdhdj', '2019-08-27', '15:55:00', '14,22,23,26', '2019-08-27 04:02:29', '2019-08-27 04:02:29'),
(504, 69, NULL, '50009', 'jddidu', '2019-08-27', '15:06:00', '14,22,23,26', '2019-08-27 04:06:52', '2019-08-27 04:06:52'),
(505, 69, NULL, '50009', 'fhfjj', '2019-08-27', '15:55:00', '14,22,23,26', '2019-08-27 04:09:45', '2019-08-27 04:09:45'),
(506, 69, NULL, '50009', 'fjfih', '2019-08-27', '15:55:00', '14,22,23,26', '2019-08-27 04:14:47', '2019-08-27 04:14:47'),
(507, 69, NULL, '50009', 'fhfjfh', '2019-08-27', '15:16:00', '14,22,23,26', '2019-08-27 04:16:45', '2019-08-27 04:16:45'),
(508, 69, NULL, '50009', 'fjfifui', '2019-08-27', '15:20:00', '14,22,23,26', '2019-08-27 04:20:30', '2019-08-27 04:20:30'),
(509, 69, NULL, '50009', 'xjxixhj', '2019-08-27', '15:55:00', '14,22,23,26', '2019-08-27 04:21:57', '2019-08-27 04:21:57'),
(510, 69, NULL, '50009', 'chcjchh', '2019-08-27', '15:55:00', '14,22,23,26', '2019-08-27 04:22:42', '2019-08-27 04:22:42'),
(511, 69, NULL, '50009', 'dhdidfu', '2019-08-27', '15:55:00', '14,22,23,26', '2019-08-27 04:23:07', '2019-08-27 04:23:07'),
(512, 69, NULL, '50009', 'dhdidyu', '2019-08-27', '15:54:00', '14,22,23,26', '2019-08-27 04:23:41', '2019-08-27 04:23:41'),
(513, 69, NULL, '50009', 'xhxkh', '2019-08-27', '16:55:00', '14,22,23,26', '2019-08-27 05:40:03', '2019-08-27 05:40:03'),
(514, 69, NULL, '50009', 'dhfiduu', '2019-08-27', '16:55:00', '14,22,23,26', '2019-08-27 05:41:09', '2019-08-27 05:41:09'),
(515, 69, NULL, '50009', 'gddhfhfhhfhf', '2019-08-27', '16:55:00', '14,22,23,26', '2019-08-27 05:49:19', '2019-08-27 05:49:19'),
(516, 69, NULL, '50009', 'dhdidh', '2019-08-27', '16:51:00', '14,22,23,26', '2019-08-27 05:51:10', '2019-08-27 05:51:10'),
(517, 69, NULL, '50009', 'ghhggtfr', '2019-08-27', '17:00:00', '14,22,23,26', '2019-08-27 05:58:23', '2019-08-27 05:58:23'),
(518, 69, NULL, '50009', 'dhdidyu', '2019-08-27', '17:55:00', '14,22,23,26', '2019-08-27 06:04:41', '2019-08-27 06:04:41'),
(519, 87, NULL, '50009', 'hxicgi', '2019-08-27', '17:55:00', '14,22,23,26', '2019-08-27 06:10:37', '2019-08-27 06:10:37'),
(520, 87, NULL, '50009', 'dhdidydiy', '2019-08-27', '17:55:00', '14,22,23,26', '2019-08-27 06:27:17', '2019-08-27 06:27:17'),
(521, 92, NULL, '50009', 'abc', '2019-08-28', '18:41:00', '14,22,23,26', '2019-08-28 02:41:36', '2019-08-28 02:41:36'),
(522, 92, NULL, '50006', 'xgsiduu', '2019-08-28', '13:44:00', '14,22,23,26', '2019-08-28 02:44:25', '2019-08-28 02:44:25'),
(523, 92, NULL, '50009', 'dhdiduu', '2019-08-28', '13:44:00', '14,22,23,26', '2019-08-28 02:44:41', '2019-08-28 02:44:41'),
(524, 92, NULL, '50006', 'abc', '2019-08-28', '18:14:00', '22', '2019-08-28 04:14:16', '2019-08-28 04:14:16'),
(525, 92, NULL, '50006', 'abc', '2019-08-29', '15:15:00', '14,22,23,26', '2019-08-28 04:15:44', '2019-08-28 04:15:44'),
(526, 92, NULL, '50006', 'xhxig', '2019-08-28', '15:17:00', '14,22,23,26', '2019-08-28 04:17:09', '2019-08-28 04:17:09'),
(527, 92, NULL, '70005', 'xjxig', '2019-08-28', '15:19:00', '14,22,23,26', '2019-08-28 04:19:37', '2019-08-28 04:19:37'),
(528, 92, NULL, '70005', 'dhdidh', '2019-08-28', '15:19:00', '14,22,23,26', '2019-08-28 04:21:49', '2019-08-28 04:21:49'),
(529, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-28 04:25:43', '2019-08-28 04:25:43'),
(530, 4, NULL, '40003', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-28 04:27:17', '2019-08-28 04:27:17'),
(531, 92, NULL, '70005', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2015-12-20', '12:15:00', '14,23,26,22', '2019-08-28 04:34:04', '2019-08-28 04:34:04'),
(532, 69, NULL, '50007', 'xjxjdgdudh', '2019-08-28', '17:46:00', '14,22', '2019-08-28 06:46:35', '2019-08-28 06:46:35'),
(533, 69, NULL, '50007', 'fhdhxhxh', '2019-08-28', '18:15:00', '14,22,23,26', '2019-08-28 07:15:17', '2019-08-28 07:15:17'),
(534, 101, NULL, '40001', 'abc', '2019-08-29', '19:10:00', '14,22,23,26', '2019-08-28 08:10:51', '2019-08-28 08:10:51'),
(535, 101, NULL, '40001', 'abc', '2019-08-29', '19:11:00', '14,22,23,26', '2019-08-28 08:11:25', '2019-08-28 08:11:25'),
(536, 101, 534, '40001', 'abc', '2019-08-29', '20:17:00', '14,22,23,26', '2019-08-28 08:17:27', '2019-08-28 08:17:27'),
(537, 101, 534, '40001', 'abc', '2019-08-28', '19:17:44', '14,22,23,26', '2019-08-28 08:17:45', '2019-08-28 08:17:45'),
(538, 69, NULL, '40001', 'dhxjxhxjh', '2019-08-29', '11:52:00', '14,22,23,26', '2019-08-29 00:53:00', '2019-08-29 00:53:00'),
(539, 69, 454, '40003', 'dhdjh', '2019-08-29', '11:54:37', '14,22,23,26', '2019-08-29 00:54:53', '2019-08-29 00:54:53'),
(540, 69, 538, '40001', 'dhxjxhxjh', '2019-08-29', '11:55:19', '14,22,23,26', '2019-08-29 00:55:30', '2019-08-29 00:55:30'),
(541, 69, 538, '40001', 'dhxjxhxjh', '2019-08-29', '12:00:42', '14,22,23,26', '2019-08-29 01:00:48', '2019-08-29 01:00:48'),
(542, 69, 538, '40001', 'dhxjxhxjh', '2019-08-29', '12:02:05', '14,22,23,26', '2019-08-29 01:03:05', '2019-08-29 01:03:05'),
(543, 69, NULL, '40001', 'vjju', '2019-08-29', '12:05:00', '14,22,23,26', '2019-08-29 01:05:37', '2019-08-29 01:05:37'),
(544, 69, NULL, '40001', 'cbfjfjfimtitu', '2019-08-29', '12:12:00', '14,22,23,26', '2019-08-29 01:12:35', '2019-08-29 01:12:35'),
(545, 69, NULL, '40001', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2019-08-29', '12:17:00', '14,23,26,22', '2019-08-29 01:16:00', '2019-08-29 01:16:00'),
(546, 69, NULL, '40001', 'Nathan K. Flores 1516 Holt Street West Palm Beach', '2019-08-29', '12:21:00', '14,23,26,22', '2019-08-29 01:19:22', '2019-08-29 01:19:22'),
(547, 69, 538, '40001', 'dhxjxhxjh', '2019-01-23', '11:28:00', '14,22,23,26', '2019-08-29 01:33:42', '2019-08-29 01:33:42'),
(548, 69, 538, '40001', 'dhxjxhxjh', '2019-01-23', '11:28:00', '14,22,23,26', '2019-08-29 01:34:42', '2019-08-29 01:34:42'),
(549, 69, 538, '40001', 'dhxjxhxjh', '2019-08-29', '12:29:42', '14,22,23,26', '2019-08-29 01:36:00', '2019-08-29 01:36:00'),
(550, 69, 538, '40001', 'dhxjxhxjh', '2019-01-23', '11:28:00', '14,22,23,26', '2019-08-29 01:36:17', '2019-08-29 01:36:17'),
(551, 69, 538, '40001', 'dhxjxhxjh', '2019-01-23', '11:28:00', '14,22,23,26', '2019-08-29 01:36:33', '2019-08-29 01:36:33'),
(552, 92, NULL, '70007', 'abc', '2019-08-30', '14:00:00', '22', '2019-08-29 01:48:52', '2019-08-29 01:48:52'),
(553, 92, NULL, '70007', 'xhdkh', '2019-08-29', '12:50:00', '23', '2019-08-29 01:50:08', '2019-08-29 01:50:08'),
(554, 92, 553, '70007', 'xhdkh', '2019-08-29', '12:51:18', '23', '2019-08-29 01:51:19', '2019-08-29 01:51:19'),
(555, 92, NULL, '70007', 'abab', '2019-08-30', '12:52:00', '23', '2019-08-29 01:52:07', '2019-08-29 01:52:07'),
(556, 92, 555, '70007', 'abab', '2019-08-29', '12:59:05', '23', '2019-08-29 01:59:13', '2019-08-29 01:59:13'),
(557, 92, 555, '70007', 'abab', '2019-08-29', '12:59:23', '23', '2019-08-29 01:59:24', '2019-08-29 01:59:24'),
(558, 92, NULL, '70007', 'abv', '2019-08-31', '13:01:00', '23', '2019-08-29 02:01:39', '2019-08-29 02:01:39'),
(559, 92, NULL, '70007', 'abvn', '2019-08-29', '13:02:00', '23', '2019-08-29 02:02:13', '2019-08-29 02:02:13'),
(560, 92, NULL, '70007', 'dhdiu', '2019-08-29', '13:02:00', '26', '2019-08-29 02:02:42', '2019-08-29 02:02:42'),
(561, 92, NULL, '70007', 'bftj', '2019-08-29', '13:03:00', '22', '2019-08-29 02:03:16', '2019-08-29 02:03:16'),
(562, 92, NULL, '70007', 'rjdidhi', '2019-08-29', '13:06:00', '14,22,23,26', '2019-08-29 02:06:21', '2019-08-29 02:06:21'),
(563, 92, NULL, '70007', 'dhjddhj', '2019-08-29', '13:06:00', '14,23,26', '2019-08-29 02:07:04', '2019-08-29 02:07:04'),
(564, 92, NULL, '70007', 'xhxjxhu', '2019-08-29', '13:11:00', '14,22,23,26', '2019-08-29 02:11:41', '2019-08-29 02:11:41'),
(565, 92, NULL, '70007', 'dhdidhi', '2019-08-29', '13:13:00', '14,23,26', '2019-08-29 02:13:17', '2019-08-29 02:13:17'),
(566, 92, NULL, '70007', 'dhddj', '2019-08-29', '13:13:00', '23,26', '2019-08-29 02:13:42', '2019-08-29 02:13:42'),
(567, 92, NULL, '70001', 'dhdidhud', '2019-08-29', '13:15:00', '14', '2019-08-29 02:16:23', '2019-08-29 02:16:23'),
(568, 92, NULL, '70001', 'shshsh', '2019-08-29', '13:17:00', '23,26', '2019-08-29 02:17:11', '2019-08-29 02:17:11'),
(569, 92, 568, '70001', 'shshsh', '2019-08-29', '13:17:55', '23,26', '2019-08-29 02:18:00', '2019-08-29 02:18:00'),
(570, 92, NULL, '70001', 'shshs', '2019-08-29', '13:25:00', '23', '2019-08-29 02:25:29', '2019-08-29 02:25:29'),
(571, 92, 570, '70001', 'shshs', '2019-08-29', '13:26:50', '23', '2019-08-29 02:26:52', '2019-08-29 02:26:52'),
(572, 92, 570, '70001', 'shshs', '2019-08-29', '13:37:09', '23', '2019-08-29 02:37:17', '2019-08-29 02:37:17'),
(574, 92, NULL, '70001', 'ababa', '2019-08-29', '13:46:00', '14', '2019-08-29 02:46:18', '2019-08-29 02:46:18'),
(575, 92, 574, '70001', 'ababa', '2019-08-29', '13:47:35', '14', '2019-08-29 02:47:36', '2019-08-29 02:47:36'),
(576, 92, NULL, '70001', 'djdidhi', '2019-08-29', '13:55:00', '23,26', '2019-08-29 02:55:49', '2019-08-29 02:55:49'),
(577, 92, 575, '70001', 'ababa', '2019-08-29', '14:00:00', '14', '2019-08-29 03:10:44', '2019-08-29 03:10:44'),
(578, 92, 574, '70001', 'ababa', '2019-08-29', '14:13:21', '14', '2019-08-29 03:13:23', '2019-08-29 03:13:23'),
(579, 92, 574, '70001', 'ababa', '2019-08-29', '14:13:35', '14', '2019-08-29 03:13:36', '2019-08-29 03:13:36'),
(580, 92, NULL, '70002', 'dhdudhdu', '2019-08-29', '17:12:00', '14,22,23,26', '2019-08-29 06:12:47', '2019-08-29 06:12:47'),
(581, 92, NULL, '70002', 'uthhsgggegw', '2019-08-29', '17:14:00', '14,22,23,26', '2019-08-29 06:14:25', '2019-08-29 06:14:25'),
(582, 92, NULL, '70002', 'bfjjfjd', '2019-08-29', '17:15:00', '23,26', '2019-08-29 06:15:43', '2019-08-29 06:15:43'),
(583, 69, NULL, '70002', 'djdidy8', '2019-08-29', '17:17:00', '26', '2019-08-29 06:17:17', '2019-08-29 06:17:17'),
(584, 69, NULL, '70002', 'rhdidy', '2019-08-29', '17:20:00', '22', '2019-08-29 06:20:36', '2019-08-29 06:20:36'),
(585, 69, NULL, '70002', 'fufufuf', '2019-08-29', '17:23:00', '23', '2019-08-29 06:24:08', '2019-08-29 06:24:08'),
(586, 69, NULL, '70009', 'djdih', '2019-08-30', '15:16:00', '26', '2019-08-30 04:17:42', '2019-08-30 04:17:42'),
(587, 107, NULL, '50006', 'Drive way , New Castle', '2020-02-28', '12:06:28', '14,22,23', '2020-02-28 01:06:54', '2020-02-28 01:06:54'),
(588, 107, NULL, '50006', 'txoodggks', '2020-02-28', '12:17:57', '14,22,23', '2020-02-28 01:18:13', '2020-02-28 01:18:13'),
(589, 109, NULL, '40003', 'abc', '2020-02-28', '15:29:28', '14,22', '2020-02-28 04:30:25', '2020-02-28 04:30:25'),
(590, 109, NULL, '40003', 'abc', '2020-02-28', '15:29:28', '14,22', '2020-02-28 04:31:32', '2020-02-28 04:31:32'),
(591, 107, NULL, '40003', 'hehg ehehhejyj', '2020-02-28', '15:44:49', '14,22,23', '2020-02-28 04:45:22', '2020-02-28 04:45:22'),
(592, 107, NULL, '40003', 'hshakanKkKmMM', '2020-02-28', '15:50:53', '14,22,23', '2020-02-28 04:51:28', '2020-02-28 04:51:28'),
(593, 107, NULL, '70005', 'gjbklhgcf', '2020-02-28', '15:53:29', '14,22,23,26', '2020-02-28 04:53:41', '2020-02-28 04:53:41'),
(594, 107, NULL, '70005', 'nfsjeykekyekyrkyky', '2020-02-28', '15:55:24', '14,22,23,26', '2020-02-28 04:55:48', '2020-02-28 04:55:48');

-- --------------------------------------------------------

--
-- Table structure for table `instant_schedule_jobs`
--

CREATE TABLE `instant_schedule_jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `job_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `cutomer_id` int(11) NOT NULL,
  `status` enum('0','1','2','3') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `instant_schedule_jobs`
--

INSERT INTO `instant_schedule_jobs` (`id`, `job_id`, `provider_id`, `cutomer_id`, `status`, `created_at`, `updated_at`) VALUES
(84, 100, 44, 2, '1', '2019-01-24 02:22:53', '2019-01-24 02:22:53'),
(85, 102, 44, 6, '2', '2019-01-24 02:31:47', '2019-08-21 06:57:37'),
(86, 101, 7, 4, '2', '2019-01-24 02:35:39', '2019-02-01 04:58:06'),
(87, 103, 37, 10, '1', '2019-01-24 02:51:33', '2019-01-24 02:51:33'),
(88, 104, 49, 12, '1', '2019-01-24 02:55:22', '2019-01-24 02:55:22'),
(90, 106, 49, 15, '1', '2019-01-24 09:13:42', '2019-01-24 09:13:42'),
(91, 107, 49, 16, '2', '2019-01-24 09:14:49', '2019-04-03 02:57:00'),
(92, 109, 7, 41, '0', '2019-01-25 02:43:30', '2019-02-01 05:07:34'),
(124, 121, 11, 42, '1', '2019-01-31 06:55:00', '2019-01-31 06:55:00'),
(159, 135, 3, 46, '1', '2019-02-04 03:14:12', '2019-02-04 03:14:12'),
(160, 136, 49, 48, '3', '2019-02-04 03:14:43', '2019-02-04 03:14:43'),
(161, 140, 49, 4, '3', '2019-02-04 04:34:00', '2019-02-04 04:34:00'),
(162, 137, 40, 2, '1', '2019-02-04 04:34:05', '2019-02-04 04:34:05'),
(163, 141, 37, 6, '0', '2019-02-04 04:41:36', '2019-02-04 04:41:36'),
(164, 143, 37, 10, '0', '2019-02-04 04:43:16', '2019-02-04 04:43:16'),
(165, 144, 3, 12, '0', '2019-02-04 04:52:40', '2019-02-04 04:52:40'),
(166, 145, 11, 15, '2', '2019-02-04 04:58:33', '2019-03-13 06:29:17'),
(167, 146, 5, 16, '2', '2019-02-04 05:00:31', '2019-03-13 08:11:14'),
(168, 147, 5, 41, '1', '2019-02-04 05:20:33', '2019-02-04 05:20:33'),
(169, 148, 43, 42, '2', '2019-02-04 05:22:13', '2019-02-04 05:22:13'),
(181, 125, 37, 45, '0', '2019-02-18 05:35:23', '2019-02-18 05:35:23'),
(182, 175, 2, 16, '1', '2019-03-13 05:27:19', '2019-03-13 06:55:43'),
(183, 176, 49, 16, '1', '2019-03-13 07:02:30', '2019-03-13 07:51:13'),
(184, 183, 2, 16, '1', '2019-03-16 05:08:16', '2019-04-09 06:32:14'),
(185, 184, 49, 16, '2', '2019-03-16 05:24:08', '2019-04-10 05:53:20'),
(186, 186, 49, 16, '2', '2019-04-03 02:42:39', '2019-04-03 02:57:13'),
(187, 187, 49, 16, '2', '2019-04-03 08:18:37', '2019-04-10 01:12:26'),
(188, 188, 49, 16, '2', '2019-04-03 08:19:28', '2019-04-09 05:22:50'),
(197, 312, 49, 16, '1', '2019-04-09 04:35:06', '2019-04-10 06:09:00'),
(198, 314, 49, 16, '2', '2019-04-09 04:43:41', '2019-04-10 06:10:04'),
(199, 315, 49, 16, '2', '2019-04-09 04:46:05', '2019-04-10 06:53:55'),
(200, 317, 49, 16, '2', '2019-04-09 05:08:12', '2019-04-10 08:30:06'),
(201, 323, 49, 16, '1', '2019-04-09 05:12:17', '2019-04-10 06:36:36'),
(202, 324, 49, 16, '2', '2019-04-09 05:15:34', '2019-04-10 23:56:48'),
(203, 328, 49, 16, '2', '2019-04-09 05:26:39', '2019-04-11 00:03:42'),
(204, 329, 49, 16, '2', '2019-04-09 05:48:02', '2019-05-18 05:10:27'),
(205, 330, 49, 16, '3', '2019-04-09 06:01:57', '2019-04-09 06:01:57'),
(206, 331, 49, 16, '2', '2019-04-09 06:06:33', '2019-05-20 07:13:46'),
(207, 336, 49, 16, '3', '2019-04-09 06:14:40', '2019-04-10 07:19:52'),
(208, 337, 49, 16, '2', '2019-04-09 06:17:33', '2019-04-10 07:32:55'),
(209, 339, 49, 16, '2', '2019-04-09 06:19:16', '2019-05-23 04:52:13'),
(210, 340, 49, 16, '2', '2019-04-09 06:30:23', '2019-05-23 23:58:45'),
(211, 344, 49, 16, '3', '2019-04-09 08:41:14', '2019-04-09 08:41:14'),
(212, 345, 49, 16, '3', '2019-04-10 00:24:21', '2019-04-10 00:24:21'),
(213, 348, 49, 16, '3', '2019-04-10 01:07:37', '2019-04-10 01:07:37'),
(214, 349, 49, 16, '2', '2019-04-10 01:08:13', '2019-07-02 01:17:04'),
(215, 352, 49, 16, '2', '2019-04-10 01:18:56', '2019-04-10 08:20:55'),
(218, 353, 49, 16, '1', '2019-05-01 00:36:28', '2019-07-15 02:53:04'),
(219, 389, 49, 2, '0', '2019-05-18 00:45:42', '2019-05-18 00:45:42'),
(220, 403, 49, 2, '2', '2019-05-18 03:04:43', '2019-07-02 01:17:12'),
(221, 398, 49, 2, '0', '2019-05-18 03:06:36', '2019-05-18 03:06:36'),
(222, 404, 49, 16, '0', '2019-05-18 03:10:54', '2019-05-18 03:10:54'),
(223, 405, 49, 16, '2', '2019-05-18 04:50:39', '2019-07-18 05:18:12'),
(224, 406, 49, 16, '0', '2019-05-18 05:08:56', '2019-05-18 05:08:56'),
(225, 411, 49, 16, '0', '2019-05-20 05:10:49', '2019-05-20 05:10:49'),
(226, 412, 49, 16, '0', '2019-05-20 05:12:09', '2019-05-20 05:12:09'),
(227, 413, 49, 16, '0', '2019-05-20 07:13:08', '2019-05-20 07:13:08'),
(228, 419, 49, 16, '0', '2019-05-24 07:19:13', '2019-05-24 07:19:13'),
(229, 420, 49, 16, '0', '2019-05-24 07:22:58', '2019-05-24 07:22:58'),
(230, 421, 49, 16, '0', '2019-05-29 03:15:58', '2019-05-29 03:15:58'),
(231, 452, 80, 69, '2', '2019-08-21 04:24:36', '2019-08-21 04:44:24'),
(232, 453, 80, 69, '2', '2019-08-21 04:25:07', '2019-08-23 04:04:06'),
(233, 454, 80, 69, '1', '2019-08-21 04:25:08', '2019-08-21 05:05:51'),
(234, 456, 80, 69, '2', '2019-08-21 05:05:05', '2019-08-26 08:38:05'),
(235, 469, 83, 69, '2', '2019-08-23 05:16:41', '2019-08-26 08:32:20'),
(236, 470, 83, 69, '2', '2019-08-23 05:17:39', '2019-08-26 08:37:58'),
(237, 471, 83, 69, '2', '2019-08-23 05:21:42', '2019-08-26 08:38:13'),
(238, 472, 83, 69, '2', '2019-08-23 05:22:36', '2019-08-26 08:38:02'),
(239, 473, 83, 69, '2', '2019-08-23 05:24:05', '2019-08-27 00:49:46'),
(240, 474, 83, 69, '2', '2019-08-23 05:24:10', '2019-08-27 00:49:49'),
(241, 474, 83, 69, '0', '2019-08-23 05:24:10', '2019-08-23 05:24:10'),
(242, 492, 49, 69, '0', '2019-08-26 08:32:02', '2019-08-26 08:32:02'),
(243, 491, 49, 69, '0', '2019-08-26 08:32:04', '2019-08-26 08:32:04'),
(244, 490, 49, 69, '0', '2019-08-26 08:32:08', '2019-08-26 08:32:08'),
(245, 493, 80, 69, '0', '2019-08-26 08:46:59', '2019-08-26 08:46:59'),
(246, 497, 80, 69, '0', '2019-08-27 00:46:41', '2019-08-27 00:46:41'),
(247, 498, 80, 69, '2', '2019-08-27 00:46:41', '2019-08-27 00:50:47'),
(248, 505, 86, 69, '2', '2019-08-27 04:10:00', '2019-08-27 05:04:51'),
(249, 506, 86, 69, '2', '2019-08-27 04:15:07', '2019-08-27 05:04:42'),
(250, 507, 86, 69, '2', '2019-08-27 04:16:58', '2019-08-27 05:04:18'),
(251, 508, 86, 69, '2', '2019-08-27 04:20:36', '2019-08-27 05:04:37'),
(252, 509, 86, 69, '2', '2019-08-27 04:22:26', '2019-08-27 05:04:33'),
(253, 510, 86, 69, '2', '2019-08-27 04:22:47', '2019-08-27 05:04:29'),
(254, 512, 86, 69, '2', '2019-08-27 04:23:50', '2019-08-27 05:04:55'),
(255, 513, 86, 69, '0', '2019-08-27 05:40:13', '2019-08-27 05:40:13'),
(256, 514, 86, 69, '0', '2019-08-27 05:41:17', '2019-08-27 05:41:17'),
(257, 515, 86, 69, '0', '2019-08-27 05:49:20', '2019-08-27 05:49:20'),
(258, 516, 86, 69, '0', '2019-08-27 05:51:18', '2019-08-27 05:51:18'),
(259, 517, 86, 69, '0', '2019-08-27 05:58:27', '2019-08-27 05:58:27'),
(260, 518, 86, 69, '0', '2019-08-27 06:04:48', '2019-08-27 06:04:48'),
(261, 520, 88, 87, '0', '2019-08-27 06:27:22', '2019-08-27 06:27:22'),
(262, 528, 94, 92, '0', '2019-08-28 04:25:02', '2019-08-28 04:25:02'),
(263, 532, 100, 69, '1', '2019-08-28 06:46:40', '2019-08-28 07:09:11'),
(264, 533, 100, 69, '0', '2019-08-28 07:15:24', '2019-08-28 07:15:24'),
(265, 534, 102, 101, '1', '2019-08-28 08:11:33', '2019-08-28 08:16:09'),
(266, 535, 102, 101, '0', '2019-08-28 08:11:35', '2019-08-28 08:11:35'),
(267, 538, 102, 69, '1', '2019-08-29 00:53:11', '2019-08-29 00:54:01'),
(268, 544, 102, 69, '0', '2019-08-29 01:18:44', '2019-08-29 01:18:44'),
(269, 546, 102, 69, '0', '2019-08-29 01:19:43', '2019-08-29 01:19:43'),
(270, 553, 103, 92, '1', '2019-08-29 01:50:11', '2019-08-29 01:50:55'),
(271, 555, 103, 92, '1', '2019-08-29 01:52:13', '2019-08-29 01:53:01'),
(272, 555, 103, 92, '0', '2019-08-29 02:00:02', '2019-08-29 02:00:02'),
(273, 568, 104, 92, '1', '2019-08-29 02:17:15', '2019-08-29 02:17:45'),
(274, 569, 104, 92, '1', '2019-08-29 02:19:00', '2019-08-29 02:36:50'),
(275, 570, 104, 92, '1', '2019-08-29 02:25:42', '2019-08-29 02:26:18'),
(276, 574, 104, 92, '1', '2019-08-29 02:46:33', '2019-08-29 02:46:48'),
(277, 575, 104, 92, '0', '2019-08-29 02:52:47', '2019-08-29 02:52:47'),
(278, 581, 96, 92, '1', '2019-08-29 06:14:30', '2019-08-29 06:17:56'),
(279, 582, 96, 92, '0', '2019-08-29 06:15:49', '2019-08-29 06:15:49'),
(280, 583, 96, 69, '0', '2019-08-29 06:17:24', '2019-08-29 06:17:24'),
(281, 584, 96, 69, '1', '2019-08-29 06:20:46', '2019-08-29 06:22:00'),
(282, 585, 96, 69, '1', '2019-08-29 06:24:19', '2019-08-29 06:25:55'),
(283, 586, 105, 69, '1', '2019-08-30 04:18:06', '2019-08-30 04:19:16');

-- --------------------------------------------------------

--
-- Table structure for table `j_ob_checkin_outs`
--

CREATE TABLE `j_ob_checkin_outs` (
  `id` int(10) UNSIGNED NOT NULL,
  `job_id` int(11) NOT NULL,
  `checkIn` time NOT NULL,
  `checkOut` time DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `j_ob_checkin_outs`
--

INSERT INTO `j_ob_checkin_outs` (`id`, `job_id`, `checkIn`, `checkOut`, `created_at`, `updated_at`) VALUES
(1, 287, '09:30:00', '15:20:01', '2019-04-09 02:59:48', '2019-04-10 04:20:00'),
(9, 298, '10:20:00', '14:30:00', '2019-04-09 08:26:04', '2019-04-10 01:22:03'),
(10, 187, '09:30:00', '11:30:00', '2019-04-10 00:23:47', '2019-04-10 01:22:21'),
(11, 184, '12:45:00', NULL, '2019-04-10 01:45:35', '2019-04-10 01:45:35'),
(12, 270, '12:54:00', '16:47:29', '2019-04-10 01:54:12', '2019-04-10 05:47:28'),
(13, 270, '12:54:00', NULL, '2019-04-10 01:54:20', '2019-04-10 01:54:20'),
(14, 287, '13:48:00', NULL, '2019-04-10 02:48:54', '2019-04-10 02:48:54'),
(15, 270, '15:15:00', NULL, '2019-04-10 04:15:37', '2019-04-10 04:15:37'),
(16, 270, '15:15:00', NULL, '2019-04-10 04:15:43', '2019-04-10 04:15:43'),
(17, 287, '15:19:00', NULL, '2019-04-10 04:19:52', '2019-04-10 04:19:52'),
(18, 352, '15:21:00', '15:22:15', '2019-04-10 04:21:46', '2019-04-10 04:22:14'),
(19, 348, '15:27:00', NULL, '2019-04-10 04:27:10', '2019-04-10 04:27:10'),
(20, 348, '15:27:00', NULL, '2019-04-10 04:27:26', '2019-04-10 04:27:26'),
(21, 184, '15:28:00', NULL, '2019-04-10 04:28:54', '2019-04-10 04:28:54'),
(22, 184, '15:38:00', NULL, '2019-04-10 04:38:37', '2019-04-10 04:38:37'),
(23, 184, '15:39:00', NULL, '2019-04-10 04:39:39', '2019-04-10 04:39:39'),
(24, 270, '15:52:00', NULL, '2019-04-10 04:52:48', '2019-04-10 04:52:48'),
(25, 184, '15:54:00', NULL, '2019-04-10 04:54:15', '2019-04-10 04:54:15'),
(26, 339, '16:34:00', NULL, '2019-04-10 05:34:22', '2019-04-10 05:34:22'),
(27, 340, '16:34:00', NULL, '2019-04-10 05:34:32', '2019-04-10 05:34:32'),
(28, 312, '17:08:00', '17:09:02', '2019-04-10 06:08:55', '2019-04-10 06:09:00'),
(29, 317, '17:33:00', NULL, '2019-04-10 06:33:19', '2019-04-10 06:33:19'),
(30, 323, '17:36:00', '17:36:38', '2019-04-10 06:36:33', '2019-04-10 06:36:36'),
(31, 329, '11:04:00', NULL, '2019-04-11 00:04:02', '2019-04-11 00:04:02'),
(32, 349, '14:03:00', NULL, '2019-05-20 03:03:59', '2019-05-20 03:03:59'),
(33, 353, '13:52:15', '12:15:00', '2019-07-15 02:52:15', '2019-07-15 02:53:04'),
(34, 454, '15:25:48', '15:15:00', '2019-08-21 04:25:49', '2019-08-21 05:05:51'),
(35, 453, '15:49:56', NULL, '2019-08-21 04:49:58', '2019-08-21 04:49:58'),
(36, 520, '17:28:33', NULL, '2019-08-27 06:28:34', '2019-08-27 06:28:34'),
(37, 532, '17:47:24', '17:46:00', '2019-08-28 06:47:26', '2019-08-28 07:09:11'),
(38, 533, '18:16:16', NULL, '2019-08-28 07:16:18', '2019-08-28 07:16:18'),
(39, 534, '19:15:50', '19:10:00', '2019-08-28 08:15:51', '2019-08-28 08:16:09'),
(40, 538, '11:53:49', '11:52:00', '2019-08-29 00:53:50', '2019-08-29 00:54:01'),
(41, 553, '12:50:48', '12:50:00', '2019-08-29 01:50:49', '2019-08-29 01:50:55'),
(42, 555, '12:52:58', '12:52:00', '2019-08-29 01:52:59', '2019-08-29 01:53:01'),
(43, 568, '13:17:40', '13:17:00', '2019-08-29 02:17:41', '2019-08-29 02:17:45'),
(44, 570, '13:26:13', '13:25:00', '2019-08-29 02:26:13', '2019-08-29 02:26:18'),
(45, 569, '13:36:47', '13:17:55', '2019-08-29 02:36:48', '2019-08-29 02:36:50'),
(46, 574, '13:46:44', '13:46:00', '2019-08-29 02:46:46', '2019-08-29 02:46:48'),
(47, 581, '17:17:51', '17:14:00', '2019-08-29 06:17:51', '2019-08-29 06:17:56'),
(48, 584, '17:21:49', '17:20:00', '2019-08-29 06:21:49', '2019-08-29 06:22:00'),
(49, 585, '17:25:40', '17:23:00', '2019-08-29 06:25:40', '2019-08-29 06:25:55'),
(50, 586, '15:19:04', '15:16:00', '2019-08-30 04:19:06', '2019-08-30 04:19:16');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_09_05_114134_create_countries_table', 1),
(4, '2018_09_05_114537_create_states_table', 1),
(5, '2018_09_05_114609_create_cities_table', 1),
(6, '2018_09_06_065411_drop_column_to_cities', 1),
(7, '2018_09_06_082732_create_zipcodes_table', 1),
(8, '2018_09_10_063849_create_services_table', 1),
(9, '2018_09_10_064135_create_service_types_table', 1),
(10, '2018_09_10_070215_update_status_to_services_table', 1),
(11, '2018_09_10_070340_update_status_to_service_types_table', 1),
(12, '2018_09_11_062953_change_column_to_users_table', 1),
(13, '2018_09_11_063634_create_roles_table', 1),
(14, '2018_09_11_063750_create_user_roles_table', 1),
(15, '2018_09_11_115014_change_mobile_to_users_table', 1),
(16, '2018_09_21_053130_create_serviceproviders_table', 2),
(17, '2018_09_25_065851_add_profile_image_to_serviceproviders_table', 3),
(18, '2018_09_25_082017_create_sptostypes_table', 4),
(19, '2018_09_25_104647_remove_service_id_from_serviceproviders', 5),
(20, '2018_09_25_104923_remove_service_id_from_serviceproviders', 6),
(21, '2018_09_25_110513_create_serviceproviders_table', 7),
(22, '2018_09_25_135808_add_image_to_servicetypes_table', 8),
(23, '2018_10_06_082833_add_description_to_servicetypes_table', 9),
(24, '2018_10_26_120941_add_role_to_users_table', 10),
(25, '2018_10_30_080511_create_otps_table', 11),
(26, '2018_10_31_071726_create_user_addresses_table', 12),
(27, '2018_11_01_074057_add_nullable_fields_to_user_table', 13),
(28, '2018_11_19_082202_add__is_expire_to_otps_table', 14),
(29, '2018_11_20_072906_add_serviceprice_to_serviceproviders_table', 15),
(30, '2018_11_21_072922_add_lat_lng_to_serviceproviders_table', 16),
(31, '2018_11_21_095715_add_latt_long_to_serviceproviders_table', 17),
(32, '2018_11_21_100335_add_lat_lng_to_serviceproviders_table', 18),
(33, '2018_11_27_064459_add_address_to_useraddresses_table', 19),
(34, '2018_11_27_112258_add_deviceid_to_users_table', 20),
(35, '2018_11_27_112823_add_deviceidtype_to_users_table', 21),
(36, '2018_11_27_113127_add_changedatatype_to_users_table', 22),
(37, '2018_11_27_114147_add_dropdeviceid_to_users_table', 23),
(38, '2018_11_27_114424_add_deviceid_to_users_table', 24),
(39, '2018_11_27_114517_add_deviceidstring_to_users_table', 24),
(40, '2018_11_28_105248_add_devicetypedeviceidrole_to_users_table', 25),
(41, '2018_11_29_071902_add_services_to_users_table', 26),
(42, '2018_11_30_062300_add_profie_to_users_table', 27),
(43, '2018_11_30_075013_add_image_to_users_table', 28),
(44, '2018_12_03_094221_create_providerbios_table', 29),
(45, '2018_12_03_094552_add_user_id_to_providerbios_table', 30),
(46, '2018_12_05_083005_change_devicetypetonullabal_to_users_table', 31),
(47, '2018_12_07_120541_create_provider_profiles_table', 32),
(48, '2018_12_07_121313_add_status_to_providerbios_table', 33),
(49, '2018_12_17_065751_create_approved__bios_table', 34),
(50, '2018_12_20_073353_add_jottimes_to_providerbios_table', 35),
(51, '2018_12_20_131639_add_jobtimeing_to_approved__bios_table', 36),
(52, '2018_12_24_130438_add_workingstatus_to_users_table', 37),
(53, '2018_12_24_131556_add_dropcolom_to_users_table', 38),
(54, '2018_12_24_132152_add_dropcolom_to_users_table', 39),
(55, '2018_12_24_132331_addjob_status_to_users_table', 40),
(56, '2018_12_26_134915_create_provider_faqs_table', 41),
(57, '2018_12_26_135238_create_customer_faqs_table', 42),
(58, '2018_12_27_105136_create_service_prices_table', 43),
(59, '2018_12_29_042356_change_ansertype_to_provider_faqs_table', 44),
(60, '2018_12_29_043646_change_answertype_to_customer_faqs_table', 45),
(61, '2018_12_29_044012_change_questiontype_to_provider_faqs_table', 46),
(62, '2018_12_29_044446_change_questiontypelong_to_provider_faqs_table', 47),
(63, '2018_12_29_044654_change_questiontypelong_to_provider_faqs_table', 48),
(64, '2018_12_29_044902_change_qestiontype_to_customer_faqs_table', 49),
(65, '2019_01_02_102231_create_instant_bookings_table', 50),
(66, '2019_01_07_072723_dropcolums_from_instant_bookings_table', 51),
(67, '2019_01_07_073206_addcolums_in_instant_bookings_table', 52),
(68, '2019_01_07_074225_drop_zipcode_service_colums_from_instant_bookings_table', 53),
(69, '2019_01_14_062024_create_neighborhoods__zipcodes_table', 54),
(70, '2019_01_15_062622_add_customeraddress_to_instant_bookings_table', 55),
(71, '2019_01_15_135414_create_instant_schedule_jobs_table', 56),
(72, '2019_01_16_053403_change_status_to_instant_schedule_jobs_table', 57),
(73, '2019_01_16_060054_add_status_to_instant_schedule_jobs_table', 58),
(74, '2019_01_31_115442_add_customer_id_to_instant_schedule_jobs_table', 59),
(75, '2019_01_31_140045_create_job_check_in__check_outs_table', 60),
(76, '2019_02_05_074431_create_working_days_table', 61),
(77, '2019_02_05_103308_create_daily_scheduled_jobs_table', 62),
(78, '2019_02_05_104056_create_weekly_scheduled_jobs_table', 63),
(79, '2019_02_05_104300_create_monthly_scheduled_jobs_table', 64),
(80, '2019_02_05_130330_add__zipcode_time_serviceids_to_daily_scheduled_jobs_table', 65),
(81, '2019_02_06_072613_add__zipcode_serviceids_to_weekly_scheduled_jobss_table', 66),
(82, '2019_02_06_074342_renamecolom_name_to_weekly_scheduled_jobss_table', 67),
(83, '2019_02_06_074541_change_type_colom_to_weekly_scheduled_jobss_table', 68),
(84, '2019_02_06_115454_add_date_time_to_monthly_scheduled_jobs_table', 69),
(85, '2019_02_06_115821_add_date_time_to_monthly_scheduled_jobs_table', 70),
(86, '2019_02_06_115916_change_date_time_to_monthly_scheduled_jobs_table', 71),
(87, '2019_02_18_064632_create_special_request_to_cleaners_table', 72),
(88, '2019_02_18_112959_create_provider_reviews_table', 73),
(89, '2019_02_19_121104_create_referrals_table', 74),
(90, '2019_02_19_132636_add_referlcode_to_users_table', 75),
(91, '2019_02_20_134226_create_rebookedjobs_table', 76),
(92, '2019_02_21_065827_add__parent_id_to_instant_bookings_table', 77),
(93, '2019_02_21_070413_drop_rebookedjobs_table', 78),
(94, '2019_03_02_053636_create_top_rated__providers_table', 79),
(95, '2019_03_02_063338_drop_services_from_to_top_rated__providers_table', 80),
(96, '2019_03_02_095022_add_status_to_working_days_table', 81),
(97, '2019_03_20_061408_create_discount_codes_table', 82),
(98, '2019_04_01_114250_create_block_providers_table', 83),
(99, '2019_04_01_130046_create_block_customers_table', 84),
(100, '2019_04_09_074515_create_j_ob_checkin_outs_table', 85),
(101, '2019_04_09_082232_alter_table_j_ob_checkin_outs_change_chec_in', 86),
(102, '2019_05_18_111850_create_service_types_spanishes_table', 87),
(103, '2019_05_18_112629_create_services_spanishes_table', 88),
(104, '2019_05_20_064954_create_customer_faq_spanishes_table', 89),
(105, '2019_05_20_065510_create_provider_faq_spanishes_table', 90);

-- --------------------------------------------------------

--
-- Table structure for table `monthly_scheduled_jobs`
--

CREATE TABLE `monthly_scheduled_jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Zipcode` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `services` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `monthly_scheduled_jobs`
--

INSERT INTO `monthly_scheduled_jobs` (`id`, `customer_id`, `date`, `time`, `Zipcode`, `customer_address`, `services`, `created_at`, `updated_at`) VALUES
(4, 10, '1 , 3 , 5', '10:40 , 11:40 , 9:40', '70008', 'Nathan K. Flores 1516 Holt Street West Palm Beach, FL 33401 Phone:561-352-5973', '14,22,26', '2019-02-06 07:19:17', '2019-02-06 07:19:17'),
(5, 15, '1 , 2 , 5 , 9 , 12 , 18 , 19 , 22 , 25 , 28 , 30', '10:00 , 18:40 , 10:20 , 11:40 , 09:40 , 11:30 , 22:40 , 11:40 , 10:40 , 11:40 , 9:40', '50006', 'Donald M. Palmer 2595 Pearlman Avenue Sudbury, MA 01776 Phone:293-112-459', '26', '2019-02-06 07:21:34', '2019-02-06 07:21:34'),
(6, 41, '12 , 18 , 19 , 22 , 25 , 28 , 30', '09:40 , 11:30 , 22:40 , 11:40 , 10:40 , 11:40 , 9:40', '40003', 'Carol J. Stephens 1635 Franklin Street Montgomery, AL 36104 Phone:126-632-2345', '26,23,14', '2019-02-06 07:22:29', '2019-02-06 07:22:29'),
(8, 42, '2 , 15 , 9 , 22 , 25 , 28 , 30', '09:40 , 11:30 , 22:40 , 11:40 , 10:40 , 11:40 , 9:40', '70001', 'Michael I. Days 3756 Preston Street Wichita, KS 67213 Phone:857-778-1265', '22,14', '2019-02-06 07:28:22', '2019-02-06 07:28:22'),
(9, 10, '1 , 3 , 5', '10:40 , 11:40 , 9:40', '70008', 'Michael I. Days 3756 Preston Street5', '14,22,26', '2019-02-07 01:03:39', '2019-02-07 01:03:39'),
(10, 42, '2 , 15 , 9 , 22 , 25 , 28 , 30', '09:40 , 11:30 , 22:40 , 11:40 , 10:40 , 11:40 , 9:40', '70001', 'Michael I. Days 3756 Preston Street Wichita, KS 67213 Phone:857-778-1265', '22,14', '2019-02-07 01:15:29', '2019-02-07 01:15:29'),
(11, 42, '1,3,8,12,15,20,19', '12:50,11:20,10:20,09:10,15:40,20:30,10:20', '70001', 'Michael I. Days 3756 Preston Street Wichita, KS 67213 Phone:857-778-1265', '22,14', '2019-02-07 06:45:35', '2019-02-07 06:45:35'),
(12, 42, '1,3,8,12,15,20,19', '12:50,11:20,10:20,09:10,15:40,20:30,10:20', '70001', 'Michael I. Days 3756 Preston Street Wichita, KS 67213 Phone:857-778-1265', '22,14', '2019-02-18 01:55:26', '2019-02-18 01:55:26'),
(13, 42, '1,3,8,12,15,20,19', '12:50,11:20,10:20,09:10,15:40,20:30,10:20', '70001', 'Michael I. Days 3756 Preston Street Wichita, KS 67213 Phone:857-778-1265', '22,14', '2019-02-18 01:58:54', '2019-02-18 01:58:54');

-- --------------------------------------------------------

--
-- Table structure for table `neighborhoods__zipcodes`
--

CREATE TABLE `neighborhoods__zipcodes` (
  `id` int(10) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `neighbr_zipCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `otps`
--

CREATE TABLE `otps` (
  `id` int(10) UNSIGNED NOT NULL,
  `otp` int(11) NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `is_expired` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `otps`
--

INSERT INTO `otps` (`id`, `otp`, `user_id`, `is_expired`, `created_at`, `updated_at`) VALUES
(1, 4316, 1, '2019-02-07 07:05:18', '2019-02-07 01:33:18', '2019-02-07 01:33:18'),
(2, 2083, 3, '2019-02-07 07:39:11', '2019-02-07 01:34:34', '2019-02-07 01:59:11'),
(3, 5427, 40, '2019-06-01 08:45:18', '2019-03-18 00:49:20', '2019-06-01 03:05:18'),
(4, 9013, 49, '2019-04-01 13:24:47', '2019-04-01 07:06:24', '2019-04-01 07:44:47'),
(5, 9523, 16, '2019-04-09 11:19:28', '2019-04-09 05:31:45', '2019-04-09 05:39:28'),
(6, 6829, 65, '2019-07-02 07:18:50', '2019-07-02 01:38:50', '2019-07-02 01:38:50'),
(7, 9404, 106, '2019-08-30 10:16:39', '2019-08-30 04:36:39', '2019-08-30 04:36:39'),
(8, 9207, 98, '2019-08-30 11:09:03', '2019-08-30 05:25:04', '2019-08-30 05:29:03'),
(9, 6312, 105, '2019-08-30 11:12:10', '2019-08-30 05:29:39', '2019-08-30 05:32:10');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `providerbios`
--

CREATE TABLE `providerbios` (
  `id` int(10) UNSIGNED NOT NULL,
  `Bio` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time NOT NULL,
  `serviceprovider_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `providerbios`
--

INSERT INTO `providerbios` (`id`, `Bio`, `starttime`, `endtime`, `serviceprovider_id`, `status`, `created_at`, `updated_at`) VALUES
(4, 'test', '15:04:00', '15:05:00', 60, 0, '2019-05-23 00:51:07', '2019-05-23 01:24:02'),
(5, 'This app works', '21:48:00', '20:48:00', 49, 0, '2019-05-23 07:47:34', '2019-05-23 08:22:04'),
(7, 'testing', '00:00:00', '23:00:00', 80, 0, '2019-08-21 04:07:35', '2019-08-21 04:07:35'),
(8, 'dhdkdhd', '00:00:00', '23:00:00', 83, 0, '2019-08-23 05:11:17', '2019-08-23 05:11:17'),
(9, 'Testing', '00:00:00', '23:00:00', 86, 0, '2019-08-27 03:57:27', '2019-08-27 03:57:27'),
(10, 'final testing', '00:00:00', '23:00:00', 88, 0, '2019-08-27 06:26:03', '2019-08-27 06:26:03'),
(11, 'testing', '00:00:00', '23:00:00', 93, 0, '2019-08-28 02:43:01', '2019-08-28 02:43:01'),
(12, 'tdhdkxhd', '00:00:00', '23:00:00', 94, 0, '2019-08-28 04:20:39', '2019-08-28 04:20:39'),
(13, 'Testing', '00:00:00', '23:00:00', 100, 0, '2019-08-28 06:35:47', '2019-08-28 06:35:47'),
(14, 'Fhdid', '00:00:00', '23:00:00', 102, 0, '2019-08-28 08:10:46', '2019-08-28 08:10:46'),
(15, 'Gdidgdiege', '00:00:00', '23:00:00', 103, 0, '2019-08-29 01:46:59', '2019-08-29 01:46:59'),
(16, 'Euro 3', '00:15:00', '23:00:00', 104, 0, '2019-08-29 02:16:05', '2019-08-29 02:16:05'),
(17, 'dhifdydudh', '00:00:00', '23:00:00', 96, 0, '2019-08-29 06:13:14', '2019-08-29 06:13:14'),
(18, 'Fhfiufuuf', '00:00:00', '23:00:00', 105, 0, '2019-08-30 04:16:59', '2019-08-30 04:17:31'),
(19, 'dhdkhd', '00:00:00', '23:00:00', 106, 0, '2019-08-30 04:17:30', '2019-08-30 04:17:30'),
(20, 'Hi there , \nI am a dedicated worker . \nPunctual', '13:00:00', '17:08:00', 108, 0, '2020-02-28 01:09:08', '2020-02-28 01:09:08'),
(21, '100% Customer Satisfaction', '17:39:00', '21:39:00', 110, 0, '2020-02-28 04:39:31', '2020-02-28 04:39:31');

-- --------------------------------------------------------

--
-- Table structure for table `provider_faqs`
--

CREATE TABLE `provider_faqs` (
  `id` int(10) UNSIGNED NOT NULL,
  `question` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `provider_faqs`
--

INSERT INTO `provider_faqs` (`id`, `question`, `answer`, `created_at`, `updated_at`) VALUES
(20, 'Do some good work so that you will get some rewards from mu side', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the&nbsp;</p>', '2018-12-27 05:37:07', '2018-12-27 08:09:40'),
(21, 'I need more help', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the&nbsp;</p>', '2018-12-27 05:37:33', '2019-01-17 05:57:21'),
(22, 'What is your college name', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the&nbsp;</p>', '2018-12-27 05:37:44', '2018-12-27 08:08:54'),
(23, 'What is your plan cancellation policy', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the&nbsp;</p>', '2018-12-27 05:37:58', '2019-01-17 05:57:38'),
(24, 'How long should a house cleaning take', '<p>t depends entirely on the size of your house! The minimum booking length is 3 hours, but you can always request a longer booking if you need one. Depending on the number of bedrooms and bathrooms you have, our checkout process will automatically scale your booking to the recommended amount of time for a home of your size.</p>', '2018-12-27 08:06:30', '2019-01-17 05:56:29'),
(38, 'Does house cleaning include laundry', '<p>If you have a washing machine and/or dryer in your home, your professional can absolutely wash and fold your laundry for you! Be sure to add it as an extra during the checkout process so the professional can be sure to set aside enough time to clean your home and still have time for laundry (it will add an extra hour onto your booking).</p>', '2018-12-28 23:40:58', '2019-01-17 05:56:11');

-- --------------------------------------------------------

--
-- Table structure for table `provider_faq_spanishes`
--

CREATE TABLE `provider_faq_spanishes` (
  `id` int(10) UNSIGNED NOT NULL,
  `pro_faqId` int(10) UNSIGNED DEFAULT NULL,
  `question` longtext COLLATE utf8mb4_unicode_ci,
  `answer` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `provider_faq_spanishes`
--

INSERT INTO `provider_faq_spanishes` (`id`, `pro_faqId`, `question`, `answer`, `created_at`, `updated_at`) VALUES
(2, 38, '¿La limpieza de la casa incluye lavandería?', '<p>Si tiene una lavadora y / o secadora en su hogar, su profesional puede absolutamente lavar y doblar su ropa por usted. Aseg&uacute;rese de agregarlo como un extra durante el proceso de pago para que el profesional pueda reservar suficiente tiempo para limpiar su casa y tener tiempo para la lavander&iacute;a (agregar&aacute; una hora adicional a su reserva).</p>', '2019-05-20 02:58:13', '2019-05-20 02:58:13'),
(3, 24, '¿Cuánto tiempo debe tomar una limpieza de casa?', '<p>Depende enteramente del tama&ntilde;o de tu casa! La duraci&oacute;n m&iacute;nima de la reserva es de 3 horas, pero siempre puede solicitar una reserva m&aacute;s larga si la necesita. Dependiendo de la cantidad de habitaciones y ba&ntilde;os que tenga, nuestro proceso de compra escalar&aacute; autom&aacute;ticamente su reserva a la cantidad de tiempo recomendada para una casa de su tama&ntilde;o.</p>', '2019-05-20 02:58:55', '2019-05-20 02:58:55'),
(4, 23, '¿Cuál es la política de cancelación de su plan?', '<p>Lorem Ipsum es simplemente un texto de relleno de la industria de impresi&oacute;n y composici&oacute;n. Lorem Ipsum ha sido el texto ficticio est&aacute;ndar de la industria desde la</p>', '2019-05-20 02:59:18', '2019-05-20 02:59:18'),
(5, 21, 'Necesito mas ayuda', '<p>Lorem Ipsum es simplemente un texto de relleno de la industria de impresi&oacute;n y composici&oacute;n. Lorem Ipsum ha sido el texto ficticio est&aacute;ndar de la industria desde la</p>', '2019-05-20 02:59:32', '2019-05-20 02:59:32'),
(6, 20, 'Haz un buen trabajo para que obtengas algunas recompensas del lado mu', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the&nbsp;</p>', '2019-05-20 02:59:48', '2019-05-20 03:02:34'),
(7, 22, 'Como se llama tu universidad', '<p>Como se llama tu universidad</p>', '2019-05-20 03:00:43', '2019-05-20 03:00:43');

-- --------------------------------------------------------

--
-- Table structure for table `provider_profiles`
--

CREATE TABLE `provider_profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `serviceprovider_id` int(11) NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `provider_reviews`
--

CREATE TABLE `provider_reviews` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `review` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `provider_reviews`
--

INSERT INTO `provider_reviews` (`id`, `customer_id`, `job_id`, `provider_id`, `review`, `comment`, `created_at`, `updated_at`) VALUES
(2, 2, 100, 44, '4.5', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry..', '2019-02-18 07:46:37', '2019-02-18 07:46:37'),
(4, 4, 101, 7, '1.5', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry..', '2019-02-18 07:47:05', '2019-02-18 07:47:05'),
(6, 6, 102, 44, '5', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry..', '2019-02-18 07:47:35', '2019-02-18 07:47:35'),
(7, 10, 103, 37, '4.5', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry..', '2019-02-18 07:47:49', '2019-02-18 07:47:49'),
(8, 12, 104, 5, '5', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry..', '2019-02-18 07:48:04', '2019-02-18 07:48:04'),
(10, 15, 106, 43, '3.5', 'Good Cleaner.', '2019-02-19 04:38:51', '2019-02-19 04:38:51'),
(14, 16, 107, 7, '1.5', 'errrrr', '2019-02-19 05:01:57', '2019-02-19 05:01:57'),
(15, 41, 109, 7, '4.5', 'hello man how are you', '2019-02-19 05:14:23', '2019-02-19 05:14:23'),
(16, 42, 121, 11, '3.5', 'helloisjsjjswjbsjsndjaksijdbxjdbdhdhshhdhdhsbdhdhdhdhdhdhbdhdhdhdhdhshsbshwjbshdbshshdbhshs', '2019-02-19 05:18:33', '2019-02-19 05:18:33'),
(18, 45, 125, 37, '5', 'wggegs', '2019-02-19 05:20:36', '2019-02-19 05:20:36'),
(20, 46, 135, 3, '5', 'cggg', '2019-02-19 05:24:29', '2019-02-19 05:24:29'),
(21, 48, 136, 40, '3.0', 'bahahahhs', '2019-02-19 05:25:24', '2019-02-19 05:25:24'),
(24, 42, 137, 40, '3.0', 'vzhaha', '2019-02-19 05:29:47', '2019-02-19 05:29:47'),
(27, 4, 140, 11, '2.0', 'ghhh', '2019-02-19 06:00:58', '2019-02-19 06:00:58'),
(28, 6, 141, 37, '3.0', 'gigighi', '2019-02-19 06:01:15', '2019-02-19 06:01:15'),
(29, 10, 143, 37, '5.0', 'y g', '2019-02-19 06:01:26', '2019-02-19 06:01:26'),
(32, 12, 144, 3, '4.0', 'vhhh', '2019-02-19 06:05:34', '2019-02-19 06:05:34'),
(34, 15, 145, 11, '2.0', 'fhhhh', '2019-02-19 06:10:52', '2019-02-19 06:10:52'),
(38, 16, 146, 5, '4.0', 'vahsushshHBsva', '2019-02-19 06:51:17', '2019-02-19 06:51:17'),
(39, 41, 147, 5, '2.0', 'gggh', '2019-02-19 07:19:20', '2019-02-19 07:19:20'),
(40, 42, 148, 43, '3.5', 'Good Cleaner.', '2019-02-25 01:36:48', '2019-02-25 01:36:48'),
(41, 16, 107, 7, '2.914285714285714', 'ksgjuosirgjoeirjhoerhjdfkljhdfklhjdfkljhldhjkdflhjfdsklhjdlkhjdklhjklhjdklhjdlfkhjdhjfdlhjdlhj', '2019-03-14 03:06:13', '2019-03-14 03:06:13'),
(42, 16, 107, 7, '2.557142857142857', 'Sdvhdsjkghdhgoasdlk', '2019-03-14 03:11:19', '2019-03-14 03:11:19'),
(43, 16, 43, 7, '3.5', 'vhhh', '2019-03-14 03:11:53', '2019-03-14 03:11:53'),
(44, 16, 107, 7, '2.5', 'Great Job', '2019-03-14 03:14:26', '2019-03-14 03:14:26'),
(45, 16, 107, 7, '3.5', 'Great Jobs', '2019-03-14 05:37:26', '2019-03-14 05:37:26'),
(46, 16, 43, 7, '2.5', 'hshshdhdhdjdsjdjdjjjjsjd', '2019-03-15 00:26:05', '2019-03-15 00:26:05'),
(47, 16, 107, 7, '4.5', 'Great Job Buddy!', '2019-03-15 02:34:51', '2019-03-15 02:34:51'),
(48, 16, 107, 7, '4.5', 'Great Job!', '2019-03-15 06:13:44', '2019-03-15 06:13:44'),
(49, 16, 107, 7, '3.5', 'Great job', '2019-03-16 05:26:15', '2019-03-16 05:26:15'),
(50, 16, 175, 2, '5', 'Xgkgdkhkhdkhdkhdhkx', '2019-04-10 00:30:41', '2019-04-10 00:30:41'),
(51, 16, 176, 49, '4.5', 'Hdgzjxgmkchhchchchkxxkgkgdkdgxgkgdkhdkgfkhdflhflhfflhflhfhfulhfhlkhxkhddhlxdlhlhxlhfhldlhdfhjlfhlflhflfhhfllhdkdykydkydgkodyoyfulhfho', '2019-04-10 00:31:23', '2019-04-10 00:31:23'),
(52, 16, 176, 49, '1', 'Hilarious service,I won’t book a cleaner from this app.', '2019-04-10 03:07:48', '2019-04-10 03:07:48'),
(53, 16, 312, 49, '3.5', 'Sjsjjssjjss', '2019-04-12 07:22:45', '2019-04-12 07:22:45'),
(54, 16, 298, 49, '5', 'Best', '2019-04-12 07:23:08', '2019-04-12 07:23:08'),
(55, 16, 175, 2, '5', 'Gdjgxgkgidjxgkxg', '2019-04-12 07:38:42', '2019-04-12 07:38:42'),
(56, 16, 298, 49, '5', 'Zfjfzigxxgmhckckhcckhlh', '2019-04-12 07:38:55', '2019-04-12 07:38:55'),
(57, 16, 175, 2, '1', 'Fzirzxitkgxckgkg', '2019-04-12 07:39:06', '2019-04-12 07:39:06'),
(58, 16, 175, 2, '5', 'HDfxkkgxdgjzfjhfjfz', '2019-04-12 07:41:34', '2019-04-12 07:41:34'),
(59, 16, 175, 2, '5', 'Fszfkxgkkgkxoy', '2019-04-12 07:42:04', '2019-04-12 07:42:04'),
(60, 16, 175, 2, '5', 'Feteryhrhf', '2019-04-12 07:47:45', '2019-04-12 07:47:45'),
(61, 16, 175, 2, '5', 'Sutsutsutsigdid', '2019-05-18 04:39:09', '2019-05-18 04:39:09'),
(62, 16, 175, 2, '5', 'Chzfjsgi', '2019-05-18 04:39:16', '2019-05-18 04:39:16'),
(63, 16, 183, 2, '5', 'Awesome work buddy!', '2019-05-29 05:53:53', '2019-05-29 05:53:53'),
(64, 16, 176, 49, '5', 'Awesome work buddy,thanks bro.', '2019-05-29 05:54:22', '2019-05-29 05:54:22'),
(65, 16, 175, 2, '5', 'Thanks brother', '2019-05-29 05:54:40', '2019-05-29 05:54:40'),
(66, 6, 43, 44, '4.5', 'rtehtghgfhrtgrgtthrth', '2019-06-03 03:12:05', '2019-06-03 03:12:05'),
(67, 101, 43, 102, '2.5', 'very nice', '2019-08-28 08:16:37', '2019-08-28 08:16:37'),
(68, 69, 43, 80, '2.5', 'Very nice', '2019-08-29 07:12:52', '2019-08-29 07:12:52');

-- --------------------------------------------------------

--
-- Table structure for table `referrals`
--

CREATE TABLE `referrals` (
  `id` int(10) UNSIGNED NOT NULL,
  `sendinguserid` int(11) NOT NULL,
  `newuserid` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'admin', '2018-11-27 05:40:05', '2018-11-27 05:47:00'),
(2, 'provider', '2018-11-27 05:40:05', '2018-11-27 05:47:00'),
(5, 'customer', '2018-11-27 05:47:30', '2018-11-27 05:47:30');

-- --------------------------------------------------------

--
-- Table structure for table `serviceproviders`
--

CREATE TABLE `serviceproviders` (
  `id` int(10) UNSIGNED NOT NULL,
  `fName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lattitude` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `longitude` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `zip_code` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `serviceproviders`
--

INSERT INTO `serviceproviders` (`id`, `fName`, `lname`, `email`, `address`, `lattitude`, `longitude`, `mobile`, `country_id`, `state_id`, `city_id`, `zip_code`, `profile_image`, `price`, `created_at`, `updated_at`) VALUES
(20, 'Anna', 'Sthesia', 'Sthesia@gmail.com', 'Chandigarh, India', '30.7333148', '76.7794179', '2465246826', 6, 12, 13, '9', 'http://192.168.0.13/CleanerUp/cleaning_service/public/thumbnail_images/91543306828.png', 1750.00, '2018-11-20 06:33:35', '2018-11-27 02:50:28');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(5, 'Cleaning', 1, '2018-10-23 02:49:36', '2018-12-06 01:28:24');

-- --------------------------------------------------------

--
-- Table structure for table `services_spanishes`
--

CREATE TABLE `services_spanishes` (
  `id` int(10) UNSIGNED NOT NULL,
  `service_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services_spanishes`
--

INSERT INTO `services_spanishes` (`id`, `service_id`, `name`, `created_at`, `updated_at`) VALUES
(3, 5, 'limpieza', '2019-05-18 06:20:27', '2019-05-18 06:20:27');

-- --------------------------------------------------------

--
-- Table structure for table `service_prices`
--

CREATE TABLE `service_prices` (
  `id` int(10) UNSIGNED NOT NULL,
  `servicetype_id` int(11) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_prices`
--

INSERT INTO `service_prices` (`id`, `servicetype_id`, `price`, `created_at`, `updated_at`) VALUES
(1, 22, '60.00', '2018-12-01 00:10:03', '2018-12-27 07:27:17'),
(2, 14, '48.00', '2018-12-27 06:49:58', '2018-12-27 06:49:58'),
(3, 23, '54.00', '2018-12-27 06:58:44', '2018-12-27 06:58:44'),
(4, 26, '55.00', '2018-12-27 07:43:30', '2018-12-27 07:43:30'),
(6, 28, '45.00', '2019-05-18 06:31:26', '2019-05-18 06:31:26'),
(7, 29, '25.00', '2019-05-18 08:01:22', '2019-05-18 08:01:22'),
(8, 30, '265.00', '2019-05-18 08:15:09', '2019-05-18 08:15:09'),
(9, 31, '65.00', '2019-05-18 08:24:34', '2019-05-18 08:24:34'),
(10, 32, '45.00', '2019-05-18 08:48:34', '2019-05-18 08:48:34');

-- --------------------------------------------------------

--
-- Table structure for table `service_types`
--

CREATE TABLE `service_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `service_id` int(10) UNSIGNED DEFAULT NULL,
  `name` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_types`
--

INSERT INTO `service_types` (`id`, `service_id`, `name`, `description`, `image`, `status`, `created_at`, `updated_at`) VALUES
(14, 5, 'Extras', '<p>For a deeper clean, consider adding one or more cleaning extras. Most cleaning extras add one half hour of time and cost to your booking.</p>\r\n\r\n<ul>\r\n	<li>Inside cabinets</li>\r\n	<li>Inside fridge</li>\r\n	<li>Inside oven</li>\r\n	<li>Laundry wash &amp; dry</li>\r\n	<li>Interior windows</li>\r\n</ul>', '1.6338681660126E+15images.jpg', 1, '2018-10-23 04:26:38', '2019-08-23 07:45:24'),
(22, 5, 'Kitchen Cleaning', '<ul>\r\n	<li>Dust all accessible surfaces</li>\r\n	<li>Empty sink and load up dishwasher with dirty dishes</li>\r\n	<li>Wipe down exterior of stove, oven and fridge</li>\r\n	<li>Clean all floor surfaces</li>\r\n	<li>Take out garbage and recycling</li>\r\n</ul>\r\n\r\n<ul>\r\n</ul>', '1.6338681595565E+15down.jpg', 1, '2018-10-24 04:50:45', '2019-08-23 07:45:22'),
(23, 5, 'Bathroom Cleaning', '<ul>\r\n	<li>Wash and sanitize the toilet, shower, tub and sink</li>\r\n	<li>Dust all accessible surfaces</li>\r\n	<li>Wipe down all mirrors and glass fixtures</li>\r\n	<li>Clean all floor surfaces</li>\r\n	<li>Take out garbage and recycling</li>\r\n</ul>', '1.633868152888E+15downlo.jpg', 1, '2018-10-24 05:00:07', '2019-08-23 07:45:19'),
(26, 5, 'Bedroom Cleaning', '<p>Bedroom, Living Room &amp; Common Areas</p>\r\n\r\n<ul>\r\n	<li>Dust all accessible surfaces</li>\r\n	<li>Wipe down all mirrors and glass fixtures</li>\r\n	<li>Clean all floor surfaces</li>\r\n	<li>Take out garbage and recycling</li>\r\n</ul>', '1.6338681460762E+15load.jpg', 1, '2018-11-03 03:14:08', '2020-02-24 05:52:01');

-- --------------------------------------------------------

--
-- Table structure for table `service_types_spanishes`
--

CREATE TABLE `service_types_spanishes` (
  `id` int(10) UNSIGNED NOT NULL,
  `servicetype_id` int(10) UNSIGNED DEFAULT NULL,
  `name` char(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_types_spanishes`
--

INSERT INTO `service_types_spanishes` (`id`, `servicetype_id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(8, 26, 'Limpieza de habitaciones', '<p>Dormitorio, sala de estar y &aacute;reas comunes</p>\r\n\r\n<ul>\r\n	<li>Desempolvar todas las superficies accesibles</li>\r\n	<li>Limpie todos los espejos y accesorios de vidrio</li>\r\n	<li>Limpie todas las superficies del piso</li>\r\n</ul>', '2019-05-18 08:44:26', '2019-05-18 08:47:54'),
(9, 23, 'Limpieza de baños', '<p>Lave y desinfecte el inodoro, la ducha, la ba&ntilde;era y el lavamanos.</p>\r\n\r\n<ul>\r\n	<li>Desempolvar todas las superficies accesibles</li>\r\n	<li>Limpie todos los espejos y accesorios de vidrio</li>\r\n	<li>Limpie todas las superficies del piso</li>\r\n</ul>', '2019-05-18 08:45:10', '2019-05-18 08:47:41'),
(10, 22, 'Limpieza de cocina', '<ul>\r\n	<li>Desempolvar todas las superficies accesibles</li>\r\n	<li>Vaciar el fregadero y cargar el lavavajillas con platos sucios</li>\r\n	<li>Limpie el exterior de la estufa, horno y nevera</li>\r\n	<li>Limpie todas las superficies del piso</li>\r\n</ul>', '2019-05-18 08:45:53', '2019-05-18 08:47:32'),
(11, 14, 'Extras', '<p>Para una limpieza m&aacute;s profunda, considere agregar uno o m&aacute;s extras de limpieza. La mayor&iacute;a de los extras de limpieza a&ntilde;aden media hora de tiempo y costo a su reserva.</p>\r\n\r\n<ul>\r\n	<li>Armarios interiores</li>\r\n	<li>Refrigerador interior</li>\r\n	<li>Horno interior</li>\r\n	<li>Lavado de ropa y seco</li>\r\n</ul>', '2019-05-18 08:46:26', '2019-05-18 08:47:24');

-- --------------------------------------------------------

--
-- Table structure for table `special_request_to_cleaners`
--

CREATE TABLE `special_request_to_cleaners` (
  `id` int(10) UNSIGNED NOT NULL,
  `Job_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `Provider_id` int(11) NOT NULL,
  `packing_instrustion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `special_Request` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `special_request_to_cleaners`
--

INSERT INTO `special_request_to_cleaners` (`id`, `Job_id`, `customer_id`, `Provider_id`, `packing_instrustion`, `special_Request`, `created_at`, `updated_at`) VALUES
(1, 40, 11, 12, 'The packing instrustion field is required.', 'The special  request field is required.', '2019-02-18 01:42:39', '2019-02-18 01:42:39'),
(2, 40, 11, 12, 'The field is required.', 'The request field is required.', '2019-02-18 02:50:03', '2019-02-18 02:50:03');

-- --------------------------------------------------------

--
-- Table structure for table `sptostypes`
--

CREATE TABLE `sptostypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `serviceprovider_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `servicetype_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sptostypes`
--

INSERT INTO `sptostypes` (`id`, `serviceprovider_id`, `service_id`, `servicetype_id`, `created_at`, `updated_at`) VALUES
(113, 5, 5, 14, '2019-03-28 06:49:29', '2019-03-28 06:49:29'),
(114, 5, 5, 22, '2019-03-28 06:49:29', '2019-03-28 06:49:29'),
(115, 5, 5, 23, '2019-03-28 06:49:29', '2019-03-28 06:49:29'),
(156, 3, 5, 14, '2019-05-21 00:32:58', '2019-05-21 00:32:58'),
(157, 3, 5, 22, '2019-05-21 00:32:58', '2019-05-21 00:32:58'),
(158, 7, 5, 14, '2019-05-21 00:34:07', '2019-05-21 00:34:07'),
(159, 7, 5, 23, '2019-05-21 00:34:07', '2019-05-21 00:34:07'),
(160, 11, 5, 14, '2019-05-21 00:34:27', '2019-05-21 00:34:27'),
(161, 11, 5, 22, '2019-05-21 00:34:27', '2019-05-21 00:34:27'),
(162, 11, 5, 23, '2019-05-21 00:34:27', '2019-05-21 00:34:27'),
(163, 11, 5, 26, '2019-05-21 00:34:27', '2019-05-21 00:34:27'),
(164, 37, 5, 22, '2019-05-21 00:36:04', '2019-05-21 00:36:04'),
(165, 37, 5, 23, '2019-05-21 00:36:04', '2019-05-21 00:36:04'),
(166, 37, 5, 26, '2019-05-21 00:36:04', '2019-05-21 00:36:04'),
(168, 40, 5, 14, '2019-05-21 00:36:39', '2019-05-21 00:36:39'),
(169, 40, 5, 23, '2019-05-21 00:36:39', '2019-05-21 00:36:39'),
(170, 40, 5, 26, '2019-05-21 00:36:39', '2019-05-21 00:36:39'),
(171, 43, 5, 22, '2019-05-21 00:36:50', '2019-05-21 00:36:50'),
(172, 43, 5, 23, '2019-05-21 00:36:50', '2019-05-21 00:36:50'),
(173, 47, 5, 22, '2019-05-21 00:36:59', '2019-05-21 00:36:59'),
(174, 47, 5, 23, '2019-05-21 00:36:59', '2019-05-21 00:36:59'),
(175, 47, 5, 14, '2019-05-21 00:36:59', '2019-05-21 00:36:59'),
(180, 63, 5, 14, '2019-05-21 00:37:32', '2019-05-21 00:37:32'),
(181, 63, 5, 22, '2019-05-21 00:37:32', '2019-05-21 00:37:32'),
(182, 63, 5, 23, '2019-05-21 00:37:32', '2019-05-21 00:37:32'),
(183, 63, 5, 26, '2019-05-21 00:37:32', '2019-05-21 00:37:32'),
(203, 54, 5, 22, '2019-05-21 00:54:35', '2019-05-21 00:54:35'),
(204, 54, 5, 23, '2019-05-21 00:54:35', '2019-05-21 00:54:35'),
(217, 50, 5, 22, '2019-05-21 02:11:46', '2019-05-21 02:11:46'),
(218, 50, 5, 23, '2019-05-21 02:11:46', '2019-05-21 02:11:46'),
(219, 50, 5, 26, '2019-05-21 02:11:46', '2019-05-21 02:11:46'),
(237, 60, 5, 14, '2019-05-23 02:10:11', '2019-05-23 02:10:11'),
(238, 60, 5, 22, '2019-05-23 02:10:11', '2019-05-23 02:10:11'),
(239, 60, 5, 23, '2019-05-23 02:10:11', '2019-05-23 02:10:11'),
(240, 60, 5, 26, '2019-05-23 02:10:11', '2019-05-23 02:10:11'),
(253, 49, 5, 14, '2019-08-20 07:26:03', '2019-08-20 07:26:03'),
(254, 49, 5, 22, '2019-08-20 07:26:03', '2019-08-20 07:26:03'),
(255, 49, 5, 23, '2019-08-20 07:26:03', '2019-08-20 07:26:03'),
(256, 49, 5, 26, '2019-08-20 07:26:03', '2019-08-20 07:26:03'),
(257, 78, 5, 22, '2019-08-20 08:09:41', '2019-08-20 08:09:41'),
(258, 78, 5, 23, '2019-08-20 08:09:41', '2019-08-20 08:09:41'),
(259, 78, 5, 26, '2019-08-20 08:09:41', '2019-08-20 08:09:41'),
(260, 80, 5, 14, '2019-08-21 04:07:35', '2019-08-21 04:07:35'),
(261, 80, 5, 22, '2019-08-21 04:07:35', '2019-08-21 04:07:35'),
(262, 80, 5, 23, '2019-08-21 04:07:35', '2019-08-21 04:07:35'),
(263, 80, 5, 26, '2019-08-21 04:07:35', '2019-08-21 04:07:35'),
(264, 81, 5, 14, '2019-08-21 05:12:13', '2019-08-21 05:12:13'),
(265, 81, 5, 22, '2019-08-21 05:12:13', '2019-08-21 05:12:13'),
(266, 81, 5, 23, '2019-08-21 05:12:13', '2019-08-21 05:12:13'),
(267, 81, 5, 26, '2019-08-21 05:12:13', '2019-08-21 05:12:13'),
(268, 83, 5, 14, '2019-08-23 05:11:17', '2019-08-23 05:11:17'),
(269, 83, 5, 22, '2019-08-23 05:11:17', '2019-08-23 05:11:17'),
(270, 83, 5, 23, '2019-08-23 05:11:17', '2019-08-23 05:11:17'),
(271, 83, 5, 26, '2019-08-23 05:11:17', '2019-08-23 05:11:17'),
(272, 86, 5, 14, '2019-08-27 03:57:27', '2019-08-27 03:57:27'),
(273, 86, 5, 22, '2019-08-27 03:57:27', '2019-08-27 03:57:27'),
(274, 86, 5, 23, '2019-08-27 03:57:27', '2019-08-27 03:57:27'),
(275, 86, 5, 26, '2019-08-27 03:57:27', '2019-08-27 03:57:27'),
(276, 88, 5, 14, '2019-08-27 06:26:03', '2019-08-27 06:26:03'),
(277, 88, 5, 22, '2019-08-27 06:26:03', '2019-08-27 06:26:03'),
(278, 88, 5, 23, '2019-08-27 06:26:03', '2019-08-27 06:26:03'),
(279, 88, 5, 26, '2019-08-27 06:26:03', '2019-08-27 06:26:03'),
(280, 93, 5, 14, '2019-08-28 02:43:01', '2019-08-28 02:43:01'),
(281, 93, 5, 22, '2019-08-28 02:43:01', '2019-08-28 02:43:01'),
(282, 93, 5, 23, '2019-08-28 02:43:01', '2019-08-28 02:43:01'),
(283, 93, 5, 26, '2019-08-28 02:43:01', '2019-08-28 02:43:01'),
(284, 94, 5, 14, '2019-08-28 04:20:39', '2019-08-28 04:20:39'),
(285, 94, 5, 22, '2019-08-28 04:20:39', '2019-08-28 04:20:39'),
(286, 94, 5, 23, '2019-08-28 04:20:39', '2019-08-28 04:20:39'),
(287, 94, 5, 26, '2019-08-28 04:20:39', '2019-08-28 04:20:39'),
(288, 100, 5, 14, '2019-08-28 06:35:47', '2019-08-28 06:35:47'),
(289, 100, 5, 22, '2019-08-28 06:35:47', '2019-08-28 06:35:47'),
(290, 100, 5, 23, '2019-08-28 06:35:47', '2019-08-28 06:35:47'),
(291, 100, 5, 26, '2019-08-28 06:35:47', '2019-08-28 06:35:47'),
(292, 102, 5, 14, '2019-08-28 08:10:46', '2019-08-28 08:10:46'),
(293, 102, 5, 22, '2019-08-28 08:10:46', '2019-08-28 08:10:46'),
(294, 102, 5, 23, '2019-08-28 08:10:46', '2019-08-28 08:10:46'),
(295, 102, 5, 26, '2019-08-28 08:10:46', '2019-08-28 08:10:46'),
(296, 103, 5, 14, '2019-08-29 01:46:59', '2019-08-29 01:46:59'),
(297, 103, 5, 22, '2019-08-29 01:46:59', '2019-08-29 01:46:59'),
(298, 103, 5, 23, '2019-08-29 01:46:59', '2019-08-29 01:46:59'),
(299, 103, 5, 26, '2019-08-29 01:46:59', '2019-08-29 01:46:59'),
(300, 104, 5, 14, '2019-08-29 02:16:06', '2019-08-29 02:16:06'),
(301, 104, 5, 22, '2019-08-29 02:16:06', '2019-08-29 02:16:06'),
(302, 104, 5, 23, '2019-08-29 02:16:06', '2019-08-29 02:16:06'),
(303, 104, 5, 26, '2019-08-29 02:16:06', '2019-08-29 02:16:06'),
(304, 96, 5, 14, '2019-08-29 06:13:15', '2019-08-29 06:13:15'),
(305, 96, 5, 22, '2019-08-29 06:13:15', '2019-08-29 06:13:15'),
(306, 96, 5, 23, '2019-08-29 06:13:15', '2019-08-29 06:13:15'),
(307, 96, 5, 26, '2019-08-29 06:13:15', '2019-08-29 06:13:15'),
(312, 106, 5, 14, '2019-08-30 04:17:30', '2019-08-30 04:17:30'),
(313, 106, 5, 22, '2019-08-30 04:17:30', '2019-08-30 04:17:30'),
(314, 106, 5, 23, '2019-08-30 04:17:30', '2019-08-30 04:17:30'),
(315, 106, 5, 26, '2019-08-30 04:17:30', '2019-08-30 04:17:30'),
(316, 105, 5, 14, '2019-08-30 04:17:31', '2019-08-30 04:17:31'),
(317, 105, 5, 22, '2019-08-30 04:17:31', '2019-08-30 04:17:31'),
(318, 105, 5, 23, '2019-08-30 04:17:31', '2019-08-30 04:17:31'),
(319, 105, 5, 26, '2019-08-30 04:17:31', '2019-08-30 04:17:31'),
(320, 108, 5, 14, '2020-02-28 01:09:08', '2020-02-28 01:09:08'),
(321, 108, 5, 22, '2020-02-28 01:09:08', '2020-02-28 01:09:08'),
(322, 108, 5, 23, '2020-02-28 01:09:08', '2020-02-28 01:09:08'),
(326, 110, 5, 14, '2020-02-28 04:55:41', '2020-02-28 04:55:41'),
(327, 110, 5, 22, '2020-02-28 04:55:41', '2020-02-28 04:55:41'),
(328, 110, 5, 23, '2020-02-28 04:55:41', '2020-02-28 04:55:41'),
(329, 110, 5, 26, '2020-02-28 04:55:41', '2020-02-28 04:55:41');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `name`, `country_id`, `created_at`, `updated_at`) VALUES
(10, 'Colorado', 6, '2018-11-17 04:35:10', '2018-12-21 06:32:00'),
(11, 'California', 6, '2018-11-17 04:35:35', '2018-12-21 06:31:50'),
(12, 'Arkansas', 6, '2018-11-17 04:35:48', '2018-12-21 06:31:38'),
(13, 'Arizona', 6, '2018-11-17 04:36:03', '2018-12-21 06:31:25'),
(14, 'Alaska', 6, '2018-11-17 04:36:18', '2018-12-21 06:31:16'),
(15, 'Alabama', 6, '2018-11-17 04:36:34', '2018-12-21 06:31:07');

-- --------------------------------------------------------

--
-- Table structure for table `top_rated__providers`
--

CREATE TABLE `top_rated__providers` (
  `id` int(10) UNSIGNED NOT NULL,
  `Provider_id` int(11) NOT NULL,
  `Avg_Rating` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `top_rated__providers`
--

INSERT INTO `top_rated__providers` (`id`, `Provider_id`, `Avg_Rating`, `created_at`, `updated_at`) VALUES
(16, 3, '4.5', '2019-03-02 01:25:03', '2019-03-04 00:07:52'),
(17, 15, '3.8', '2019-03-02 01:25:03', '2019-03-02 01:25:03'),
(18, 11, '2.5', '2019-03-02 01:25:03', '2019-03-04 00:07:52'),
(19, 44, '4.7', '2019-03-02 01:35:59', '2019-06-03 04:34:12'),
(20, 7, '3.1', '2019-03-02 01:35:59', '2019-03-16 02:11:30'),
(21, 43, '3.5', '2019-03-02 01:35:59', '2019-03-04 00:07:52'),
(22, 37, '4.4', '2019-03-02 01:35:59', '2019-03-02 01:35:59'),
(23, 5, '3.7', '2019-03-02 01:35:59', '2019-03-04 00:07:52'),
(24, 40, '3.0', '2019-03-02 01:35:59', '2019-03-02 01:35:59'),
(25, 2, '4.6', '2019-04-11 01:09:04', '2019-06-01 02:53:01'),
(26, 49, '4.0', '2019-04-11 01:09:04', '2019-06-01 02:53:01'),
(27, 102, '2.5', '2019-08-29 06:13:25', '2019-08-29 06:13:25'),
(28, 80, '2.5', '2019-08-30 04:08:06', '2019-08-30 04:08:06');

-- --------------------------------------------------------

--
-- Table structure for table `useraddresses`
--

CREATE TABLE `useraddresses` (
  `id` int(10) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `country` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zipCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `useraddresses`
--

INSERT INTO `useraddresses` (`id`, `userId`, `country`, `state`, `address`, `city`, `zipCode`, `created_at`, `updated_at`) VALUES
(1, 2, 6, 11, 'Dilli', '27', '27', '2019-01-22 00:28:30', '2019-02-02 06:35:07'),
(2, 3, 6, 11, 'dehradun', '27', '27', '2019-01-22 00:30:14', '2019-02-02 08:17:22'),
(3, 4, 6, 11, 'Uttrakhand', '28', '21', '2019-01-22 00:32:06', '2019-01-22 00:32:06'),
(4, 5, 6, 11, 'Ropar punjab', '28', '27', '2019-01-22 00:34:52', '2019-02-02 05:49:28'),
(5, 6, 6, 11, 'Ropar', '27', '27', '2019-01-22 00:37:06', '2019-01-29 07:52:31'),
(6, 7, 6, 11, 'dehradun', '27', '27', '2019-01-22 00:38:31', '2019-02-02 02:39:24'),
(7, 8, 6, 10, 'Ropar', '23', '23', '2019-01-22 01:44:20', '2019-01-22 01:44:20'),
(8, 9, 6, 10, 'hahshwuuw', '23', '19', '2019-01-22 01:50:06', '2019-01-22 01:50:06'),
(9, 10, 6, 11, 'Ropar', '26', '26', '2019-01-22 02:11:42', '2019-01-30 05:16:00'),
(10, 11, 6, 13, 'Ropar punjab', '19', '30', '2019-01-22 02:15:54', '2019-05-21 00:34:27'),
(11, 12, 6, 10, 'Ropar', '23', '27', '2019-01-24 00:09:17', '2019-01-24 00:09:17'),
(14, 15, 6, 10, 'Ropar', '23', '19', '2019-01-25 02:06:31', '2019-01-25 02:06:31'),
(15, 16, 6, 10, 'SMIT', '23', '19', '2019-01-25 02:36:03', '2019-05-23 23:53:55'),
(22, 37, 6, 10, 'Ropar', '23', '19', '2019-01-31 06:24:29', '2019-05-21 00:35:52'),
(25, 40, 6, 10, '100 avenue street', '23', '19', '2019-02-04 01:47:32', '2019-05-21 00:36:26'),
(27, 42, 6, 10, '25 street downtown', '25', '15', '2019-02-04 02:01:20', '2019-02-04 02:01:20'),
(28, 43, 6, 10, 'Ropar', '23', '19', '2019-02-04 02:02:00', '2019-05-21 00:36:50'),
(29, 44, 6, 11, 'SMIT Ropar', '23', '27', '2019-02-05 00:27:27', '2019-02-05 00:27:27'),
(30, 45, 6, 11, '21 avenue', '29', '33', '2019-02-07 06:24:47', '2019-02-07 06:24:47'),
(31, 46, 6, 11, 'SMIT, ROPAR', '31', '34', '2019-02-07 07:27:37', '2019-02-07 07:27:37'),
(32, 47, 6, 12, 'Ghaziabad', '20', '23', '2019-02-20 00:12:40', '2019-05-21 00:36:59'),
(33, 48, 6, 12, 'Ghaziabad', '23', '23', '2019-02-20 00:13:36', '2019-02-20 00:13:36'),
(35, 50, 6, 10, '365 Queen St. Hialeah, FL 33010', '24', '26', '2019-02-20 00:44:10', '2019-05-21 02:11:46'),
(38, 49, 6, 11, 'RPR updated', '28', '32', '2019-04-01 05:32:07', '2019-05-20 05:25:14'),
(39, 50, 6, 10, 'Ropar', '24', '26', '2019-04-03 07:36:54', '2019-04-03 07:36:54'),
(41, 52, 6, 11, 'India', '29', '33', '2019-04-10 06:21:21', '2019-04-10 06:21:21'),
(42, 53, 6, 12, 'Ghaziabad', '15', '33', '2019-04-16 05:06:46', '2019-04-16 05:06:46'),
(43, 54, 6, 11, '365 Queen St. Hialeah, FL 33010', '27', '28', '2019-05-18 00:49:25', '2019-05-21 00:54:35'),
(44, 55, 6, 10, 'ROPAR', '23', '19', '2019-05-18 03:12:42', '2019-05-18 03:12:42'),
(45, 56, 6, 10, 'agdkkhdjg', '23', '19', '2019-05-20 00:50:18', '2019-05-20 00:50:18'),
(46, 57, 6, 10, 'xvxjxvsjsgsjdgi', '35', '31', '2019-05-20 01:48:46', '2019-05-20 01:48:46'),
(47, 58, 6, 14, 'bddjdhdjdgdjdgsish', '34', '22', '2019-05-20 01:53:56', '2019-05-20 01:53:56'),
(48, 59, 6, 15, 'zvzjzgsjsgsj', '33', '29', '2019-05-20 02:45:37', '2019-05-20 02:45:37'),
(49, 60, 6, 14, 'xbxjsvajagaig', '34', '34', '2019-05-20 05:24:47', '2019-05-20 05:24:47'),
(50, 61, 6, 14, 'dhdisgsisggsj', '34', '22', '2019-05-20 06:44:07', '2019-05-20 06:44:07'),
(51, 62, 6, 12, 'ndndnd', '21', '21', '2019-05-20 07:12:17', '2019-05-20 07:51:01'),
(52, 63, 6, 11, 'gshsjsj', '27', '27', '2019-05-20 07:21:53', '2019-05-20 07:21:53'),
(53, 64, 6, 10, 'dfgdfg', '23', '19', '2019-06-03 05:00:04', '2019-06-03 05:00:04'),
(54, 65, 6, 15, 'hdjdgdjsgsugdudgj', '33', '33', '2019-07-02 01:36:20', '2019-07-02 01:36:20'),
(55, 66, 6, 10, 'Chandigarh', '23', '19', '2019-07-12 02:31:41', '2019-07-12 02:31:41'),
(56, 69, 6, 15, 'shsjsgsjdgsjg', '33', '29', '2019-08-20 02:59:39', '2019-08-20 02:59:39'),
(57, 73, 6, 3, 'dehtjjdyjtyd', 'Perth', '70001', '2019-08-20 04:07:43', '2019-08-20 04:07:43'),
(58, 74, 6, 3, 'dehtjjdyjtyd', 'Perth', '70001', '2019-08-20 04:14:39', '2019-08-20 04:14:39'),
(59, 75, 6, 11, 'Ropar', '28', '32', '2019-08-20 04:17:53', '2019-08-20 04:17:53'),
(60, 76, 6, 15, 'zgzjsgwjwg', '33', '33', '2019-08-20 06:41:23', '2019-08-20 06:41:23'),
(61, 77, 6, 11, 'test', '28', '32', '2019-08-20 07:15:22', '2019-08-20 07:15:22'),
(62, 78, 6, 24, 'house no. 532', '35', '23', '2019-08-20 07:51:59', '2019-08-20 07:51:59'),
(63, 79, 6, 24, 'sgshdghdggehe', '24', '23', '2019-08-21 00:26:04', '2019-08-21 00:26:04'),
(64, 80, 6, 11, 'zgzdu', '27', '27', '2019-08-21 02:22:51', '2019-08-21 02:22:51'),
(65, 81, 6, 12, 'ropar', '21', '23', '2019-08-21 05:08:42', '2019-08-21 05:08:42'),
(66, 82, 6, 10, '365 Queen St. Hialeah, FL 33010', '15', '16', '2019-08-21 06:50:27', '2019-08-21 06:50:27'),
(67, 83, 6, 11, 'shsjg', '29', '23', '2019-08-23 04:46:58', '2019-08-23 04:46:58'),
(68, 84, 6, 11, 'hey', '28', '32', '2019-08-23 06:23:29', '2019-08-23 06:23:29'),
(69, 85, 6, 11, 'hey', '28', '32', '2019-08-23 06:25:29', '2019-08-23 06:25:29'),
(70, 86, 6, 14, 'xhxjd', '34', '23', '2019-08-27 01:24:07', '2019-08-27 01:24:07'),
(71, 87, 6, 10, 'dbjddgdhwuehe', '23', '19', '2019-08-27 06:09:27', '2019-08-27 06:09:27'),
(72, 88, 6, 13, '1234212223', '19', '23', '2019-08-27 06:16:29', '2019-08-27 06:16:29'),
(73, 89, 6, 14, 'eerrr', '34', '22', '2019-08-27 06:43:24', '2019-08-27 06:43:24'),
(74, 90, 6, 10, 'xhxhdge', '23', '23', '2019-08-27 07:39:40', '2019-08-27 07:39:40'),
(75, 91, 6, 10, 'dgdidgu', '23', '23', '2019-08-27 07:50:21', '2019-08-27 07:50:21'),
(76, 92, 6, 10, 'abc', '23', '19', '2019-08-28 02:32:38', '2019-08-28 02:32:38'),
(77, 93, 6, 10, 'abc', '23', '23', '2019-08-28 02:36:34', '2019-08-28 02:36:34'),
(78, 94, 6, 11, 'shzjdgdj', '32', '32', '2019-08-28 02:46:01', '2019-08-28 02:46:01'),
(79, 95, 6, 10, 'ropar', '23', '19', '2019-08-28 04:12:25', '2019-08-28 04:12:25'),
(80, 96, 6, 13, 'sjxkdh', '30', '30', '2019-08-28 04:36:38', '2019-08-28 04:36:38'),
(81, 97, 6, 14, '365 Queen St. Hialeah, FL 33010', '34', '22', '2019-08-28 04:49:49', '2019-08-28 04:49:49'),
(82, 98, 6, 12, 'fhfjfufydy', '26', '16', '2019-08-28 06:06:17', '2019-08-28 06:06:17'),
(83, 99, 6, 15, 'hdjdsusuuw', '33', '29', '2019-08-28 06:14:43', '2019-08-28 06:14:43'),
(84, 100, 6, 12, 'dbxjxgxjdysi', '26', '16', '2019-08-28 06:34:37', '2019-08-28 06:34:37'),
(85, 101, 6, 10, 'abc', '27', '27', '2019-08-28 08:08:21', '2019-08-28 08:08:21'),
(86, 102, 6, 14, 'dhxjxgdu', '34', '22', '2019-08-28 08:08:41', '2019-08-28 08:08:41'),
(87, 103, 6, 11, 'fhckchoe', '31', '34', '2019-08-29 01:44:55', '2019-08-29 01:44:55'),
(88, 104, 6, 15, 'gjfisuiwygsw', '33', '29', '2019-08-29 02:14:51', '2019-08-29 02:14:51'),
(89, 105, 6, 13, 'abc', '30', '36', '2019-08-30 04:06:03', '2019-08-30 04:06:03'),
(90, 106, 6, 13, 'acava', '30', '36', '2019-08-30 04:11:42', '2019-08-30 04:11:42'),
(91, 107, 6, 10, 'House number 1', '23', '19', '2020-02-28 01:00:23', '2020-02-28 01:00:23'),
(92, 108, 6, 10, 'Shop number 11', '23', '19', '2020-02-28 01:03:25', '2020-02-28 01:03:25'),
(93, 109, 6, 13, 'abc', '30', '36', '2020-02-28 04:27:01', '2020-02-28 04:27:01'),
(94, 110, 6, 11, 'House number 10', '28', '32', '2020-02-28 04:27:11', '2020-02-28 04:53:20');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` char(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` char(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `working_status` tinyint(1) NOT NULL,
  `services` int(11) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `image`, `referral_code`, `device_id`, `device_type`, `status`, `working_status`, `services`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Bhupender', 'Singh', 'bhupender.smartitventures@gmail.com', '$2y$10$3GnDiB.7CTyTuOc2ZKlL.eJmYk2WLDZtO1Q2agAGQjZ0ShtD1gWWC', '9690267595', NULL, NULL, '', '', 1, 0, NULL, 'nrIMdes3ORObC2htF8WiAHtam7uTFuHAQOkqdKtpLcFwXJS94uibTPG60WDh', '2018-12-01 00:10:03', '2018-12-07 07:13:55'),
(2, 'Shahzeb', 'JC', 'shahzebC@gmail.com', '$2y$10$aj/PpuozQGxqbI.abURaxe0pIYMEfyH/92i3GVJLwh9xfuI3I0Vja', '8860984985', '3313381558422282.png', 'AMDO21A2C6', NULL, 'A', 1, 0, NULL, '$2y$10$8W2KRsGp2f4evHZ0AGglauWIINbiLggJXkIfTN7mD4TyhyGdLJ0s.', '2019-01-22 00:28:30', '2019-05-21 01:34:42'),
(3, 'Thomas S. Romeo', 'Provider', 'shahzebP@gmail.com', '$2y$10$c4i48vdrtnIxr8xWLeOex.qXFTOEqoiRmC7Zl8K..46Gr/WGx4Aey', '9690267595', '5900021558418578.jpg', 'OT68J0AOCO', NULL, 'A', 1, 1, 5, '7LaLhhXrE60GMiJBPawbPRGY6MAY1WuuzzlBMrvXRowMOZ0HkiKKPVDnQ2ja', '2019-01-22 00:30:14', '2019-05-21 00:32:58'),
(4, 'Bhupinder customer', 'SmartItVentures', 'bhupenderC@gmail.com', '$2y$10$W4krmhgDnORAYwj7f42C5eJvrVmcCFmmOhdRTT2U4skpYcq6O/JXu', '8860984985', '1794341558422287.png', 'WFOCRFAD70', 'er6DDLxmU_U:APA91bGkz7ob3gCVeo5WsFR-WiJHFEzH4eYQ03ARTKzUwFozt3HVQLRghjAdK9OeyYJhfqAiWTNsvLdmR0B6spggGpmvE_JCfW6Kk_0Ee4no-XrZOutDI79z1mHnBWii78XUwmjxfy3M', 'A', 1, 0, NULL, '$2y$10$9PHFVgMbaGyyc5fbtFfEcuWzi4d7lfBiTpsT3EW1rjGYWGHnGRXkO', '2019-01-22 00:32:06', '2019-05-21 01:34:47'),
(5, 'bhupenderprovider', 'Provider', 'bhupenderP@gmail.com', '$2y$10$12ymJj4t2R9CyQS461S0fONclapgWY6LBA7ZiRfgaaY1n7bP2GhAC', '8860984985', '1149931558423986.jpg', '52FPHTSIER', 'e601hrjyL80:APA91bGDyRGsO6F0I-pK2MWKEt_O1A6cc7VSswZIp1kBwmmtZgTzP-ef-JgDdtbwpLQWeVPAKmkk0hK5V6N4ZN7tujRPGbyaGNd0IU-XsHW-46q69lwkH43QDt_eCmh2hz0m0Z4o4ymr', 'A', 1, 1, 5, '$2y$10$nm3v7Zgad5/Q65pqKYkNNexfxbdrk4rZvFRM2ZVnVoH.2OlIm.fUm', '2019-01-22 00:34:52', '2019-05-21 02:03:12'),
(6, 'Charanveer', 'JC', 'charanveerC@gmail.com', '$2y$10$33Wrj6ioHVG8krFo74cmO.2jdQT0C.TXsoEt2NKxTWiJbMPAfgN9u', '8860984985', '1902001558422299.jpg', 'QFCI0HZURZ', 'fZAVYwaZKs0:APA91bHVTmmE_fHEoixxfR2S9072VjRy1Y3cA_0rV3YmMs1Fjm7oei1y0AE8JD0-ZPUtCDNtmQYHL9oe7Hqlpq6zdqRmXVe_-EOrvw_264dPWx30opPfx0oICTw22d77Le7XolUCVt8W', 'A', 1, 0, NULL, '$2y$10$IRRzS5h2u0I7Bi3grpYWcOyVefMLhAGJY6keLT3vjgJNc2KW5C9m.', '2019-01-22 00:37:06', '2019-06-03 00:27:45'),
(7, 'provider', 'testing', 'charanveerP@gmail.com', '$2y$10$R9V2XGYR4PcUHKwekifkYuASxB0Hcqp0Y0IpgG5c0Azuom0nq/hHq', '9690267595', '2778861558418647.jpg', '9ZL6PVP21A', 'cDB3zyiB-ZM:APA91bFzqqdU0KXu1hqQQ8kz8D4x7ejLAL_nSFLbJotpPIrxXHimGBfEnfmqyumDCMEnCfVNh8BFCntO1fnnXKnIOCTSRoU1WyrczhTEta4ILG7GQmKljC8rhSnT0tY6UjT-gq4Xhi8b', 'A', 1, 1, 5, '$2y$10$k51Hz1xCCFC62FRO9njGAuiIlM0cLdL6XYrJXAC7/ZtMr9dueXLJi', '2019-01-22 00:38:31', '2019-05-21 00:34:07'),
(10, 'Customer', 'JC', 'customerNew@gmail.com', '$2y$10$R94mtluFEC0EVMEIc6nf/uL9KWOVdi1VNRMnvCIGogNIbEJBEwtUu', '8860984985', '1096381558422344.jpg', '0JAZGF9K9H', 'eJbH5xv-9Hc:APA91bHff1zkqji8UP4bi-Y_yjsn0kivtsPlI7LvgzIRnWtK4tq2R3lLi120s3qhtHaoAzpGPFlJhFSTK2gorYKvCsEu9w0W_wv-D6VzAIeWNguK4gKOqh0S0qfvUkZ5XARfmZseqK7b', 'A', 1, 0, NULL, '$2y$10$gbJz.lSAL35KcC7qcG/OIeYPGpbAhQmkw/4mbtIbnULiGCn52kHWC', '2019-01-22 02:11:42', '2019-05-21 01:35:44'),
(11, 'Jose B. Lee', 'Ajay bhatt', 'providerNew@gmail.com', '$2y$10$0/PfY7a8feq.FiUUXxab4esoJT1Nwe5vsQCPNHFHns0szPltMS25W', '8860984985', '895631558418667.jpg', 'FNF46Y0CH3', 'du0r_aYVg4c:APA91bEM98eZaOYCnmXRUXeXsH3UwYiETvftRZc1w2KC3wcs_UNDUfqchP9HBVGGBZ41QldlU0Wib2BYNpMP-QXsIdlmrIILDHqi-xmnJ8JfjTebia-orE5waU-9nnsaUYeV4TqAgj1_', 'A', 1, 1, 5, '$2y$10$QrZXYPKi/MsC871KiJeGhuMnXtxt3cG7YhfFGniWtbPATP4in/saq', '2019-01-22 02:15:54', '2019-05-21 00:34:27'),
(12, 'Test', 'SmartItVentures', 'Test@gmail.com', '$2y$10$AcM.r7IGt4jWktZuMyIdMOKthfFy.MqlYlSkoVBzk21gwha9PY6la', '8860984985', '6790321558422020.png', '7HTEGGYJMU', 'du0r_aYVg4c:APA91bEM98eZaOYCnmXRUXeXsH3UwYiETvftRZc1w2KC3wcs_UNDUfqchP9HBVGGBZ41QldlU0Wib2BYNpMP-QXsIdlmrIILDHqi-xmnJ8JfjTebia-orE5waU-9nnsaUYeV4TqAgj1_', 'A', 1, 0, NULL, '$2y$10$FnKmkXZyUmI2s7aGqZO3AecHoeF.9Xrj0KaNjCbKDsI2mODKlJpn.', '2019-01-24 00:09:17', '2019-05-21 01:30:20'),
(15, 'Annu', NULL, 'apiOS003@gmail.com', '$2y$10$aB6jw.bpta.lLtCTnIsXpO9FH95Ha2JV1R0jV8KE9161dhu49VXHO', '9877762277', '3308181558419875.jpg', 'YEUB5LYZS9', 'dXbl-Ld_M1o:APA91bEgdnKFNRF5bsvUnoASYFlcmmlv7iGx8M1CXCW6PBbx4s9VNv5yPvI_ObfOKQVo_CrsPW6WyotME2PPOflezSs5bjT41zZI8pBy29NOkA1SGuon_EtDc8xntw0KuUC4V8VWzP-3', 'I', 1, 0, NULL, '$2y$10$qQWJe01Isg37cU4uokQ7luElGjjE8KpCc/Hs6JnoVT1C8x.GxwPIS', '2019-01-25 02:06:31', '2019-01-25 02:06:31'),
(16, 'Annupriya', NULL, 'testiOS003@gmail.com', '$2y$10$fKzSD0BYZLs69FPfVdVwt.MjHa6dFog2vcPE6vyz58vaQuGxzDwQC', '864235789', '2280321559387429.jpg', 'XBDJ58T276', 'elcBjWgXI-E:APA91bEhNKrv4LGiIhfsNS0a62A3u47m8GvgqFE8wPshcVQW3yO_HEGBtqxUg2vxPcoK7QyjjfOgS1tVcoB_ytdXOpF93YBx7JccueIjUP8sreaNYdpqfkFxotFWRuHngQWJ8BeFMhsd', 'I', 1, 0, NULL, '$2y$10$6Z.ie65O8xD21DhsnY7wvuWkKhuN4iUARR2POCLIrIfuDDhQ3uDqW', '2019-01-25 02:36:03', '2019-08-30 06:39:00'),
(37, 'Alphalota', 'Provider', 'alphalota@gmail.com', '$2y$10$7hLedNFo9zrA0Ou6MP7NteFc/GcbJ5ST/yoghHfqxlOF13QF5JuwC', '8860984985', '2463801558418682.jpg', 'I27KMSDKB8', 'c5MW_ItkuC4:APA91bHsYd9-dsPz4NckZaPF8wnW8e3NO8ZU0Y4TPSiAlNfYMg0RYTq1sBjM1Ughi_IE1YOWNcghvpTXYzCYmIIctaOILmSr3J0dFRRs0b5YTfxsXhvKVopdCf32SaMVxunqlz3VDlUQ', 'A', 1, 1, 5, '$2y$10$PzmtISCDZxOurumVg0PJCeszBeruT760tBEnBCpDf74K8Arfip0FW', '2019-01-31 06:24:29', '2019-05-21 00:34:42'),
(40, 'harry sharma Provider', NULL, 'hemantbadola7@gmail.com', '$2y$10$sf4zvF3IeYc5jEqnVcYUYu1TigxsXdyZ7tpZ3RgYC30rpN8KAPhR.', '9988264926', '582761558418799.jpg', 'TALJ34AYF7', 'cDB3zyiB-ZM:APA91bFzqqdU0KXu1hqQQ8kz8D4x7ejLAL_nSFLbJotpPIrxXHimGBfEnfmqyumDCMEnCfVNh8BFCntO1fnnXKnIOCTSRoU1WyrczhTEta4ILG7GQmKljC8rhSnT0tY6UjT-gq4Xhi8b', 'A', 1, 1, 5, '$2y$10$5EkeSofxhYHRSpuS1QntZOmblflOban1EXBT9UGEUFbqlMrxS2bIm', '2019-02-04 01:47:32', '2019-06-01 03:06:39'),
(42, 'hemant', 'SmartItVentures', 'hemantbadola1994@gmail.com', '$2y$10$tIE03LKShO0wTeh3J6Fs3urDHay/VyZiNIrdiIaCdkGCllCLz/jDu', '9988264926', '1715321558422325.png', 'XYDZ92N4MS', 'du0r_aYVg4c:APA91bEM98eZaOYCnmXRUXeXsH3UwYiETvftRZc1w2KC3wcs_UNDUfqchP9HBVGGBZ41QldlU0Wib2BYNpMP-QXsIdlmrIILDHqi-xmnJ8JfjTebia-orE5waU-9nnsaUYeV4TqAgj1_', 'A', 1, 0, NULL, '$2y$10$GKA.KRN3VCu8hkSs0J1dpOdEpildPqsyoXoBCE9WesIvsZ1Af6VSe', '2019-02-04 02:01:20', '2019-05-21 01:35:25'),
(43, 'pankaj provider', 'Provider', 'pankajP@gmail.com', '$2y$10$ze4hViBySuztc9rHOMZfMuG5L2yt9YS84RlWjf9iQmGSADB7Tz4A6', '8860984985', '4955381558418810.jpg', 'ON57HXW0CB', 'fGvL5klUzwc:APA91bGr2229qUW4B0zcZma8EkrPZkHgZk0ZmFhp-Ji9eS17A0vWeaKwQ0wkp8RjJp9-U6oRYWDCxoGMwhzJJxY8P1W_4wCM9IxvoEun_JtW66USZXSqsjc53012iUkyYbRKtkTAEPGC', 'A', 1, 1, 5, '$2y$10$lx0NeJ0tZp3eXIvOGaHqqettEmeqYbTF6wpveIX94Ng0kCQkthoeC', '2019-02-04 02:02:00', '2019-05-21 00:36:50'),
(44, 'testAndroid', 'Provider', 'testandroid003@gmail.com', '$2y$10$Q01DW/eu5EUHz8sFVQpVSuDNZSwMyVekWH9LaWUwkTnGvKT9ved.q', '1456328769', '2463801558418682.jpg', 'QZGLHAPXBQ', 'cc8an5MSj_A:APA91bHrlZnpy3IFmcgEleQhIgWKSM0u68wlBdWmm35uILcsk3HottB4YZlqE7dKiZy13BWt4ryJQvRsh1SGxmhBZmyc5UfzG7fCOo-gnhnf6_bEvT6VAIXH1fr-R8P1YZO391-Hjx8P', 'A', 1, 1, 5, '$2y$10$6OsEebRhyEpyTv0uHWMbMe/UZMFFsJw2QDnjEsKtghzqCjQ5mRc1m', '2019-02-05 00:27:27', '2019-02-26 03:13:50'),
(45, 'John Legend', NULL, 'anpuriya.smartitventures@gmail.com', '$2y$10$tToUSVrbQShFc3wnw5J1RuNzukiVrJRizKWVO86tzg7wjOp3FB6ia', '9988264926', '2149181558418851.jpg', 'O31NXAZYQZ', 'fwlF_d7tXHY:APA91bFR-gLhFuTvUcpx_TY5rhdSifoOUmp-CljVi4__Qu1X3obKvjzA8yotoB6P42cIarTBHf4O9PIA4Tc1V37TkDCgI9e_VcAOx_TMeYxrGLOo9Zm_YBZB0dpoSrGp_uJuIUexo3HN', 'I', 1, 0, NULL, '$2y$10$loHZG1wxWYWmoLG8VNdUYeZx6sLQwo4mxq3bLltSPFCPleB8kYwoK', '2019-02-07 06:24:47', '2019-02-07 06:24:47'),
(46, 'test123', NULL, 'test123678@gmail.com', '$2y$10$gkBMYKH6rQae2VnWC2KWVu3KRKJAVV91xosIikNRTKzOyiu0Tohw2', '62433311445', '9915741558418840.jpg', 'JYXE9R380Y', 'fYV-YV3-1UY:APA91bFJ_NuAnDdU7Vi2aV9IF9hhowuyGBIgoShGp1bJlxip2jasdHKPEyrk7ESSID-efH2ZtO-ndiv75MaIR__WSiebVeuVqiyrDhvoaNW8YeF7Mb2OHT5UvfKeXnxgfTZ1Vmtl-2xb', 'I', 1, 0, NULL, '$2y$10$4EufXB2QnqWAnV8.dc5VJOGRlG50/DMaB5XJm8iw4g/ra6HdT8cOW', '2019-02-07 07:27:37', '2019-02-07 07:27:37'),
(47, 'adminreferal', 'testing', 'testingreferadmin@gmail.com', '$2y$10$qil9xd2ZEwsTk.44/eQbN.gxaEfPOfU9A1bj6jMjH6yGlwvuWMOpG', '9690267595', '6349011558418818.jpg', 'H5TVTUJSYS', NULL, NULL, 1, 1, 5, NULL, '2019-02-20 07:06:38', '2019-05-21 00:36:59'),
(48, 'cleaner5', 'SmartItVentures', 'cleaner5@gmail.com', '$2y$10$aqFLO7s75Ijwb5g5kY/Iyexbq8jhbFwS4qJPNKNQ46LLTl3mm6lcS', '7863452269', '5787851558422253.jpg', 'EENR0ZOFQO', 'cF6td9L8G2w:APA91bHRgsvCuLgGw014NyqBPuSsJWjMlXZJiXygT-n7WzlyNdu1GFvMmpcG3F5GXC5HHui8vBLrKhIDBiNypgiwCWrTOwZiqVRy5dx8ofCyls9d7SVi0VL4RUUnv0ZnTJITn3spm7Ao', 'A', 1, 0, NULL, '$2y$10$LGTycbmAAZhfEe0uAyXB1OzMDppXxp5DkHRijcny/oSDuOXhqsilW', '2019-02-25 00:26:07', '2019-02-25 00:26:07'),
(49, 'hi', NULL, 'shubhamsmartitventures@gmail.com', '$2y$10$gzP3lbDxMDi1KzXBQdKC4OShzoFxECHrAI3L.eCY6HPMLe1q3YxSe', '123456789', '9915741558418840.jpg', 'G86YMI9J3O', 'cA371bdiJaE:APA91bGxoTniEtUNDJwQ9eeIFY-wMgWEO6gGzgBltlzPAIiK-g-aXZ2KKFgKDb_4U5OUvZxxlbRp8tiSECwBUZ0bNrKQWmJ5p7M7LSB0JswGCHSyr3HYBc3w4ElNkcEv4mJL-EDDumsM', 'I', 1, 1, 5, '$2y$10$sW8WD6OI3GAzrpWQqX1LPeU4lygMpzPP8mEG6Iwy1FmXE5W4QbZOe', '2019-04-01 05:32:07', '2019-08-26 08:18:12'),
(50, 'testing', NULL, 'naiyer.smartitventures@gmail.com', '$2y$10$pn0M1FsKON4PPkbqKBwBJu4akMeaQQ.0s6r3YYXaPbFdX8a2K9nte', '77878077867', '9383181558424506.jpg', 'E7I3R6W2B0', 'fIZGr3p-85A:APA91bEUUeEaNjSdc4wm59UFpoS0u1wpQ6v_9aJz86pvF43JVZmmTFjwPD1D9AXGwGmkh0reEQUPCNh5pqk5WuTQOEzl3f5pWoF8gflf-FCNCVP0Xk1z4H-2Sd2yuBh4FnZ3CRVoFaXR', 'I', 1, 1, 5, '$2y$10$jLYO9WHY4liPMQI6TOjcnOoF4VO0O2rZ2DOsA/0UTjwd3A9qVGakK', '2019-04-03 07:36:54', '2019-05-21 02:11:46'),
(52, 'Baji', NULL, 'shaikbaji1911@gmail.com', '$2y$10$97PcO5HYhNnNdDvKomBkzO/BdCnyj1ITVlcHoexH.g6u7W8OLd6su', '3652804768', '7187861558422107.png', 'HWM5CEWYFM', '38FBD249-F6BC-4459-B8F3-02C5BE998DC2', 'I', 1, 1, 5, '$2y$10$W.2lvlF3Sl/crsxifmQe3Oc.m9pKSvuy8arMsPtdJsXMlbjZFcP16', '2019-04-10 06:21:21', '2019-04-11 01:09:24'),
(53, 'ReferalCode', 'TestingReferalcode', 'reffercode@gmail.com', '$2y$10$surzELc63qT7InK2dhcREOnp.ia0TiznLgf9aYeHk5vAys813spxm', '9690267595', '5787851558422253.jpg', 'ESQLN58U0V', 'fgwfddffuifdfufdufdufd4fg65d4g5f', 'A', 1, 0, NULL, '$2y$10$O2GFER179P6LKI/2zrhAUOyptLIA8RFhhVzjyG52/5VoB5y.HFu8K', '2019-04-16 05:06:46', '2019-04-16 05:06:46'),
(54, 'referprovider', 'testingrefer', 'providerreferal@gmail.com', '$2y$10$QYLqQ9oEXlnZoeKwzxDSWe31iL56oHD0QgEI37JE7efRdSBNinCWK', '9690267595', '3308181558419875.jpg', 'O6NQ9524RJ', 'fgfgffg', 'A', 1, 1, 5, '$2y$10$ymddnzuBgjWM5BngdHsbe.u75OO/UegUd/rHccAV7DKp37toqjTvG', '2019-05-18 00:49:25', '2019-05-21 00:54:35'),
(55, 'Charan', NULL, 'charan123@gmail.com', '$2y$10$V5a5oQ2ZBUqXDZO0mQZOFeuPY96OYntE2QMZPZVtx3cfVgXsTp0pC', '985368418', '5787851558422253.jpg', 'MGZJ7GEANB', 'evIkL5JZV7Q:APA91bG5FmW2RyGSIvqX_gqXq5W3rr42yK3Hu9qOPAjCk3oFA7M2H3y8OqUndV8BKCPawRbx9-OaUGto1wKnOkDtlX-Gh4EDNwS-2dygyoWZMDOsdGGICjAaj4M_EAAhq5I0A5wImOCn', 'I', 1, 0, NULL, '$2y$10$dMeVzmzZxATqjZz9VZ7KyOxafZjckyLgnBBIR17AHPTfmIv2hdO0C', '2019-05-18 03:12:42', '2019-05-21 01:34:13'),
(56, 'gdnjgd', NULL, 'fjzgmehk@sdhjt.com', '$2y$10$T2qm2mZNNS.8Ef9lXl74EOJ.W7/qUqGKwLjRqz1frbJZmpdjkCKqu', '6456459855535', '582761558418799.jpg', 'VNNWHI2DEH', 'evIkL5JZV7Q:APA91bG5FmW2RyGSIvqX_gqXq5W3rr42yK3Hu9qOPAjCk3oFA7M2H3y8OqUndV8BKCPawRbx9-OaUGto1wKnOkDtlX-Gh4EDNwS-2dygyoWZMDOsdGGICjAaj4M_EAAhq5I0A5wImOCn', 'I', 1, 0, NULL, '$2y$10$mXPXdRiJkaWSpvJu9PzP6OTeytOrPNSSTsDV8V8Vh24O9CcrEEctm', '2019-05-20 00:50:18', '2019-05-20 00:50:18'),
(57, 'charan', 'SmartItVentures', 'charan@gmail.com', '$2y$10$72RYUR0TFKnxhMuPkqq2euv3mqmPC5cEaUWlb3XUKmAvMXVMdnWji', '894675767575', '5983981558421327.jpg', '5NV6JWCVK0', 'cVx8Ooc042Y:APA91bFrYec7yrUAPV29ePad_d_KQXzwjebgijAc8d3GwyTn4f-HHS1ZP4RRjuJ5xraZE3fm4zpq31bmuPv4hLbvu6snED68uHn0IEhiz-pDje3qm-WnUiKEr3QX5ImUA8gqtn4vcD_j', 'A', 1, 0, NULL, '$2y$10$yZc2LD6C/IVAXyon9pTWYuNj00K52xmElaShPool57j3zViBbymDu', '2019-05-20 01:48:46', '2019-05-20 01:48:46'),
(58, 'charan', 'SmartItVentures', 'charan1234@gmail.com', '$2y$10$eDiqvPK6jePC8i5S4gaRf.2P7DcrsesWAn7aU0aqulzVgXDS2Vtpi', '1225487542', '578041558422191.jpg', 'G5ZYC500UO', 'cVx8Ooc042Y:APA91bFrYec7yrUAPV29ePad_d_KQXzwjebgijAc8d3GwyTn4f-HHS1ZP4RRjuJ5xraZE3fm4zpq31bmuPv4hLbvu6snED68uHn0IEhiz-pDje3qm-WnUiKEr3QX5ImUA8gqtn4vcD_j', 'A', 1, 0, NULL, '$2y$10$wVq2l.U.R5GRsU1XxbDi6.AQiAhv/G7rXSi9/xXIwyiCgrdbz/KsS', '2019-05-20 01:53:56', '2019-05-21 01:33:11'),
(59, 'test', 'SmartItVentures', 'test123@gmail.com', '$2y$10$2RElRINpdh/pBOHgTKjHHuTScs70cfz9ClVb0YG9lD9DcD50Ae8US', '1254255542', '7187861558422107.png', 'A65Q2HCPDM', 'cVx8Ooc042Y:APA91bFrYec7yrUAPV29ePad_d_KQXzwjebgijAc8d3GwyTn4f-HHS1ZP4RRjuJ5xraZE3fm4zpq31bmuPv4hLbvu6snED68uHn0IEhiz-pDje3qm-WnUiKEr3QX5ImUA8gqtn4vcD_j', 'A', 1, 0, NULL, '$2y$10$7hkQToeB8emSY/aLZkJi/upKRkdcJ1CFnsGVkypBFOMPFnlXk4TAK', '2019-05-20 02:45:37', '2019-05-21 01:31:47'),
(60, 'charan', 'Provider', 'charan13@gmail.com', '$2y$10$FoSn0tg3Y1BWQx6lYkKDfO21v7uB142i47/ERffWhB5AL0WVvPPbu', '4587542154', '5983981558421327.jpg', 'SLKSLGT4T0', 'eKKLPZbFJ98:APA91bFUZ5ARkFf29PMOoHkNAltGy2KipP8MMvsAv7IXUSS2k32IY7R1W5el38gQtc7lWsvOySM-I8tY44RV7_Fmmly9ZddlHDFx028p9mvspsUwtuOqMXAIdjzqzZKuZXu8UJnTOtyW', 'A', 1, 1, 5, '$2y$10$xHFuhC1B/VihjxExJGewluIFV/Nw.xAHDGb2xsoBJDkFbro/8c5Fu', '2019-05-20 05:24:47', '2019-05-20 05:25:25'),
(61, 'charanveer', 'SmartItVentures', 'charan12345@gmail.com', '$2y$10$pM.DnWcF3UeWTMJiOdizY.iJbXKeTA1wkeypL442OSxbjEp5mjRoG', '12546372846', '3308181558419875.jpg', 'X2YAAP3CKW', 'dR2LZib6MD0:APA91bGU-VQOwOFN1uD9Mb9rWS5DdS2viuuiJsR250oBqFtxc3vDhXizuKSSab95N0YkyxQdHk2__sUI5NUKZc9_pzIBCkh1baRa7U3O83o3gQv8iyaT7BZ647jIlxFfUuvdJhCHfnwJ', 'A', 1, 0, NULL, '$2y$10$fJSDWYuXD4ocYJGtHwxTde9OJlz1t3sf110z4wFlDKGw5q7ocg/li', '2019-05-20 06:44:07', '2019-05-20 06:44:07'),
(62, 'Harry', 'JC', 'hemantbadola@gmail.com', '$2y$10$nkMC85K2c78a12Ce90O4guMgQ.Q6O79QvZCtWiRQh98fVykXJdci2', '57873491', '5983981558421327.jpg', '163X4SB481', 'cVx8Ooc042Y:APA91bFrYec7yrUAPV29ePad_d_KQXzwjebgijAc8d3GwyTn4f-HHS1ZP4RRjuJ5xraZE3fm4zpq31bmuPv4hLbvu6snED68uHn0IEhiz-pDje3qm-WnUiKEr3QX5ImUA8gqtn4vcD_j', 'A', 1, 0, NULL, '$2y$10$QskdKnz8HCXX298QM2F3JOG717VqYCeWpmWb4zUrKRMq6PmfNhb06', '2019-05-20 07:12:17', '2019-05-21 01:18:47'),
(63, 'bhupender', 'Provider', 'bkanyal824@gmail.com', '$2y$10$8sVApRFfNCshSjTq1dugcO10sU5ey86yb9eZii6HZNNIVFCkET0da', '9690267595', '2149181558418851.jpg', 'APD0OFJKSD', 'ezpy1Nbs0Hc:APA91bH1G0ttliyQi1QZBNo0GdDtGK8zFwfaPHtNNhm9eqnfZ5XCuwDPyViyx-vgGishjtsvCGvMjor0PSgIS0-FoD4YhBjHQnBid6jpz787ys5rZ_C4mfmA4h4PnYNRcLpijVg_EA_6', 'A', 1, 1, 5, '$2y$10$/g8wq6sB7OMmpLpBVl1MR.89SIyCmAMEzHpsahnFFR/64iyNa9G7.', '2019-05-20 07:21:53', '2019-05-21 00:37:32'),
(64, 'dfgfg', 'SmartItVentures', 'charan12345444444@gmail.com', '$2y$10$GAUbaITz..n2ycNRrHd4sOqKbwqT/vz1LGfQ5R4anclsHZwimRP/S', '125478568', NULL, 'G4L0722M4X', 'fZAVYwaZKs0:APA91bHVTmmE_fHEoixxfR2S9072VjRy1Y3cA_0rV3YmMs1Fjm7oei1y0AE8JD0-ZPUtCDNtmQYHL9oe7Hqlpq6zdqRmXVe_-EOrvw_264dPWx30opPfx0oICTw22d77Le7XolUCVt8W', 'A', 1, 0, NULL, '$2y$10$r5XCUXYPq31k/22dVsNzIeQZb0xofNk1QBs3jY9g9tr2153dbVn7e', '2019-06-03 05:00:04', '2019-06-03 05:00:04'),
(65, 'charan', 'Provider', 'charanveer.smartitventures@gmail.com', '$2y$10$POckdlWXsLXhUJYt93JlSeKF6/A5Qo5SUMzUFbQYp3vb02KMprrNq', '1254875421', NULL, 'ZA169DVSU6', 'e2rnnPavJWQ:APA91bGUQDmRirBLgrDbKBFdhijdn3JsaKtuqvG5VquRcMaemmUYLw_ULgq-u2fjubZYWCxU8in-8scBGg2d0ZkOaBwBE19h6XXlsHZukeAIQmfA5eHT-DLF3ZK0InAax5I-WyOQxnJS', 'A', 1, 1, 5, '$2y$10$HZ2LeeljhXmSY4ZcQmlnouXOskhYGFhYoSrGAaV9SmzVIU25eV.u6', '2019-07-02 01:36:20', '2019-07-02 01:40:33'),
(66, 'shahzeb', 'SmartItVentures', 'shahzeb.smartitventures@gmail.com', '$2y$10$oURTMWyFZVrAGd6l4zvtz.1iN69xSBkBitxfjXc7AhetG5/hiWuX6', '1234567890', NULL, 'JV2G69AS22', 'cY8Vhjc4NSE:APA91bELJX9I8QHel5OsZm6M5JgoMF2RONT3jeNFgc4_ZgGyKAgu6jcLs1jz8W0nWvcisDHY69hQNMNeltdHSUDrKcux0rRHzMRxsRIX8_K7wEoeC4Mdgu4IbgbhGpNE3_vW8EWIxJJF', 'A', 1, 0, NULL, '$2y$10$B7pylPMka1qYzttrBYHKaeBVqebPxhVbfHO25VFD3v0cQt66YDm96', '2019-07-12 02:31:41', '2019-07-12 02:31:41'),
(67, 'guran', NULL, 'guran@gmail.com', '$2y$10$US4DncATy8I7Ikx/0u3UCeaL7hppKvX.L2C4IUwdriMU/rppdbrua', '14254875', NULL, 'W1RQTC2WBZ', 'cJJhtcU-yEo:APA91bEcNkBlNtoL--aUYRc7vtOtVmkRKXBDA5d3aWCsyPbfqlkRGE50KooKwNGUqdwV_YP6Cz2xlwzteCHRGXmYg2v07YTt4DIzzB6HrlIr_uJvxoUG1mQwCW0CYVMnvJ8S_gduVcPi', 'A', 1, 0, NULL, '$2y$10$O/2nspD5Lxp5o3OI7VSfQO/veXDRR42.JlqNAPcUdKkvDfpSiTnY.', '2019-08-20 02:57:58', '2019-08-20 02:57:58'),
(68, 'sdfcsd', 'dscsdcdscd', 'sdcn@gmail.com', '$2y$10$R/5zTpsIkrMSuCFrFH7sTOCKvQn/gGKDGVBAy3ZkiMA/c.9soo/yi', '14254875', NULL, 'SX5HMFNRJP', 'cJJhtcU-yEo:APA91bEcNkBlNtoL--aUYRc7vtOtVmkRKXBDA5d3aWCsyPbfqlkRGE50KooKwNGUqdwV_YP6Cz2xlwzteCHRGXmYg2v07YTt4DIzzB6HrlIr_uJvxoUG1mQwCW0CYVMnvJ8S_gduVcPi', 'A', 1, 0, NULL, '$2y$10$CDB7U89OQEXFZ8lYlJA9SuZEyrzH4Zb42i57t7gj4vTzEslVthDFe', '2019-08-20 02:59:04', '2019-08-20 02:59:04'),
(69, 'charan', NULL, 'charang@gmail.com', '$2y$10$CmLeTfzlw5hpSqDJAlUIg.2M300mJTqA97c1Ld7rwWiMcXK5ggynO', '1254875245', '7863731567157812.png', '3FOP1RFZ2D', NULL, 'A', 1, 0, NULL, '$2y$10$HTN12VvJNmDUsQf9QidbfeFHOV0tdREuGyTC8jIMBFMtWx53D5fSS', '2019-08-20 02:59:39', '2019-08-30 06:07:39'),
(70, 'sdfcsd', 'dscsdcdscd', 'sdcnmk@gmail.com', '$2y$10$RHYTmm0c1OjGuauQv4zCQeCpuNUULG/qajJ7wq7NPnCwj.3tbFWaG', '14254875', NULL, 'U7746GS0IO', 'cJJhtcU-yEo:APA91bEcNkBlNtoL--aUYRc7vtOtVmkRKXBDA5d3aWCsyPbfqlkRGE50KooKwNGUqdwV_YP6Cz2xlwzteCHRGXmYg2v07YTt4DIzzB6HrlIr_uJvxoUG1mQwCW0CYVMnvJ8S_gduVcPi', 'A', 1, 0, NULL, '$2y$10$02Yn4N31X8dXiw2IQeFmQukoF9jNBgI0LPZYKZe/DxuoUZ70N4bbO', '2019-08-20 03:07:46', '2019-08-20 03:07:46'),
(71, 'sdfcsd', 'dscsdcdscd', 'sdcnssmk@gmail.com', '$2y$10$E4sCi523ipJ.7zL0uyBWkOhv2OIQaq7EUJYU5tFXYaTEHx3UwFq4G', '14254875', NULL, 'SXPU5QTY8J', 'cJJhtcU-yEo:APA91bEcNkBlNtoL--aUYRc7vtOtVmkRKXBDA5d3aWCsyPbfqlkRGE50KooKwNGUqdwV_YP6Cz2xlwzteCHRGXmYg2v07YTt4DIzzB6HrlIr_uJvxoUG1mQwCW0CYVMnvJ8S_gduVcPi', 'A', 1, 0, NULL, '$2y$10$FIjltHjOplfovbNmkosyDeZzQHswpnIBxC2EsoLm8z1oLkC/Gjn8q', '2019-08-20 03:59:58', '2019-08-20 03:59:58'),
(72, 'sdfcsd', 'dscsdcdscd', 'sdcnssmkd@gmail.com', '$2y$10$kAZGCugCzvXrj4M2.yZ4gOyrFuFenN.7v8VjXZHA19F2.jzV6vjZO', '14254875', NULL, '576CIEMB04', 'cJJhtcU-yEo:APA91bEcNkBlNtoL--aUYRc7vtOtVmkRKXBDA5d3aWCsyPbfqlkRGE50KooKwNGUqdwV_YP6Cz2xlwzteCHRGXmYg2v07YTt4DIzzB6HrlIr_uJvxoUG1mQwCW0CYVMnvJ8S_gduVcPi', 'A', 1, 0, NULL, '$2y$10$g/eFu/Ri.sru1SiokoL50ex7NhwlwylYu36qe2.q6UWJiA1c3dpJK', '2019-08-20 04:06:47', '2019-08-20 04:06:47'),
(73, 'sdfcsd', 'dscsdcdscd', 'sdcnssmkdd@gmail.com', '$2y$10$TBeyeocjfrFTfdwXYzwCi.6vSID0GebvbCctK9MiZUhfeuUug2kbC', '14254875', NULL, 'TFA2OCSMTR', 'cJJhtcU-yEo:APA91bEcNkBlNtoL--aUYRc7vtOtVmkRKXBDA5d3aWCsyPbfqlkRGE50KooKwNGUqdwV_YP6Cz2xlwzteCHRGXmYg2v07YTt4DIzzB6HrlIr_uJvxoUG1mQwCW0CYVMnvJ8S_gduVcPi', 'A', 1, 0, NULL, '$2y$10$4SJJGD3dEpEIDa.YqyeZ/O1Fz7hMEtic6zxOaBcybdDjH3CLF5aI6', '2019-08-20 04:07:43', '2019-08-20 04:07:43'),
(74, 'sdfcsd', 'dscsdcdscd', 'nmu@gmail.com', '$2y$10$Xya8z78nEajASr003zau0.sU6Gwf5xAWg1u7CqiPGtHrUQgQ/XvWq', '14254875', NULL, '33NUWN8TKA', 'cJJhtcU-yEo:APA91bEcNkBlNtoL--aUYRc7vtOtVmkRKXBDA5d3aWCsyPbfqlkRGE50KooKwNGUqdwV_YP6Cz2xlwzteCHRGXmYg2v07YTt4DIzzB6HrlIr_uJvxoUG1mQwCW0CYVMnvJ8S_gduVcPi', 'A', 1, 0, NULL, '$2y$10$1Ef3iQAPf8qvkqoL/DJRkOKuxfBWnB1r3HM/ZOOHYid70yppJQFyG', '2019-08-20 04:14:39', '2019-08-20 04:14:39'),
(75, 'Annu', NULL, 'ap45@gmail.com', '$2y$10$J3q2ihsA7/RuNihBEnP1r.ngglaP0/usG72ZYrvKRJo47NSCkqQx2', '9534811432', NULL, 'XIFKAW2SXR', 'c5sCrr2N_ZU:APA91bHCtWbEV9TaCF1JWz1bjqUTmpag5iraNQteg2reQSfGRb6557UnIfEfSrj3Ev8hhurTw0Rz0S_TA9zInmnrMPbzgqOevUgMwcT2lpU5jIX6V3uslcYiREWq_AH18Hpdy1TvJkPI', 'I', 1, 0, NULL, '$2y$10$qX1a8sSvd4SivclG57r9cOSh1fti1fu8edgP3BRle.xTg0Hj5G2I2', '2019-08-20 04:17:53', '2019-08-20 04:17:53'),
(76, 'charan', 'Provider', 'charan3200@gmail.com', '$2y$10$h0VfqVzf9k8VzbHOE.HdM.S1cSUdUUkaT1jtty2tWklzp5fK/GNE2', '45781245', NULL, '84P6MHYQ46', 'c9Aqg5RD1PM:APA91bGoknlSnSkt3qlH0GzHSmcrAseU-9zWQKjfeJ2sJkVFBrt8Ks3LoKrynOfijYfDLJYY_74ibKiY-9pxlk1kwp7Aa2zPgNXZDOtRP61SAlPQCBvItwRh1m4N656iqXlVNVaD57tX', 'A', 2, 0, 5, '$2y$10$i1Khkw4wMCQgTdPUzdWoL.vJdbgWuNGVdq1KdM4P4aCKZx82nEozS', '2019-08-20 06:41:23', '2019-08-30 07:43:23'),
(77, 'Annu', NULL, 'anuiOS123@gmail.com', '$2y$10$tK4DVOnsmqhF5lOwTP205ONAbCrM3EEViN4bN5./.H6Qf5.MtqyEa', '98531475', NULL, '23KYK9KLQF', 'c5sCrr2N_ZU:APA91bHCtWbEV9TaCF1JWz1bjqUTmpag5iraNQteg2reQSfGRb6557UnIfEfSrj3Ev8hhurTw0Rz0S_TA9zInmnrMPbzgqOevUgMwcT2lpU5jIX6V3uslcYiREWq_AH18Hpdy1TvJkPI', 'I', 1, 0, NULL, '$2y$10$xjxgiw4uzc/THCEu3p3vHuu7O8tLdlr4x/bz0qZE8zCW1/efDTKfO', '2019-08-20 07:15:22', '2019-08-20 07:15:22'),
(79, 'charan', 'Provider', 'charanveerg@gmail.com', '$2y$10$on1.yBKs9wCNbhmgUea.J.ZOPA9LluZAB90GDbjzO3AhVXRFi5Fz.', '1254875425', NULL, '4MOBY4MTLY', NULL, 'A', 1, 1, 5, '$2y$10$0aE42583yKxBD6FV0ufgbOMBsFJJWOxUYmUZVu5/0mFfIBFV6ELn2', '2019-08-21 00:26:04', '2019-08-26 08:44:11'),
(80, 'newuser', 'Provider', 'newuser@gmail.com', '$2y$10$JG1ZTxP.aGNuZzsUeucOZ.m/Y29iEhLbOImAkY/t.lTHrkCGsUN3G', '1254875421', '4418871566374073.jpg', '81H738JRQH', NULL, 'A', 1, 1, 5, '$2y$10$w8jOfsmKpJ3pJ0rZWIVEJOCS52F7Kp3OCmBZMuVWYmL.0dPQLPMpG', '2019-08-21 02:22:50', '2019-08-27 01:18:54'),
(81, 'ajay', 'Provider', 'ajaybhattit@gmail.com', '$2y$10$qpKUwQDbTz0hLC4qDRMJfuGmrN/HdjnLczGnDu20RX2u6yzr/bQ8G', '9650240243', NULL, 'Z08KIONJUR', NULL, 'A', 1, 1, 5, '$2y$10$b35Z2E5CkOJEjKw8EyISGecjrOWRHfmwiQCU0R4Kje7.SxUBuaDVe', '2019-08-21 05:08:42', '2019-08-21 06:47:19'),
(82, 'newuser', NULL, 'newuserg@gmail.com', '$2y$10$.IODa6EQET27s53eexFPZuZ/wDY5ZcXPiofpX.QQAAzJ3aZaNVsLG', '9690267595', NULL, 'G9L0X1PIPS', 'hsdfggfyugdsuf435464656354', 'A', 2, 0, 5, '$2y$10$uDIk0IR3OQApI7XMFCIGfOVUh/EdBJtQ/She.1mC.nX8IgKFk3gM6', '2019-08-21 06:50:27', '2019-08-30 07:43:25'),
(83, 'charan', 'Provider', 'charan333@gmail.com', '$2y$10$Vl6GCYO8wGBsOXWbglt.LOKuU7W6Z1BE20qf21zjzFsWwX58HDPfu', '125487542', NULL, 'DY2UX80I9G', NULL, 'A', 1, 1, 5, '$2y$10$xAMquDuTdML6Bq86vb9RWenLtMNeZzLMmqb4k5Vs8NmWg6iPMyzJS', '2019-08-23 04:46:58', '2019-08-23 06:13:23'),
(84, 'Annu', NULL, 'Priya@gmail.com', '$2y$10$gB3O4Y9Fy94LeMDGWXcRt.kaOswjyvRDZUYy3wWfNHa3aPVaVpO2O', '48246183', NULL, 'FAIR3JJQRP', 'dBY9fTZUocA:APA91bFyFM7qEon9P88TRjRDpAp4jcLiTfLhRgNMqu-4TzkUPqxh871gCWEjOTlsNMLsO11MbvQg_FH2WE3ZrZ4vAZWLCJLZuUaNKeL1rg_vfDtYS1AyFGZQjOHgcZIzxWsU0jtoBR93', 'I', 1, 0, NULL, '$2y$10$fiF3gpAnaBgu31mWZ0ckK.hS6KCbgSixa92L1xW9VrZQIhouzUMIe', '2019-08-23 06:23:29', '2019-08-23 06:23:29'),
(85, 'Anu', NULL, 'ap456@gmail.com', '$2y$10$Ydws8f6P7mW06gFAyOuWfOvQ/m7OvcrX6Ki04va0TP2rxDWqqf8LS', '98364122', NULL, '39RNA6TAD2', 'dBY9fTZUocA:APA91bFyFM7qEon9P88TRjRDpAp4jcLiTfLhRgNMqu-4TzkUPqxh871gCWEjOTlsNMLsO11MbvQg_FH2WE3ZrZ4vAZWLCJLZuUaNKeL1rg_vfDtYS1AyFGZQjOHgcZIzxWsU0jtoBR93', 'I', 1, 0, NULL, '$2y$10$23Q3gDou7GP3UXxS6O76JeWWvGoSh/LobF7NIBT1M5t/R8UknuG26', '2019-08-23 06:25:29', '2019-08-23 06:26:05'),
(86, 'final', 'Provider', 'finaltest@gmail.com', '$2y$10$csqZanotdyFrttEJDQpR4Oi2xvETuY43B/tnbLEMEh4k/wqOUeRJe', '123456', NULL, 'X1D1PWQ9RY', 'eKkKF1sw55A:APA91bHG-7O41_3vEOgz6EErCjadSIVatpVabKzwqOH-GbnrboPAmS6LGLIySrWZg-F-RD20u187x1TXLTrWq8fbpL6y4UEgvyi5XJF8ASjhnCBKBbcMoMtF1b5fp4RJnCar2fHmW2e-', 'A', 1, 1, 5, '$2y$10$.Sa.R2Bnv7cIY9idi/ziSessqS4aJ/3ChbPUJmy4GNc7kIJk8VD1a', '2019-08-27 01:24:07', '2019-08-27 02:45:45'),
(87, 'customerfinal', NULL, 'customerfinal@gmail.com', '$2y$10$nBaGzkp4fXW6XZHfNudR7eqjP0cIaQ3rFrJuOicd68VE0CDhO1eGG', '4125455255', '3324861566906009.jpg', 'HJTZHJ9KRF', NULL, 'A', 1, 0, NULL, '$2y$10$H.8G.3cM2cjqx.kmaWJo0ePp0ueqOV5b/w6qI/3FiDTRInVmrliei', '2019-08-27 06:09:27', '2019-08-27 06:34:33'),
(88, 'finaltest', 'Provider', 'finaltesting@gmail.com', '$2y$10$E5LUG5ctChKBjgVxfXg8..2pJe14MBjSg9Yos4gO/GH2q1VnMuzHm', '12345678', NULL, 'XZJ33XLOMN', NULL, 'A', 1, 1, 5, '$2y$10$IjBZ6OBgBC3ggAIg55Q7TuirDetiNNyGsQFzR4LAPEowthSGtteQu', '2019-08-27 06:16:29', '2019-08-27 06:32:28'),
(89, 'Honour 9 Lite', NULL, 'honor.smartitventures@gmail.com', '$2y$10$fcbcbj79jxILfg2dOJPShuqdAQPqhiayyvqMDMvaBZWqRen.qkcB6', '3698521470', NULL, 'JX02190ZGD', 'elcBjWgXI-E:APA91bEhNKrv4LGiIhfsNS0a62A3u47m8GvgqFE8wPshcVQW3yO_HEGBtqxUg2vxPcoK7QyjjfOgS1tVcoB_ytdXOpF93YBx7JccueIjUP8sreaNYdpqfkFxotFWRuHngQWJ8BeFMhsd', 'A', 1, 0, NULL, '$2y$10$2ri7LpDr0wY04dnuqPvsTOpksG7tTiGLhHWnZ1Ash0eQCX/UduKRe', '2019-08-27 06:43:24', '2019-08-27 06:43:24'),
(90, 'dhdj', 'Provider', 'dhdjdg@gmail.com', '$2y$10$qPN13.KKhAFJV1jZulvVBOrG7k/R9ODwUSBZ5chfML.HUgIP2obcO', '85764545', NULL, 'W71376CCZ5', 'eQGO73CqljA:APA91bF90V8SEwT2hUm95ArFjfSoIey5g72JVCEK_vunSHTnmFKzc-1LfdVXAIYkM0VAwvbKTYCRK25dQ5xowIWHRS4-N7bU1mnXnpvvh6YKgZQb_Ad-gujXAZNKNOy5Rjk9pCjgkdoD', 'A', 2, 0, 5, '$2y$10$IqY6mqMTIIHnbYkLCCDdN.yIJD.ZqVoA.GZ6zsMup/Iz3Fp.UG5vW', '2019-08-27 07:39:40', '2019-08-27 07:43:21'),
(91, 'xgdj', 'Provider', 'xhsh@gmail.com', '$2y$10$sE7TwoxQ8Qc0at9lxeEhGOBhREyfZbHJqarsC8zv9IsWrwxV1LFq6', '56565', NULL, 'TWB6QK3GBA', 'eQGO73CqljA:APA91bF90V8SEwT2hUm95ArFjfSoIey5g72JVCEK_vunSHTnmFKzc-1LfdVXAIYkM0VAwvbKTYCRK25dQ5xowIWHRS4-N7bU1mnXnpvvh6YKgZQb_Ad-gujXAZNKNOy5Rjk9pCjgkdoD', 'A', 2, 0, 5, '$2y$10$ccF9Pg8RaqO/b0AI9EutsuOzLMVFCaR0jvK5XF22VERdz6/SQnpxC', '2019-08-27 07:50:21', '2019-08-30 07:43:28'),
(92, 'sameer', NULL, 'sameer.smartitventures@gmail.com', '$2y$10$MQXnh6GT8EnxKSgd.83kS.fncfOoRDyNr9jufacwcbTVVIGXqRg/C', '8284904441', NULL, 'JRIOFRXSIN', NULL, 'A', 1, 0, NULL, '$2y$10$bOSAIA3bA9wFfzLRjtrpMeOLGdm9/8lSH6BQhsAY1erT1afG0tVpi', '2019-08-28 02:32:38', '2019-08-30 07:04:02'),
(93, 'aman', 'Provider', 'aman.smartitventures@gmail.com', '$2y$10$fUsiAcVQ8hKgOP7zXAcuhuAt/O6EfrqFU/AAJ734qAOoendClCD.O', '8284904442', NULL, 'JIKDV7LM5Y', NULL, 'A', 1, 1, 5, '$2y$10$7t8PpcPfrrckZgCbOi5r2ejhoL9KTX0ouO/gWrgkcXHUCslMfJx16', '2019-08-28 02:36:34', '2019-08-28 05:01:07'),
(94, 'testinguser', 'Provider', 'testuser@gmail.com', '$2y$10$381z13DxuM.maskRE2pJFu1vpYPrIH2iOMA0evXzfqypzjObltUwa', '1254857414', NULL, 'GD2CYFNMIG', NULL, 'A', 1, 1, 5, '$2y$10$ZR..horBw9ZDGa9w0ndF.ur1gdDdde69v1wp8fwvmu3qP.348H6ua', '2019-08-28 02:46:01', '2019-08-28 04:35:29'),
(95, 'ajay', NULL, 'ajaybhatttyit@gmail.com', '$2y$10$jyMDWfVRhUWr2VGUvz71vutAL8j4qzQFmzqkxVfIHDeoPjdmXpGFq', '9650240243', NULL, 'TAP3GWH41Z', 'elcBjWgXI-E:APA91bEhNKrv4LGiIhfsNS0a62A3u47m8GvgqFE8wPshcVQW3yO_HEGBtqxUg2vxPcoK7QyjjfOgS1tVcoB_ytdXOpF93YBx7JccueIjUP8sreaNYdpqfkFxotFWRuHngQWJ8BeFMhsd', 'A', 1, 0, NULL, '$2y$10$Z.WQMx1dBcuPME1DoZOcZucjNapS8hd6/qi/T/HzA7kp5Vz6ualji', '2019-08-28 04:12:25', '2019-08-28 04:12:25'),
(96, 'charan', 'Provider', 'charan134@gmail.com', '$2y$10$ltTStmQ7P6HgqN014T85suCw9YGxmK4aekGbaDBJLYG7RXpki35OS', '12547845', NULL, 'KAPM5NFIOR', 'eFffq00RNgY:APA91bGtokZJ0Rp_lhjSKJI_0YjG4U2UuciY4oriMgZnB1XkeBsZujTfSp0oCfl7ZESuyn4IeTb-Ne2AXQcxD_wsN-Y3c1eCixcRQ_lEFhgaT6XsltYOsAc3ysmwI4sYOrmX7olYpqXq', 'A', 1, 1, 5, '$2y$10$Cq5x0MBklvD7j9kJWQ4swemAI6KZaCpMURV6WU9EalXSEGMEgSq02', '2019-08-28 04:36:38', '2019-08-29 06:10:50'),
(97, 'charan', NULL, 'charan124@gmail.com', '$2y$10$JCP.Zlx2bSdlIb.aP4jEXe6RaDvlrENFXhnsUJ/urrKXD/6LjH.Xe', '9690267595', NULL, '6WG6TAV1QA', NULL, 'A', 1, 1, 5, '$2y$10$UpK6iJmT1BktdwVlVBrN.OIHM4k7UbKzaciLZogihwLFrDB2VHq6e', '2019-08-28 04:49:49', '2019-08-28 05:25:10'),
(98, 'hxjxh', 'Provider', 'charanveer90@gmail.com', '$2y$10$ZpePmNFh1rqAPTY4HThlcO.gNRIWWbi3p69enkvTBHaIqnz3dIZoy', '6325551537272', NULL, '09W3UFS235', 'c-n8JCNBMKs:APA91bGoBUVzbJdkQSuOmRfIpJJxW6sVtwXynMcyfUd8e97FHt1QpOI3oWkUgrvd5mjNKfGAEMDzt6Iyk9mmkFGFX06wTmpL7wMGnozrDdqL5cKo0GjhdstXBV9fZMpDG06RMvSZeOSW', 'A', 1, 1, 5, '$2y$10$dSA/GIkWxhr7AgfvCK6WCOclgraVeIIlPVg75yVnWCoe8Rc8a2jNC', '2019-08-28 06:06:17', '2019-08-28 06:13:28'),
(99, 'zipcode', 'Provider', 'ziocode@gmail.com', '$2y$10$2Hp38SKmKkCLAZkP9nhEOeXsVhl25MIdse2/XjUAOk1JDWED2.doW', '1234567856', NULL, '4EQG6JBHJF', NULL, 'A', 1, 1, 5, '$2y$10$hA1bxbpB.ProfPTYH6sCu.RJ3bVTuBr5OfQ5zV8cFCnfyDCRfuRya', '2019-08-28 06:14:43', '2019-08-28 06:33:41'),
(100, 'zipcode', 'Provider', 'zipcode@gmail.com', '$2y$10$wXwD.HjV/xH4YuuzNcS6HO2xXDTH56pwyiVaUZdWRv1VM5RouWaz6', '5521255875655', NULL, 'YHZTU1UDWX', NULL, 'A', 1, 1, 5, '$2y$10$St8HKieT/sBjl87b1vzgWOH9vBFoqdHcKe3Y29If3wQYIGmdV5JP.', '2019-08-28 06:34:36', '2019-08-28 08:07:38'),
(101, 'harpreet', NULL, 'harpreet13@gmail.com', '$2y$10$epcB4nMmxm5LGRZPh45kX.lP2UjPGmE2M31nz2fwO751D1lqcSY.W', '8284904441', NULL, 'RLPC1NPWW1', 'cL-w4h0VcUs:APA91bHy7f0PxEt6Iny2YP5UBU3JwemzUDTH0VfMcHqx1o2BC8TAXw5rvcVh2Xs3ErEqoL1Zwx6c_15QdW44iYkk7syNtgKsHQHuafHxos5XOJ_TWkiIdR2P_74XuFcDW32R5waHb3wg', 'A', 1, 0, NULL, '$2y$10$pg8JVSB8fYj5pfumt3RRouFLpFcDAdcVFkcbk37TTgoSDw91HlnmS', '2019-08-28 08:08:21', '2019-08-28 08:08:21'),
(102, 'newtest', 'Provider', 'newtest@gmail.com', '$2y$10$LCak.7Y3w64TRhUgQ.jNee9T6idjmScdq973bG0G2Zs5/TR1HBhUK', '1257572725452', NULL, 'CJ6ZIA95JG', NULL, 'A', 1, 1, 5, '$2y$10$UI1fBYXiBylpCkXnUG/cTOehYAoOyy3ij8BJCjflb6pNBmnAh0EnS', '2019-08-28 08:08:41', '2019-08-29 01:44:22'),
(103, 'rahul', 'Provider', 'rahul@gmail.com', '$2y$10$PKcMjEWk6ROd.1eNHvtEJuzIOHWoZcTYgjdYrvYL4ueTF7YCV7xKG', '5648484155', NULL, 'R2S90XDKQG', NULL, 'A', 1, 1, 5, '$2y$10$aRsilIXxALLvA3LsyT9/JOqUK/xlc/PbfrJkU5h4mlual6IWuhE8e', '2019-08-29 01:44:55', '2019-08-29 02:14:03'),
(104, 'honor', 'Provider', 'honor@gmail.com', '$2y$10$SUFkXD9a91KoX5ST5PeA0OtboSdDH3TpuSNsN.HirYhD0b9wRBXZq', '51915453', NULL, 'LGRYMGPJZA', NULL, 'A', 1, 1, 5, '$2y$10$2u1f653GLgZRABQ5aX6GYu/5dwti/Dm9jciZw9zN9FSoeEkLqPHQa', '2019-08-29 02:14:51', '2019-08-30 04:04:46'),
(105, 'rajesh', 'Provider', 'rajesh12@gmail.com', '$2y$10$3MenFlMSBNyzyrhKmo5i7.rZ8gVFZGOcBetjHw1jWD/FgZrXEKdXa', '2580741258', NULL, '5CPEG57CNV', NULL, 'A', 1, 1, 5, '$2y$10$rZXJy/oAGUDxSLM4H00xW.qFV7aFsZFJ.XWugSMWMqbjY6I4Sb4ZO', '2019-08-30 04:06:03', '2019-08-30 05:24:01'),
(106, '...', 'Provider', 'vijay12@gmail.com', '$2y$10$UXr1G7ujjBz3GPUB4FREU.CWQDUBMOFE2G1aHhqkwnP82Fhm6hoi2', '0', NULL, '2GE9QEMIBI', NULL, 'A', 1, 1, 5, '$2y$10$v2I55.wConP9v/3wGiLoN.GNxd3gYQJqVznd/.gIuBvsZi6IbC8de', '2019-08-30 04:11:42', '2019-08-30 04:36:18'),
(107, 'Shubham', NULL, 's@yopmail.com', '$2y$10$/LkK1QjmUH5y/Y.u1SlOcudDMoHIShuUBH6J28prtLwMd1w3.TXdK', '5465456435234', NULL, 'RG2ICTPFJ7', 'fvo__QkNnXM:APA91bEcGdKLEVjLlLppKTNGtFUDTT0zwi3Z-qhlztxwQ7pfpUXXywOqpsSwDM_ZYYjM6bYSSclBYDmaW8AgEktSHrGp04mePiMRdf1yPo4ejeRHZZ0cgG5NatXlos_2oOCnKa9iM5gg', 'I', 1, 0, NULL, '$2y$10$1eic8dzd6kfBpwm22EXQHOmqWjsgSx9s9DL3MfqzBW2HDeG58SIY.', '2020-02-28 01:00:22', '2020-02-28 04:44:47'),
(108, 'Provider Shubham', NULL, 'ps@yopmail.com', '$2y$10$tJoGYK806yA7TbDEI.Ejzeo/rqdDGtfi3drb6SCJKf8dq0snLSVG6', '54594643446', NULL, 'YTW5PHUAHY', NULL, 'I', 1, 1, 5, '$2y$10$ZThCZEhjmqUTWhKKt.NO5eSVHEFM5MsFNYpCnJMKR72Jr/Gr2XKUe', '2020-02-28 01:03:25', '2020-02-28 04:24:48'),
(109, 'Durgesh', NULL, 'ajayb.smartitventures@gmail.com', '$2y$10$WsZDgwvDWFIafrDzPhDXQOAIum44JeAzcv8xz0cCO1GZnExxMRfGq', '8284904441', NULL, 'EGLGF9SFBV', 'fvo__QkNnXM:APA91bEcGdKLEVjLlLppKTNGtFUDTT0zwi3Z-qhlztxwQ7pfpUXXywOqpsSwDM_ZYYjM6bYSSclBYDmaW8AgEktSHrGp04mePiMRdf1yPo4ejeRHZZ0cgG5NatXlos_2oOCnKa9iM5gg', 'I', 1, 0, NULL, '$2y$10$hfoq6Sz51MOfLQnisX6gh.Qd9QcjaBuCUsvPzdp3bGejcSSr1qZp.', '2020-02-28 04:27:01', '2020-02-28 04:27:01'),
(110, 'Harkesh', NULL, 'jagdeep.smartitventures@gmail.com', '$2y$10$vkFlniv855h3zftwQoLFyeXOQ0FihUlfFVdkp1HpKbw3B6.sDZdo6', '567687646767', NULL, 'DFKUOAH13M', 'elh8ve_wZB0:APA91bEWJYQgOaQiYVs2jMM4aykCqPHFf-5z1YZ0fnkA0uroQs5dFSnqpatCWmsHZNyO41wjc5EuZcjCCFlHilFqkX9PZWgIG44n48k9_LuA04dZRfTGewhIyGBQ4gJXOlZHzaI7oYjP', 'I', 1, 1, 5, '$2y$10$ibL7TjRWbbchkmasJ0tLZOpBp7UTvM6Q5lp8JR/KQ0PkJpl6EwnSW', '2020-02-28 04:27:10', '2020-02-28 04:28:58');

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `role_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`id`, `user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2019-03-19 18:30:00', '2019-03-19 18:30:00'),
(2, 2, 5, '2019-01-22 00:28:30', '2019-01-22 00:28:30'),
(3, 3, 2, '2019-01-22 00:30:14', '2019-01-22 00:30:14'),
(4, 4, 5, '2019-01-22 00:32:06', '2019-01-22 00:32:06'),
(5, 5, 2, '2019-01-22 00:34:52', '2019-01-22 00:34:52'),
(6, 6, 5, '2019-01-22 00:37:06', '2019-01-22 00:37:06'),
(7, 7, 2, '2019-01-22 00:38:31', '2019-01-22 00:38:31'),
(10, 10, 5, '2019-01-22 02:11:42', '2019-01-22 02:11:42'),
(11, 11, 2, '2019-01-22 02:15:54', '2019-01-22 02:15:54'),
(12, 12, 5, '2019-01-24 00:09:17', '2019-01-24 00:09:17'),
(15, 15, 5, '2019-01-25 02:06:31', '2019-01-25 02:06:31'),
(16, 16, 5, '2019-01-25 02:36:03', '2019-01-25 02:36:03'),
(35, 37, 2, '2019-01-31 06:24:29', '2019-01-31 06:24:29'),
(38, 40, 2, '2019-02-04 01:47:32', '2019-02-04 01:47:32'),
(40, 42, 5, '2019-02-04 02:01:20', '2019-02-04 02:01:20'),
(41, 43, 2, '2019-02-04 02:02:00', '2019-02-04 02:02:00'),
(42, 44, 2, '2019-02-05 00:27:27', '2019-02-05 00:27:27'),
(43, 45, 5, '2019-02-07 06:24:47', '2019-02-07 06:24:47'),
(44, 46, 5, '2019-02-07 07:27:37', '2019-02-07 07:27:37'),
(45, 47, 2, '2019-02-20 07:06:38', '2019-02-20 07:06:38'),
(46, 48, 5, '2019-02-25 00:26:07', '2019-02-25 00:26:07'),
(47, 49, 2, '2019-04-01 05:32:07', '2019-04-01 05:32:07'),
(48, 50, 2, '2019-04-03 07:36:54', '2019-04-03 07:36:54'),
(50, 52, 2, '2019-04-10 06:21:21', '2019-04-10 06:21:21'),
(51, 53, 5, '2019-04-16 05:06:46', '2019-04-16 05:06:46'),
(52, 54, 2, '2019-05-18 00:49:25', '2019-05-18 00:49:25'),
(53, 55, 5, '2019-05-18 03:12:42', '2019-05-18 03:12:42'),
(54, 56, 5, '2019-05-20 00:50:18', '2019-05-20 00:50:18'),
(55, 57, 5, '2019-05-20 01:48:46', '2019-05-20 01:48:46'),
(56, 58, 5, '2019-05-20 01:53:56', '2019-05-20 01:53:56'),
(57, 59, 5, '2019-05-20 02:45:37', '2019-05-20 02:45:37'),
(58, 60, 2, '2019-05-20 05:24:47', '2019-05-20 05:24:47'),
(59, 61, 5, '2019-05-20 06:44:07', '2019-05-20 06:44:07'),
(60, 62, 5, '2019-05-20 07:12:17', '2019-05-20 07:12:17'),
(61, 63, 2, '2019-05-20 07:21:53', '2019-05-20 07:21:53'),
(62, 64, 5, '2019-06-03 05:00:04', '2019-06-03 05:00:04'),
(63, 65, 2, '2019-07-02 01:36:20', '2019-07-02 01:36:20'),
(64, 66, 5, '2019-07-12 02:31:41', '2019-07-12 02:31:41'),
(65, 67, 5, '2019-08-20 02:57:58', '2019-08-20 02:57:58'),
(66, 68, 5, '2019-08-20 02:59:04', '2019-08-20 02:59:04'),
(67, 69, 5, '2019-08-20 02:59:39', '2019-08-20 02:59:39'),
(68, 70, 5, '2019-08-20 03:07:46', '2019-08-20 03:07:46'),
(69, 71, 5, '2019-08-20 03:59:58', '2019-08-20 03:59:58'),
(70, 72, 5, '2019-08-20 04:06:47', '2019-08-20 04:06:47'),
(71, 73, 5, '2019-08-20 04:07:43', '2019-08-20 04:07:43'),
(72, 74, 5, '2019-08-20 04:14:39', '2019-08-20 04:14:39'),
(73, 75, 5, '2019-08-20 04:17:53', '2019-08-20 04:17:53'),
(74, 76, 2, '2019-08-20 06:41:23', '2019-08-20 06:41:23'),
(75, 77, 5, '2019-08-20 07:15:22', '2019-08-20 07:15:22'),
(77, 79, 2, '2019-08-21 00:26:04', '2019-08-21 00:26:04'),
(78, 80, 2, '2019-08-21 02:22:50', '2019-08-21 02:22:50'),
(79, 81, 2, '2019-08-21 05:08:42', '2019-08-21 05:08:42'),
(80, 82, 2, '2019-08-21 06:50:27', '2019-08-21 06:50:27'),
(81, 83, 2, '2019-08-23 04:46:58', '2019-08-23 04:46:58'),
(82, 84, 5, '2019-08-23 06:23:29', '2019-08-23 06:23:29'),
(83, 85, 5, '2019-08-23 06:25:29', '2019-08-23 06:25:29'),
(84, 86, 2, '2019-08-27 01:24:07', '2019-08-27 01:24:07'),
(85, 87, 5, '2019-08-27 06:09:27', '2019-08-27 06:09:27'),
(86, 88, 2, '2019-08-27 06:16:29', '2019-08-27 06:16:29'),
(87, 89, 5, '2019-08-27 06:43:24', '2019-08-27 06:43:24'),
(88, 90, 2, '2019-08-27 07:39:40', '2019-08-27 07:39:40'),
(89, 91, 2, '2019-08-27 07:50:21', '2019-08-27 07:50:21'),
(90, 92, 5, '2019-08-28 02:32:38', '2019-08-28 02:32:38'),
(91, 93, 2, '2019-08-28 02:36:34', '2019-08-28 02:36:34'),
(92, 94, 2, '2019-08-28 02:46:01', '2019-08-28 02:46:01'),
(93, 95, 5, '2019-08-28 04:12:25', '2019-08-28 04:12:25'),
(94, 96, 2, '2019-08-28 04:36:38', '2019-08-28 04:36:38'),
(95, 97, 2, '2019-08-28 04:49:49', '2019-08-28 04:49:49'),
(96, 98, 2, '2019-08-28 06:06:17', '2019-08-28 06:06:17'),
(97, 99, 2, '2019-08-28 06:14:43', '2019-08-28 06:14:43'),
(98, 100, 2, '2019-08-28 06:34:37', '2019-08-28 06:34:37'),
(99, 101, 5, '2019-08-28 08:08:21', '2019-08-28 08:08:21'),
(100, 102, 2, '2019-08-28 08:08:41', '2019-08-28 08:08:41'),
(101, 103, 2, '2019-08-29 01:44:55', '2019-08-29 01:44:55'),
(102, 104, 2, '2019-08-29 02:14:51', '2019-08-29 02:14:51'),
(103, 105, 2, '2019-08-30 04:06:03', '2019-08-30 04:06:03'),
(104, 106, 2, '2019-08-30 04:11:42', '2019-08-30 04:11:42'),
(105, 107, 5, '2020-02-28 01:00:23', '2020-02-28 01:00:23'),
(106, 108, 2, '2020-02-28 01:03:25', '2020-02-28 01:03:25'),
(107, 109, 5, '2020-02-28 04:27:01', '2020-02-28 04:27:01'),
(108, 110, 2, '2020-02-28 04:27:11', '2020-02-28 04:27:11');

-- --------------------------------------------------------

--
-- Table structure for table `weekly_scheduled_jobs`
--

CREATE TABLE `weekly_scheduled_jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(11) NOT NULL,
  `Zipcode` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `days` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `services` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `weekly_scheduled_jobs`
--

INSERT INTO `weekly_scheduled_jobs` (`id`, `customer_id`, `Zipcode`, `days`, `time`, `services`, `customer_address`, `created_at`, `updated_at`) VALUES
(11, 10, '70008', '1,3,5', '10:40,11:40,9:40', '14,22,26', 'Donald M. Palmer 2595 Pearlman Avenue Sudbury, MA 01776 Phone:293-112-459', '2019-02-06 07:09:59', '2019-02-06 07:09:59'),
(12, 42, '40003', '3,5', '11:00,12:30', '14,22,26', 'Michael I. Days 3756 Preston Street Wichita, KS 67213 Phone:857-778-1265', '2019-02-06 07:10:51', '2019-02-06 07:10:51'),
(13, 6, '50005', '1,4', '09:00,12:30', '14,22,26,23', 'Carol J. Stephens 1635 Franklin Street Montgomery, AL 36104 Phone:126-632-2345', '2019-02-06 07:11:52', '2019-02-06 07:11:52'),
(15, 12, '70001', '7,1,4,5', '09:00,12:30,19:00,22:30', '26,23,14', 'Micheal R. Porterfield 508 Virginia Street Chicago, IL 60653 Phone:346-523-454', '2019-02-06 08:34:42', '2019-02-06 08:34:42'),
(16, 10, '70008', '1,3,5', '10:40,11:40,9:40', '14,22,26', 'Michael I. Days 3756 Preston Street', '2019-02-07 00:57:25', '2019-02-07 00:57:25'),
(17, 12, '70001', '1,2,3,4', '10:20,10:20,10:20,10:20', '26,23,14', 'Micheal R. Porterfield 508 Virginia Street Chicago, IL 60653 Phone:346-523-454', '2019-02-07 07:08:58', '2019-02-07 07:08:58'),
(18, 12, '70001', '1,2,3,4', '10:20,10:20,10:20,10:20', '26,23,14', 'Micheal R. Porterfield', '2019-02-08 01:13:56', '2019-02-08 01:13:56'),
(19, 12, '70001', '1,2,3,4', '10:20,10:20,10:20,10:20', '26,23,14', 'Micheal R. Porterfield', '2019-02-11 00:17:52', '2019-02-11 00:17:52'),
(20, 4, '40002', '1,3,4', '11:45,2:45,8:45', '22,23,26', 'jijkjj', '2019-02-21 00:45:49', '2019-02-21 00:45:49'),
(21, 16, '70008', '1,2', '23:26,17:26', '23', 'fggh', '2019-03-15 02:27:35', '2019-03-15 02:27:35'),
(22, 16, '40003', '1', '23:3', '23', 'fghh', '2019-03-16 03:03:28', '2019-03-16 03:03:28'),
(23, 16, '40003', '1,4,7', '18:19,17:19,20:19', '22', 'Ropar', '2019-03-16 05:19:50', '2019-03-16 05:19:50'),
(24, 16, '50009', '1,3,5', '19:07,19:06,14:06', '14', 'Ropar', '2019-04-03 06:06:42', '2019-04-03 06:06:42'),
(25, 16, '50009', '1,3,5', '16:50,17:50,19:53', '14,22,26', 'Ropar', '2019-04-09 04:51:23', '2019-04-09 04:51:23'),
(26, 16, '50009', '1,5,7', '17:40,18:40,20:40', '14,22,26', 'Ropar', '2019-04-09 05:41:01', '2019-04-09 05:41:01'),
(27, 16, '50009', '1,5,7,1,5,7', '17:40,18:40,20:40,17:40,18:40,20:40', '14,22,26', 'Ropar', '2019-04-09 05:41:05', '2019-04-09 05:41:05'),
(28, 16, '50009', '1,3,3,5', '19:52,19:52,20:52,23:52', '14,22,23,26', 'Ropar', '2019-04-09 06:52:46', '2019-04-09 06:52:46'),
(29, 62, '40003', '4,5', '15:42,14:42', '22', 'ghh', '2019-05-20 07:42:43', '2019-05-20 07:42:43'),
(30, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:42', '2019-07-12 02:50:42'),
(31, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:42', '2019-07-12 02:50:42'),
(32, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:42', '2019-07-12 02:50:42'),
(33, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:42', '2019-07-12 02:50:42'),
(34, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:42', '2019-07-12 02:50:42'),
(35, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:43', '2019-07-12 02:50:43'),
(36, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:43', '2019-07-12 02:50:43'),
(37, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:43', '2019-07-12 02:50:43'),
(38, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:43', '2019-07-12 02:50:43'),
(39, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:43', '2019-07-12 02:50:43'),
(40, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:43', '2019-07-12 02:50:43'),
(41, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:43', '2019-07-12 02:50:43'),
(42, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:43', '2019-07-12 02:50:43'),
(43, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:43', '2019-07-12 02:50:43'),
(44, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:43', '2019-07-12 02:50:43'),
(45, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:43', '2019-07-12 02:50:43'),
(46, 16, '50001', '1', '14:50', '14,22,23,26', 'ddff', '2019-07-12 02:50:45', '2019-07-12 02:50:45');

-- --------------------------------------------------------

--
-- Table structure for table `working_days`
--

CREATE TABLE `working_days` (
  `id` int(10) UNSIGNED NOT NULL,
  `day` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `working_days`
--

INSERT INTO `working_days` (`id`, `day`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Monday', 1, '2019-02-05 04:25:25', '2019-03-02 04:33:10'),
(2, 'Tuesday', 1, '2019-02-05 04:25:32', '2019-03-02 04:41:06'),
(3, 'Wednesday', 1, '2019-02-05 04:25:39', '2019-03-02 04:33:15'),
(4, 'Thursday', 1, '2019-02-05 04:25:45', '2019-03-14 23:53:56'),
(5, 'Friday', 1, '2019-02-05 04:25:51', '2019-03-14 23:53:57'),
(7, 'Saturday', 1, '2019-02-05 04:32:30', '2019-03-14 23:53:57'),
(9, 'Sunday', 0, '2019-03-02 04:41:42', '2019-08-30 07:36:34');

-- --------------------------------------------------------

--
-- Table structure for table `zipcodes`
--

CREATE TABLE `zipcodes` (
  `id` int(10) UNSIGNED NOT NULL,
  `city_id` int(10) UNSIGNED DEFAULT NULL,
  `zipcode` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `zipcodes`
--

INSERT INTO `zipcodes` (`id`, `city_id`, `zipcode`, `created_at`, `updated_at`) VALUES
(15, 25, '60001', '2018-12-04 02:21:36', '2019-01-21 23:48:15'),
(16, 26, '50007', '2018-12-04 02:21:45', '2019-01-21 23:47:29'),
(19, 23, '50006', '2018-12-04 02:22:12', '2019-01-21 23:47:07'),
(20, 22, '50005', '2018-12-04 02:22:25', '2019-01-21 23:46:54'),
(22, 34, '40001', '2018-12-04 02:22:42', '2019-02-02 08:22:03'),
(23, 20, '50009', '2018-12-04 02:22:54', '2019-01-21 23:46:22'),
(24, 21, '50002', '2018-12-04 02:23:10', '2019-01-21 23:46:03'),
(25, 20, '50001', '2018-12-04 02:23:23', '2019-01-21 23:45:51'),
(26, 24, '50000', '2018-12-04 02:23:36', '2019-01-21 23:45:38'),
(27, 27, '40003', '2018-12-04 02:23:48', '2019-01-21 23:45:20'),
(28, 27, '40002', '2018-12-04 02:23:58', '2019-01-21 23:44:57'),
(29, 33, '70001', '2019-02-02 08:22:42', '2019-02-02 08:22:42'),
(30, 19, '70002', '2019-02-02 08:23:44', '2019-02-02 08:23:44'),
(31, 35, '70004', '2019-02-02 08:26:46', '2019-02-02 08:26:46'),
(32, 28, '70005', '2019-02-02 08:27:27', '2019-02-02 08:27:27'),
(33, 29, '70006', '2019-02-02 08:27:48', '2019-02-02 08:27:48'),
(34, 31, '70007', '2019-02-02 08:28:09', '2019-02-02 08:28:09'),
(35, 32, '70008', '2019-02-02 08:29:01', '2019-02-02 08:29:01'),
(36, 30, '70009', '2019-02-02 08:29:47', '2019-02-02 08:29:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approved__bios`
--
ALTER TABLE `approved__bios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `block_customers`
--
ALTER TABLE `block_customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `block_providers`
--
ALTER TABLE `block_providers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cities_name_unique` (`name`),
  ADD KEY `cities_state_id_foreign` (`state_id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `countries_name_unique` (`name`);

--
-- Indexes for table `customer_faqs`
--
ALTER TABLE `customer_faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_faq_spanishes`
--
ALTER TABLE `customer_faq_spanishes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_faq_spanishes_cust_faqid_foreign` (`cust_faqId`);

--
-- Indexes for table `daily_scheduled_jobs`
--
ALTER TABLE `daily_scheduled_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discount_codes`
--
ALTER TABLE `discount_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instant_bookings`
--
ALTER TABLE `instant_bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instant_schedule_jobs`
--
ALTER TABLE `instant_schedule_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `j_ob_checkin_outs`
--
ALTER TABLE `j_ob_checkin_outs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `monthly_scheduled_jobs`
--
ALTER TABLE `monthly_scheduled_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `neighborhoods__zipcodes`
--
ALTER TABLE `neighborhoods__zipcodes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otps`
--
ALTER TABLE `otps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `otps_user_id_foreign` (`user_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `providerbios`
--
ALTER TABLE `providerbios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `provider_faqs`
--
ALTER TABLE `provider_faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `provider_faq_spanishes`
--
ALTER TABLE `provider_faq_spanishes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `provider_faq_spanishes_pro_faqid_foreign` (`pro_faqId`);

--
-- Indexes for table `provider_profiles`
--
ALTER TABLE `provider_profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `provider_reviews`
--
ALTER TABLE `provider_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `referrals`
--
ALTER TABLE `referrals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `serviceproviders`
--
ALTER TABLE `serviceproviders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `serviceproviders_email_unique` (`email`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `services_name_unique` (`name`);

--
-- Indexes for table `services_spanishes`
--
ALTER TABLE `services_spanishes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `services_spanishes_service_id_foreign` (`service_id`);

--
-- Indexes for table `service_prices`
--
ALTER TABLE `service_prices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_types`
--
ALTER TABLE `service_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `service_types_name_unique` (`name`),
  ADD KEY `service_types_service_id_foreign` (`service_id`);

--
-- Indexes for table `service_types_spanishes`
--
ALTER TABLE `service_types_spanishes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_types_spanishes_servicetype_id_foreign` (`servicetype_id`);

--
-- Indexes for table `special_request_to_cleaners`
--
ALTER TABLE `special_request_to_cleaners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sptostypes`
--
ALTER TABLE `sptostypes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `states_name_unique` (`name`),
  ADD KEY `states_country_id_foreign` (`country_id`);

--
-- Indexes for table `top_rated__providers`
--
ALTER TABLE `top_rated__providers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `useraddresses`
--
ALTER TABLE `useraddresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_roles_user_id_foreign` (`user_id`),
  ADD KEY `user_roles_role_id_foreign` (`role_id`);

--
-- Indexes for table `weekly_scheduled_jobs`
--
ALTER TABLE `weekly_scheduled_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `working_days`
--
ALTER TABLE `working_days`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `working_days_day_unique` (`day`);

--
-- Indexes for table `zipcodes`
--
ALTER TABLE `zipcodes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `zipcodes_zipcode_unique` (`zipcode`),
  ADD KEY `zipcodes_city_id_foreign` (`city_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approved__bios`
--
ALTER TABLE `approved__bios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `block_customers`
--
ALTER TABLE `block_customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `block_providers`
--
ALTER TABLE `block_providers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `customer_faqs`
--
ALTER TABLE `customer_faqs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `customer_faq_spanishes`
--
ALTER TABLE `customer_faq_spanishes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `daily_scheduled_jobs`
--
ALTER TABLE `daily_scheduled_jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `discount_codes`
--
ALTER TABLE `discount_codes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `instant_bookings`
--
ALTER TABLE `instant_bookings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=595;
--
-- AUTO_INCREMENT for table `instant_schedule_jobs`
--
ALTER TABLE `instant_schedule_jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=284;
--
-- AUTO_INCREMENT for table `j_ob_checkin_outs`
--
ALTER TABLE `j_ob_checkin_outs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;
--
-- AUTO_INCREMENT for table `monthly_scheduled_jobs`
--
ALTER TABLE `monthly_scheduled_jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `neighborhoods__zipcodes`
--
ALTER TABLE `neighborhoods__zipcodes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `otps`
--
ALTER TABLE `otps`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `providerbios`
--
ALTER TABLE `providerbios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `provider_faqs`
--
ALTER TABLE `provider_faqs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `provider_faq_spanishes`
--
ALTER TABLE `provider_faq_spanishes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `provider_profiles`
--
ALTER TABLE `provider_profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `provider_reviews`
--
ALTER TABLE `provider_reviews`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT for table `referrals`
--
ALTER TABLE `referrals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `serviceproviders`
--
ALTER TABLE `serviceproviders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `services_spanishes`
--
ALTER TABLE `services_spanishes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `service_prices`
--
ALTER TABLE `service_prices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `service_types`
--
ALTER TABLE `service_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `service_types_spanishes`
--
ALTER TABLE `service_types_spanishes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `special_request_to_cleaners`
--
ALTER TABLE `special_request_to_cleaners`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `sptostypes`
--
ALTER TABLE `sptostypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=330;
--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `top_rated__providers`
--
ALTER TABLE `top_rated__providers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `useraddresses`
--
ALTER TABLE `useraddresses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;
--
-- AUTO_INCREMENT for table `user_roles`
--
ALTER TABLE `user_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;
--
-- AUTO_INCREMENT for table `weekly_scheduled_jobs`
--
ALTER TABLE `weekly_scheduled_jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `working_days`
--
ALTER TABLE `working_days`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `zipcodes`
--
ALTER TABLE `zipcodes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `cities`
--
ALTER TABLE `cities`
  ADD CONSTRAINT `cities_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `customer_faq_spanishes`
--
ALTER TABLE `customer_faq_spanishes`
  ADD CONSTRAINT `customer_faq_spanishes_cust_faqid_foreign` FOREIGN KEY (`cust_faqId`) REFERENCES `customer_faqs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `otps`
--
ALTER TABLE `otps`
  ADD CONSTRAINT `otps_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `provider_faq_spanishes`
--
ALTER TABLE `provider_faq_spanishes`
  ADD CONSTRAINT `provider_faq_spanishes_pro_faqid_foreign` FOREIGN KEY (`pro_faqId`) REFERENCES `provider_faqs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `services_spanishes`
--
ALTER TABLE `services_spanishes`
  ADD CONSTRAINT `services_spanishes_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `service_types`
--
ALTER TABLE `service_types`
  ADD CONSTRAINT `service_types_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `service_types_spanishes`
--
ALTER TABLE `service_types_spanishes`
  ADD CONSTRAINT `service_types_spanishes_servicetype_id_foreign` FOREIGN KEY (`servicetype_id`) REFERENCES `service_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `states`
--
ALTER TABLE `states`
  ADD CONSTRAINT `states_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD CONSTRAINT `user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `zipcodes`
--
ALTER TABLE `zipcodes`
  ADD CONSTRAINT `zipcodes_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
